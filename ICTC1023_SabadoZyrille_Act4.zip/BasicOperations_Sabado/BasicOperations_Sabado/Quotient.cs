﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Sabado
{
    class Quotient
    {
        public double computeQuotient()
        {
            return DeclareVar.num1 / DeclareVar.num2;
        }
    }
}
