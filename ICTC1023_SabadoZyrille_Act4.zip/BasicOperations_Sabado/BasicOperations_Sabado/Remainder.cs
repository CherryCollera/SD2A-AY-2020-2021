﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Sabado
{
    class Remainder
    {
        public double computeRemainder()
        {
            return DeclareVar.num1 % DeclareVar.num2;
        }
    }
}
