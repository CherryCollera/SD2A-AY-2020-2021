﻿using System;

namespace BasicOperations_Sabado
{
    class Program
    {
        static void Main(string[] args)
        {
            Sum s = new Sum();
            Difference d = new Difference();
            Product p = new Product();
            Quotient q = new Quotient();
            Remainder r = new Remainder();
            Input i = new Input();
            i.InputVals();

            Console.WriteLine("Sum:\t{0}", s.computeSum());
            Console.ReadKey();

            Console.WriteLine("Difference:\t{0}", d.computeDifference());
            Console.ReadKey();

            Console.WriteLine("Product:\t{0}", p.computeProduct());
            Console.ReadKey();

            Console.WriteLine("Quotient:\t{0}", q.computeQuotient());
            Console.ReadKey();

            Console.WriteLine("Remainder: \t{0}", r.computeRemainder());
        }
    }
}
