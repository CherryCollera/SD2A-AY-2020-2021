﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Sabado
{
    class Difference
    {
        public double computeDifference()
        {
            return DeclareVar.num1 - DeclareVar.num2;
        }
    }
}
