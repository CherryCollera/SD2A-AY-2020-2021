﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Sabado
{
    class DeclareVar
    {
        public static double num1, num2 = 0;

        public static double Num1
        {
            get { return num1; }
            set { num1 = value; }
        }

        public static double Num2
        {
            get { return num2; }
            set { num2 = value; }
        }
    }
}
