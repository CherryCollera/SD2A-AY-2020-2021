﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample_Sabado
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("Name:		        Zyrille Joy M. Sabado");
            System.Console.WriteLine("Birthday:		November 3, 1999");
            System.Console.WriteLine("Course:	                BS Computer Science Major in Software Development");
            System.Console.WriteLine("Year:			2nd Year");
            System.Console.WriteLine("Section:		SD2A");
            System.Console.ReadLine();
        }
    }
}
