﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample_Sabado
{
    class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            System.Console.WriteLine("Enter your Firstname and Lastname:\t");

            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();
        }

    }
}
