﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample_Sabado
{
    class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept(); //Creating object of 1st class
            a.AcceptDetails();   //executing method of 1st class
            //Printing value of name variable
            System.Console.Write("Hello " + a.firstname + "  " + a.lastname + "!!! \n You have created class in OOP... \n");
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
    }
}
