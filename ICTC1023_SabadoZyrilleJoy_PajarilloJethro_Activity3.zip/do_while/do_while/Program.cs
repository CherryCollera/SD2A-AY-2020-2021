﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] JMP = { 6, 7, 8, 10 };
            int jmp_sum = 0;

            int i = 0;
            do
            {
                jmp_sum += JMP[i];
                i++;
            }
            while (i < JMP.Length);
            Console.Write("Total Sum of the array is " + jmp_sum);
            Console.ReadKey();
        }
    }
}
