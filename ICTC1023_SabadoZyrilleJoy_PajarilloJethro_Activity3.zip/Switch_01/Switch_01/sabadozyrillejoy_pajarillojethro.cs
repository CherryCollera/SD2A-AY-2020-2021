﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_01
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter your Gender (M/F): ");
            char gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {
                case 'M':
                case 'm':
                    Console.WriteLine("Hi " + name + "! your gender is Male!.");
                    break;
                case 'F':
                case 'f':
                    Console.WriteLine("Hi " + name + "! your gender is Female!.");
                    break;
                default:
                    Console.WriteLine("Invalid Input! Please try again! ");
                    break;
            }
            Console.ReadKey();

        }
    }
}
