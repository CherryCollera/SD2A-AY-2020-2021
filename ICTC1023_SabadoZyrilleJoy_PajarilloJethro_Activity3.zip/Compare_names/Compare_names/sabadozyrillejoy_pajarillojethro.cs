﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compare_names
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            Console.Write("Enter first Number: ");
            int fNumber = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second Number: ");
            int sNumber = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third Number: ");
            int tNumber = Convert.ToInt32(Console.ReadLine());

            if (fNumber > sNumber && fNumber > sNumber)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", fNumber, sNumber, tNumber);
                Console.WriteLine("{0} is less than {1}", sNumber, fNumber);
                Console.WriteLine("{0} is less than {1}", tNumber, fNumber);
            }
            else if (sNumber > fNumber && sNumber > tNumber)
            {
                Console.WriteLine("{0} is greater  than {1} and {2}", sNumber, fNumber, tNumber);
                Console.WriteLine("{0} is less than {1}", fNumber, sNumber);
                Console.WriteLine("{0} is less than {1}", tNumber, sNumber);
            }
            else if (tNumber > fNumber && tNumber > sNumber)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", tNumber, sNumber, fNumber);
                Console.WriteLine("{0} is less than {1}", fNumber, tNumber);
                Console.WriteLine("{0} is less than {1}", sNumber, tNumber);
            }
            else if (fNumber == sNumber)
            {
                if (fNumber > tNumber)
                {
                    Console.WriteLine("{0} and {1} is greater than {2}", fNumber, sNumber, tNumber);
                }
                else if (fNumber == tNumber)
                {
                    Console.WriteLine("{0}, {1} and {2} are equal ", fNumber, sNumber, tNumber);
                }
            }
            else if (sNumber == tNumber)
            {
                if (sNumber > fNumber)
                {
                    Console.WriteLine("{0} and {1} is greater than {2}", sNumber, tNumber, fNumber);
                }
                else if (sNumber == fNumber)
                {
                    Console.WriteLine("{0}, {1} and {2} are equal ", fNumber, sNumber, tNumber);
                }
            }
            else if (fNumber == tNumber)
            {
                if (fNumber > sNumber)
                {
                    Console.WriteLine("{0} and {1} is greater than {2}", fNumber, tNumber, sNumber);
                }
                else if (fNumber == tNumber)
                {
                    Console.WriteLine("{0}, {1} and {2} are equal ", fNumber, sNumber, tNumber);
                }
            }
            Console.ReadKey();

        }
    }
}
