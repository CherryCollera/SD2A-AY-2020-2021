﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_loop
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            for (int i = 9; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey(); 
        }
    }
}
