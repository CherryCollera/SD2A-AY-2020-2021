﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grading_system
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            string remarks;
            string gradeequivalent;
            Console.Write("Enter your final grade: ");
            double finalgrade = Convert.ToDouble(Console.ReadLine());

            if (finalgrade >= 98 && finalgrade <= 100)
            {
                remarks = "Excellent";
                gradeequivalent = "1.0";
            }
            else if (finalgrade >= 95 && finalgrade <= 97.99)
            {
                remarks = "Excellent";
                gradeequivalent = "1.25";
            }
            else if (finalgrade >= 92 && finalgrade <= 94.99)
            {
                remarks = "Very Good";
                gradeequivalent = "1.50";
            }
            else if (finalgrade >= 89 && finalgrade <= 91.99)
            {
                remarks = "Very Good";
                gradeequivalent = "1.75";
            }
            else if (finalgrade >= 86 && finalgrade <= 88.99)
            {
                remarks = "Good";
                gradeequivalent = "2.00";
            }
            else if (finalgrade >= 83 && finalgrade <= 85.99)
            {
                remarks = "Good";
                gradeequivalent = "2.25";
            }
            else if (finalgrade >= 80 && finalgrade <= 82.99)
            {
                remarks = "Fair";
                gradeequivalent = "2.50";
            }
            else if (finalgrade >= 77 && finalgrade <= 79.99)
            {
                remarks = "Fair";
                gradeequivalent = "2.75";
            }
            else if (finalgrade >= 75 && finalgrade <= 76.99)
            {
                remarks = "Passed";
                gradeequivalent = "3.00";
            }
            else if (finalgrade >= 72 && finalgrade <= 74.99)
            {
                remarks = "Conditional";
                gradeequivalent = "4.00";
            }
            else if (finalgrade >= 60 && finalgrade <= 71.99)
            {
                remarks = "Failed";
                gradeequivalent = "5.00";
            }
            else
            {
                remarks = "";
                gradeequivalent = "Incomplete";
            }
            Console.WriteLine($"Grade Equivalent: " + gradeequivalent + "\nRemarks: " + remarks);
            Console.ReadKey();
        }
    }
}


            

