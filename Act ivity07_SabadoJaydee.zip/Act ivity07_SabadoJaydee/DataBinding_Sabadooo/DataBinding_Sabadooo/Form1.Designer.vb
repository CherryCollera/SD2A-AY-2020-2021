﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BSCSToolStrip = New System.Windows.Forms.ToolStrip()
        Me.BSCSToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BSITToolStrip = New System.Windows.Forms.ToolStrip()
        Me.BSITToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me._2B_SECTIONToolStrip = New System.Windows.Forms.ToolStrip()
        Me._2B_SECTIONToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ADDRESS_BALANGAToolStrip = New System.Windows.Forms.ToolStrip()
        Me.ADDRESS_BALANGAToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.SECTION_YEAR_ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.SECTION_YEAR_ToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.REFRESHToolStrip = New System.Windows.Forms.ToolStrip()
        Me.REFRESHToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip = New System.Windows.Forms.ToolStrip()
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip = New System.Windows.Forms.ToolStrip()
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.StudIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiddleNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BirthdayDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProgramDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SectionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.YearLevelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblStudentInfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentsDataSet = New DataBinding_Sabadooo.studentsDataSet()
        Me.TblStudent_InfoTableAdapter = New DataBinding_Sabadooo.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BSCSToolStrip.SuspendLayout()
        Me.BSITToolStrip.SuspendLayout()
        Me._2B_SECTIONToolStrip.SuspendLayout()
        Me.ADDRESS_BALANGAToolStrip.SuspendLayout()
        Me.SECTION_YEAR_ToolStrip.SuspendLayout()
        Me.REFRESHToolStrip.SuspendLayout()
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.SuspendLayout()
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.SuspendLayout()
        CType(Me.TblStudentInfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bernard MT Condensed", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Teal
        Me.Label1.Location = New System.Drawing.Point(368, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(719, 95)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "STUDENT INFORMATION"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudIDDataGridViewTextBoxColumn, Me.LastNameDataGridViewTextBoxColumn, Me.FirstNameDataGridViewTextBoxColumn, Me.MiddleNameDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.BirthdayDataGridViewTextBoxColumn, Me.ProgramDataGridViewTextBoxColumn, Me.SectionDataGridViewTextBoxColumn, Me.YearLevelDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TblStudentInfoBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(78, 160)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1434, 240)
        Me.DataGridView1.TabIndex = 1
        '
        'BSCSToolStrip
        '
        Me.BSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.BSCSToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.BSCSToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BSCSToolStripButton})
        Me.BSCSToolStrip.Location = New System.Drawing.Point(122, 441)
        Me.BSCSToolStrip.Name = "BSCSToolStrip"
        Me.BSCSToolStrip.Size = New System.Drawing.Size(104, 39)
        Me.BSCSToolStrip.TabIndex = 2
        Me.BSCSToolStrip.Text = "BSCSToolStrip"
        '
        'BSCSToolStripButton
        '
        Me.BSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.BSCSToolStripButton.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BSCSToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.BSCSToolStripButton.Name = "BSCSToolStripButton"
        Me.BSCSToolStripButton.Size = New System.Drawing.Size(91, 36)
        Me.BSCSToolStripButton.Text = "BSCS"
        '
        'BSITToolStrip
        '
        Me.BSITToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.BSITToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.BSITToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BSITToolStripButton})
        Me.BSITToolStrip.Location = New System.Drawing.Point(299, 441)
        Me.BSITToolStrip.Name = "BSITToolStrip"
        Me.BSITToolStrip.Size = New System.Drawing.Size(96, 39)
        Me.BSITToolStrip.TabIndex = 3
        Me.BSITToolStrip.Text = "BSITToolStrip"
        '
        'BSITToolStripButton
        '
        Me.BSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.BSITToolStripButton.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BSITToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.BSITToolStripButton.Name = "BSITToolStripButton"
        Me.BSITToolStripButton.Size = New System.Drawing.Size(83, 36)
        Me.BSITToolStripButton.Text = "BSIT"
        '
        '_2B_SECTIONToolStrip
        '
        Me._2B_SECTIONToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me._2B_SECTIONToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me._2B_SECTIONToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._2B_SECTIONToolStripButton})
        Me._2B_SECTIONToolStrip.Location = New System.Drawing.Point(485, 441)
        Me._2B_SECTIONToolStrip.Name = "_2B_SECTIONToolStrip"
        Me._2B_SECTIONToolStrip.Size = New System.Drawing.Size(219, 39)
        Me._2B_SECTIONToolStrip.TabIndex = 4
        Me._2B_SECTIONToolStrip.Text = "_2B_SECTIONToolStrip"
        '
        '_2B_SECTIONToolStripButton
        '
        Me._2B_SECTIONToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me._2B_SECTIONToolStripButton.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._2B_SECTIONToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me._2B_SECTIONToolStripButton.Name = "_2B_SECTIONToolStripButton"
        Me._2B_SECTIONToolStripButton.Size = New System.Drawing.Size(206, 36)
        Me._2B_SECTIONToolStripButton.Text = "_2B_SECTION"
        '
        'ADDRESS_BALANGAToolStrip
        '
        Me.ADDRESS_BALANGAToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.ADDRESS_BALANGAToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ADDRESS_BALANGAToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ADDRESS_BALANGAToolStripButton})
        Me.ADDRESS_BALANGAToolStrip.Location = New System.Drawing.Point(802, 441)
        Me.ADDRESS_BALANGAToolStrip.Name = "ADDRESS_BALANGAToolStrip"
        Me.ADDRESS_BALANGAToolStrip.Size = New System.Drawing.Size(318, 39)
        Me.ADDRESS_BALANGAToolStrip.TabIndex = 5
        Me.ADDRESS_BALANGAToolStrip.Text = "ADDRESS_BALANGAToolStrip"
        '
        'ADDRESS_BALANGAToolStripButton
        '
        Me.ADDRESS_BALANGAToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ADDRESS_BALANGAToolStripButton.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDRESS_BALANGAToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.ADDRESS_BALANGAToolStripButton.Name = "ADDRESS_BALANGAToolStripButton"
        Me.ADDRESS_BALANGAToolStripButton.Size = New System.Drawing.Size(305, 36)
        Me.ADDRESS_BALANGAToolStripButton.Text = "ADDRESS_BALANGA"
        '
        'SECTION_YEAR_ToolStrip
        '
        Me.SECTION_YEAR_ToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.SECTION_YEAR_ToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.SECTION_YEAR_ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SECTION_YEAR_ToolStripButton})
        Me.SECTION_YEAR_ToolStrip.Location = New System.Drawing.Point(1185, 441)
        Me.SECTION_YEAR_ToolStrip.Name = "SECTION_YEAR_ToolStrip"
        Me.SECTION_YEAR_ToolStrip.Size = New System.Drawing.Size(265, 39)
        Me.SECTION_YEAR_ToolStrip.TabIndex = 6
        Me.SECTION_YEAR_ToolStrip.Text = "SECTION_YEAR_ToolStrip"
        '
        'SECTION_YEAR_ToolStripButton
        '
        Me.SECTION_YEAR_ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SECTION_YEAR_ToolStripButton.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SECTION_YEAR_ToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.SECTION_YEAR_ToolStripButton.Name = "SECTION_YEAR_ToolStripButton"
        Me.SECTION_YEAR_ToolStripButton.Size = New System.Drawing.Size(252, 36)
        Me.SECTION_YEAR_ToolStripButton.Text = "SECTION_YEAR_"
        '
        'REFRESHToolStrip
        '
        Me.REFRESHToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.REFRESHToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.REFRESHToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REFRESHToolStripButton})
        Me.REFRESHToolStrip.Location = New System.Drawing.Point(702, 610)
        Me.REFRESHToolStrip.Name = "REFRESHToolStrip"
        Me.REFRESHToolStrip.Size = New System.Drawing.Size(166, 39)
        Me.REFRESHToolStrip.TabIndex = 7
        Me.REFRESHToolStrip.Text = "REFRESHToolStrip"
        '
        'REFRESHToolStripButton
        '
        Me.REFRESHToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.REFRESHToolStripButton.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.REFRESHToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.REFRESHToolStripButton.Name = "REFRESHToolStripButton"
        Me.REFRESHToolStripButton.Size = New System.Drawing.Size(153, 36)
        Me.REFRESHToolStripButton.Text = "REFRESH"
        '
        'LASTNAME_START_WITH_LETTER_A_AND_CToolStrip
        '
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton})
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.Location = New System.Drawing.Point(178, 527)
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.Name = "LASTNAME_START_WITH_LETTER_A_AND_CToolStrip"
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.Size = New System.Drawing.Size(555, 33)
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.TabIndex = 8
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.Text = "LASTNAME_START_WITH_LETTER_A_AND_CToolStrip"
        '
        'LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton
        '
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.Name = "LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton"
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.Size = New System.Drawing.Size(542, 30)
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.Text = "LASTNAME_START_WITH_LETTER_A_AND_C"
        '
        'FIRSTNAME_START_WITH_CONSONANTToolStrip
        '
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton})
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.Location = New System.Drawing.Point(877, 527)
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.Name = "FIRSTNAME_START_WITH_CONSONANTToolStrip"
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.Size = New System.Drawing.Size(498, 33)
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.TabIndex = 9
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.Text = "FIRSTNAME_START_WITH_CONSONANTToolStrip"
        '
        'FIRSTNAME_START_WITH_CONSONANTToolStripButton
        '
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton.ForeColor = System.Drawing.Color.Teal
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton.Name = "FIRSTNAME_START_WITH_CONSONANTToolStripButton"
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton.Size = New System.Drawing.Size(485, 30)
        Me.FIRSTNAME_START_WITH_CONSONANTToolStripButton.Text = "FIRSTNAME_START_WITH_CONSONANT"
        '
        'StudIDDataGridViewTextBoxColumn
        '
        Me.StudIDDataGridViewTextBoxColumn.DataPropertyName = "StudID"
        Me.StudIDDataGridViewTextBoxColumn.HeaderText = "StudID"
        Me.StudIDDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.StudIDDataGridViewTextBoxColumn.Name = "StudIDDataGridViewTextBoxColumn"
        Me.StudIDDataGridViewTextBoxColumn.Width = 125
        '
        'LastNameDataGridViewTextBoxColumn
        '
        Me.LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.LastNameDataGridViewTextBoxColumn.Name = "LastNameDataGridViewTextBoxColumn"
        Me.LastNameDataGridViewTextBoxColumn.Width = 125
        '
        'FirstNameDataGridViewTextBoxColumn
        '
        Me.FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FirstNameDataGridViewTextBoxColumn.Name = "FirstNameDataGridViewTextBoxColumn"
        Me.FirstNameDataGridViewTextBoxColumn.Width = 125
        '
        'MiddleNameDataGridViewTextBoxColumn
        '
        Me.MiddleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName"
        Me.MiddleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName"
        Me.MiddleNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.MiddleNameDataGridViewTextBoxColumn.Name = "MiddleNameDataGridViewTextBoxColumn"
        Me.MiddleNameDataGridViewTextBoxColumn.Width = 125
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        Me.AddressDataGridViewTextBoxColumn.Width = 125
        '
        'BirthdayDataGridViewTextBoxColumn
        '
        Me.BirthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday"
        Me.BirthdayDataGridViewTextBoxColumn.HeaderText = "Birthday"
        Me.BirthdayDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BirthdayDataGridViewTextBoxColumn.Name = "BirthdayDataGridViewTextBoxColumn"
        Me.BirthdayDataGridViewTextBoxColumn.Width = 125
        '
        'ProgramDataGridViewTextBoxColumn
        '
        Me.ProgramDataGridViewTextBoxColumn.DataPropertyName = "Program"
        Me.ProgramDataGridViewTextBoxColumn.HeaderText = "Program"
        Me.ProgramDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.ProgramDataGridViewTextBoxColumn.Name = "ProgramDataGridViewTextBoxColumn"
        Me.ProgramDataGridViewTextBoxColumn.Width = 125
        '
        'SectionDataGridViewTextBoxColumn
        '
        Me.SectionDataGridViewTextBoxColumn.DataPropertyName = "Section"
        Me.SectionDataGridViewTextBoxColumn.HeaderText = "Section"
        Me.SectionDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.SectionDataGridViewTextBoxColumn.Name = "SectionDataGridViewTextBoxColumn"
        Me.SectionDataGridViewTextBoxColumn.Width = 125
        '
        'YearLevelDataGridViewTextBoxColumn
        '
        Me.YearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel"
        Me.YearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel"
        Me.YearLevelDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.YearLevelDataGridViewTextBoxColumn.Name = "YearLevelDataGridViewTextBoxColumn"
        Me.YearLevelDataGridViewTextBoxColumn.Width = 125
        '
        'TblStudentInfoBindingSource
        '
        Me.TblStudentInfoBindingSource.DataMember = "tblStudent_Info"
        Me.TblStudentInfoBindingSource.DataSource = Me.StudentsDataSet
        '
        'StudentsDataSet
        '
        Me.StudentsDataSet.DataSetName = "studentsDataSet"
        Me.StudentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblStudent_InfoTableAdapter
        '
        Me.TblStudent_InfoTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataBinding_Sabadooo.My.Resources.Resources._831632
        Me.ClientSize = New System.Drawing.Size(1547, 729)
        Me.Controls.Add(Me.FIRSTNAME_START_WITH_CONSONANTToolStrip)
        Me.Controls.Add(Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip)
        Me.Controls.Add(Me.REFRESHToolStrip)
        Me.Controls.Add(Me.SECTION_YEAR_ToolStrip)
        Me.Controls.Add(Me.ADDRESS_BALANGAToolStrip)
        Me.Controls.Add(Me._2B_SECTIONToolStrip)
        Me.Controls.Add(Me.BSITToolStrip)
        Me.Controls.Add(Me.BSCSToolStrip)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BSCSToolStrip.ResumeLayout(False)
        Me.BSCSToolStrip.PerformLayout()
        Me.BSITToolStrip.ResumeLayout(False)
        Me.BSITToolStrip.PerformLayout()
        Me._2B_SECTIONToolStrip.ResumeLayout(False)
        Me._2B_SECTIONToolStrip.PerformLayout()
        Me.ADDRESS_BALANGAToolStrip.ResumeLayout(False)
        Me.ADDRESS_BALANGAToolStrip.PerformLayout()
        Me.SECTION_YEAR_ToolStrip.ResumeLayout(False)
        Me.SECTION_YEAR_ToolStrip.PerformLayout()
        Me.REFRESHToolStrip.ResumeLayout(False)
        Me.REFRESHToolStrip.PerformLayout()
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.ResumeLayout(False)
        Me.LASTNAME_START_WITH_LETTER_A_AND_CToolStrip.PerformLayout()
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.ResumeLayout(False)
        Me.FIRSTNAME_START_WITH_CONSONANTToolStrip.PerformLayout()
        CType(Me.TblStudentInfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents StudentsDataSet As studentsDataSet
    Friend WithEvents TblStudentInfoBindingSource As BindingSource
    Friend WithEvents TblStudent_InfoTableAdapter As studentsDataSetTableAdapters.tblStudent_InfoTableAdapter
    Friend WithEvents StudIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MiddleNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BirthdayDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ProgramDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SectionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents YearLevelDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BSCSToolStrip As ToolStrip
    Friend WithEvents BSCSToolStripButton As ToolStripButton
    Friend WithEvents BSITToolStrip As ToolStrip
    Friend WithEvents BSITToolStripButton As ToolStripButton
    Friend WithEvents _2B_SECTIONToolStrip As ToolStrip
    Friend WithEvents _2B_SECTIONToolStripButton As ToolStripButton
    Friend WithEvents ADDRESS_BALANGAToolStrip As ToolStrip
    Friend WithEvents ADDRESS_BALANGAToolStripButton As ToolStripButton
    Friend WithEvents SECTION_YEAR_ToolStrip As ToolStrip
    Friend WithEvents SECTION_YEAR_ToolStripButton As ToolStripButton
    Friend WithEvents REFRESHToolStrip As ToolStrip
    Friend WithEvents REFRESHToolStripButton As ToolStripButton
    Friend WithEvents LASTNAME_START_WITH_LETTER_A_AND_CToolStrip As ToolStrip
    Friend WithEvents LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton As ToolStripButton
    Friend WithEvents FIRSTNAME_START_WITH_CONSONANTToolStrip As ToolStrip
    Friend WithEvents FIRSTNAME_START_WITH_CONSONANTToolStripButton As ToolStripButton
End Class
