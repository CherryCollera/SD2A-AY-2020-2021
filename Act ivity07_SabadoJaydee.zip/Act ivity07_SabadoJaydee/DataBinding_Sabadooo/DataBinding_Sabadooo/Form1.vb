﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StudentsDataSet.tblStudent_Info' table. You can move, or remove it, as needed.
        Me.TblStudent_InfoTableAdapter.Fill(Me.StudentsDataSet.tblStudent_Info)

    End Sub

    Private Sub BSCSToolStripButton_Click(sender As Object, e As EventArgs) Handles BSCSToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.BSCS(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BSCSToolStrip_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles BSCSToolStrip.ItemClicked



    End Sub

    Private Sub BSITToolStripButton_Click(sender As Object, e As EventArgs) Handles BSITToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.BSIT(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub _2B_SECTIONToolStripButton_Click(sender As Object, e As EventArgs) Handles _2B_SECTIONToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter._2B_SECTION(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub ADDRESS_BALANGAToolStripButton_Click(sender As Object, e As EventArgs) Handles ADDRESS_BALANGAToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.ADDRESS_BALANGA(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub SECTION_YEAR_ToolStripButton_Click(sender As Object, e As EventArgs) Handles SECTION_YEAR_ToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.SECTION_YEAR_(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub REFRESHToolStripButton_Click(sender As Object, e As EventArgs) Handles REFRESHToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.REFRESH(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton_Click(sender As Object, e As EventArgs) Handles LASTNAME_START_WITH_LETTER_A_AND_CToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.LASTNAME_START_WITH_LETTER_A_AND_C(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub FIRSTNAME_START_WITH_CONSONANTToolStripButton_Click(sender As Object, e As EventArgs) Handles FIRSTNAME_START_WITH_CONSONANTToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.FIRSTNAME_START_WITH_CONSONANT(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
