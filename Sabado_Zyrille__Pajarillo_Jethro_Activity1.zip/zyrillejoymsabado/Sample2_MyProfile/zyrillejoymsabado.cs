﻿using System;

namespace Sample2_MyProfile
{
    /* 
     * student ID no. 19-04483 
     * student's full name: Sabado, Zyrille Joy Miguel 
     * section:BSCS SD2A
     * Date: February 28,2021
     * 
     * Student ID no. 19-05775
     * student's full name: Pajarillo, Jethro M.
     * section: BSCS SD2A
     * 
     * it contains my basic information
     */
    class zyrillejoymsabado
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Zyrille Joy M. Sabado \n \n" +
                "Date of Birth: November 03 1999 \n \n" + 
                "Course: BS Computer Science Major in Software Development \n  \n" + 
                "Year & Section: 2A \n \n ");

            Console.WriteLine("Name: Jethro M. Pajarillo  \n \n" +
                "Date of Birth: March 4,2001 \n \n" +
                "Course: BS Computer Science Major in Software Development \n \n" +
                "Year & Section: 2A");
        }
    }
}
