﻿
namespace WinFormsApp3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.BtnInteger = new System.Windows.Forms.Button();
            this.BtnFloat = new System.Windows.Forms.Button();
            this.BtnDouble = new System.Windows.Forms.Button();
            this.BtnSum = new System.Windows.Forms.Button();
            this.fnum = new System.Windows.Forms.Label();
            this.snum = new System.Windows.Forms.Label();
            this.txtBox1 = new System.Windows.Forms.TextBox();
            this.txtBox2 = new System.Windows.Forms.TextBox();
            this.clearform3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnInteger
            // 
            this.BtnInteger.BackColor = System.Drawing.Color.Gray;
            this.BtnInteger.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BtnInteger.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnInteger.Location = new System.Drawing.Point(49, 82);
            this.BtnInteger.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnInteger.Name = "BtnInteger";
            this.BtnInteger.Size = new System.Drawing.Size(157, 44);
            this.BtnInteger.TabIndex = 0;
            this.BtnInteger.Text = "Integer";
            this.BtnInteger.UseVisualStyleBackColor = false;
            this.BtnInteger.Click += new System.EventHandler(this.BtnInteger_Click);
            // 
            // BtnFloat
            // 
            this.BtnFloat.BackColor = System.Drawing.Color.Gray;
            this.BtnFloat.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BtnFloat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnFloat.Location = new System.Drawing.Point(304, 82);
            this.BtnFloat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnFloat.Name = "BtnFloat";
            this.BtnFloat.Size = new System.Drawing.Size(157, 49);
            this.BtnFloat.TabIndex = 1;
            this.BtnFloat.Text = "Float";
            this.BtnFloat.UseVisualStyleBackColor = false;
            this.BtnFloat.Click += new System.EventHandler(this.BtnFloat_Click);
            // 
            // BtnDouble
            // 
            this.BtnDouble.BackColor = System.Drawing.Color.Gray;
            this.BtnDouble.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BtnDouble.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnDouble.Location = new System.Drawing.Point(545, 84);
            this.BtnDouble.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnDouble.Name = "BtnDouble";
            this.BtnDouble.Size = new System.Drawing.Size(157, 44);
            this.BtnDouble.TabIndex = 2;
            this.BtnDouble.Text = "Double";
            this.BtnDouble.UseVisualStyleBackColor = false;
            this.BtnDouble.Click += new System.EventHandler(this.BtnDouble_Click);
            // 
            // BtnSum
            // 
            this.BtnSum.BackColor = System.Drawing.Color.Gray;
            this.BtnSum.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BtnSum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnSum.Location = new System.Drawing.Point(295, 312);
            this.BtnSum.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnSum.Name = "BtnSum";
            this.BtnSum.Size = new System.Drawing.Size(157, 44);
            this.BtnSum.TabIndex = 3;
            this.BtnSum.Text = "Compute Sum";
            this.BtnSum.UseVisualStyleBackColor = false;
            this.BtnSum.Click += new System.EventHandler(this.BtnSum_Click);
            // 
            // fnum
            // 
            this.fnum.AutoSize = true;
            this.fnum.BackColor = System.Drawing.Color.Transparent;
            this.fnum.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.fnum.Location = new System.Drawing.Point(20, 189);
            this.fnum.Name = "fnum";
            this.fnum.Size = new System.Drawing.Size(157, 20);
            this.fnum.TabIndex = 4;
            this.fnum.Text = "Enter first number:";
            // 
            // snum
            // 
            this.snum.AutoSize = true;
            this.snum.BackColor = System.Drawing.Color.Transparent;
            this.snum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.snum.Location = new System.Drawing.Point(355, 189);
            this.snum.Name = "snum";
            this.snum.Size = new System.Drawing.Size(195, 23);
            this.snum.TabIndex = 5;
            this.snum.Text = "Enter second number:";
            // 
            // txtBox1
            // 
            this.txtBox1.Location = new System.Drawing.Point(183, 186);
            this.txtBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBox1.Name = "txtBox1";
            this.txtBox1.Size = new System.Drawing.Size(158, 27);
            this.txtBox1.TabIndex = 6;
            this.txtBox1.TextChanged += new System.EventHandler(this.txtBox1_TextChanged);
            // 
            // txtBox2
            // 
            this.txtBox2.Location = new System.Drawing.Point(556, 186);
            this.txtBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBox2.Name = "txtBox2";
            this.txtBox2.Size = new System.Drawing.Size(146, 27);
            this.txtBox2.TabIndex = 7;
            this.txtBox2.TextChanged += new System.EventHandler(this.txtBox2_TextChanged);
            // 
            // clearform3
            // 
            this.clearform3.BackColor = System.Drawing.Color.Gray;
            this.clearform3.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.clearform3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.clearform3.Location = new System.Drawing.Point(295, 260);
            this.clearform3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.clearform3.Name = "clearform3";
            this.clearform3.Size = new System.Drawing.Size(157, 44);
            this.clearform3.TabIndex = 8;
            this.clearform3.Text = "Clear";
            this.clearform3.UseVisualStyleBackColor = false;
            this.clearform3.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(724, 407);
            this.Controls.Add(this.clearform3);
            this.Controls.Add(this.txtBox2);
            this.Controls.Add(this.txtBox1);
            this.Controls.Add(this.snum);
            this.Controls.Add(this.fnum);
            this.Controls.Add(this.BtnSum);
            this.Controls.Add(this.BtnDouble);
            this.Controls.Add(this.BtnFloat);
            this.Controls.Add(this.BtnInteger);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnInteger;
        private System.Windows.Forms.Button BtnFloat;
        private System.Windows.Forms.Button BtnDouble;
        private System.Windows.Forms.Button BtnSum;
        private System.Windows.Forms.Label fnum;
        private System.Windows.Forms.Label snum;
        private System.Windows.Forms.TextBox txtBox1;
        private System.Windows.Forms.TextBox txtBox2;
        private System.Windows.Forms.Button clearform3;
    }
}