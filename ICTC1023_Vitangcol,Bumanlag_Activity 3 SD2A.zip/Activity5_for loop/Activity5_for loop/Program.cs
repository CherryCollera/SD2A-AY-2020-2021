﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--) //ACTIVITY 5 FOR LOOP
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
