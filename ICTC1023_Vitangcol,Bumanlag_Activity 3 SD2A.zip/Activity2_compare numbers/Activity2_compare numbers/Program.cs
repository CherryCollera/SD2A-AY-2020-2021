﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int ADB06_num1, ADB06_num2, ADB06_num3;
            Console.Write("Enter first number: ");
            ADB06_num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            ADB06_num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number: ");
            ADB06_num3 = Convert.ToInt32(Console.ReadLine());
            if (ADB06_num1 > ADB06_num2 && ADB06_num1 > ADB06_num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", ADB06_num1, ADB06_num2, ADB06_num3);
                Console.WriteLine("{0} is less than {1}", ADB06_num2, ADB06_num1);
                Console.WriteLine("{0} is less than {1}", ADB06_num3, ADB06_num1);
            }
            else if (ADB06_num2 > ADB06_num1 && ADB06_num2 > ADB06_num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", ADB06_num2, ADB06_num1, ADB06_num3);
                Console.WriteLine("{0} is less than {1}", ADB06_num1, ADB06_num2);
                Console.WriteLine("{0} is less than {1}", ADB06_num3, ADB06_num2);
            }

            else if (ADB06_num3 > ADB06_num1 && ADB06_num3 > ADB06_num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", ADB06_num3, ADB06_num1, ADB06_num2);
                Console.WriteLine("{0} is less than {1}", ADB06_num1, ADB06_num3);
                Console.WriteLine("{0} is less than {1}", ADB06_num2, ADB06_num3);
            }
            else if (ADB06_num1 == ADB06_num2 && ADB06_num1 == ADB06_num3)
            {
                Console.WriteLine("{0} {1} and {2} are equal", ADB06_num1, ADB06_num2, ADB06_num3);
            }
            else if (ADB06_num1 == ADB06_num2)
            {
                Console.WriteLine("{0} and {1} are equal", ADB06_num1, ADB06_num2);
                Console.WriteLine("{0} is less than {1}", ADB06_num3, ADB06_num1);
            }
            else if (ADB06_num1 == ADB06_num3)
            {
                Console.WriteLine("{0} and {1} are equal", ADB06_num1, ADB06_num3);
                Console.WriteLine("{0} is less than {1}", ADB06_num2, ADB06_num1);
            }
            else
            {
                Console.WriteLine("{0} and {1} are equal", ADB06_num2, ADB06_num3);
                Console.WriteLine("{0} and {1} are equal", ADB06_num1, ADB06_num2);
            }
            Console.ReadKey();
        }
    }
    }
