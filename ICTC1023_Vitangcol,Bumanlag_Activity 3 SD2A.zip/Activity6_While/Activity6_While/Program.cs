﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0; //ACTIVITY 6 WHILE
            while (i < 10)
            {
                Console.WriteLine("While Statement ");
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
