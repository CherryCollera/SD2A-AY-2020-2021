﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] ADB06_nms = new int[] { 6, 7, 8, 10 }; //ACTIVITY 7 DO-WHILE
            int ADB06_sum = 0;
            int i = 0;
            do
            {
                ADB06_sum += ADB06_nms[i];
                i++;
            } while (i < 4);
            Console.WriteLine(ADB06_sum);
            Console.ReadKey(); */
        }
    }
}
