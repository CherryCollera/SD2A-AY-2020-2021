﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            char gender;
            string name;
            Console.Write("Enter your Name: ");
            name = Console.ReadLine();
            Console.Write("Enter your Gender M/F: ");
            gender = Convert.ToChar(Console.ReadLine());
            switch (gender)
            {
                case 'M':
                case 'm':
                    Console.WriteLine("\nHi " + name + "! " + "Your Gender is Male!");
                    break;
                case 'F':
                case 'f':
                    Console.WriteLine("\nHi " + name + "! " + "Your Gender is Female");
                    break;
                default:
                    Console.WriteLine("\nInvalid Input... Try Again...");
                    break;
            }
            Console.ReadKey();
        }
    }
}
