﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1;

            Console.Write("Enter your Grade: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            if (num1 > 100)
            {
                Console.WriteLine("Please Try Again");
            }
            else if (num1 >= 98 && num1 <= 100)
            {
                Console.WriteLine("Grade Equivalent : 1.00");
                Console.WriteLine("Remarks: Excellent");
            }
            else if (num1 >= 95 && num1 <= 97)
            {
                Console.WriteLine("Grade Equivalent : 1.25");
                Console.WriteLine("Remarks: Excellent");
            }
            else if (num1 >= 92 && num1 <= 94)
            {
                Console.WriteLine("Grade Equivalent : 1.50");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (num1 >= 89 && num1 <= 91)
            {
                Console.WriteLine("Grade Equivalent : 1.75");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (num1 >= 86 && num1 <= 88)
            {
                Console.WriteLine("Grade Equivalent : 2.00");
                Console.WriteLine("Remarks: Good");
            }
            else if (num1 >= 83 && num1 <= 85)
            {
                Console.WriteLine("Grade Equivalent : 2.25");
                Console.WriteLine("Remarks: Good");
            }
            else if (num1 >= 80 && num1 <= 82)
            {
                Console.WriteLine("Grade Equivalent : 2.50");
                Console.WriteLine("Remarks: Fair");
            }
            else if (num1 >= 77 && num1 <= 79)
            {
                Console.WriteLine("Grade Equivalent : 2.75");
                Console.WriteLine("Remarks: Passed");
            }
            else if (num1 >= 75 && num1 <= 76)
            {
                Console.WriteLine("Grade Equivalent : 3.00");
                Console.WriteLine("Remarks: Passed");
            }
            else if (num1 >= 72 && num1 <= 74)
            {
                Console.WriteLine("Grade Equivalent : 4.00");
                Console.WriteLine("Remarks: Conditional (MT Only)");
            }
            else if (num1 >= 60 && num1 <= 71)
            {
                Console.WriteLine("Grade Equivalent : 5.00");
                Console.WriteLine("Remarks: Failed");
            }
            else
            {
                Console.WriteLine("Incomplete");
            }
        }
    }
}
