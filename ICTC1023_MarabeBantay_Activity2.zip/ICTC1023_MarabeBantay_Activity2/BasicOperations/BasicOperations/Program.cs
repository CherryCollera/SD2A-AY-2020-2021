﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 08, 2021
 * This program will compute the basic operations such as Sum, Difference, Product, Quitient, and Remainder
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Double num1, num2;

            Console.Write("\nEnter the first number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\nSum = {0}.", num1 + num2);
            Console.WriteLine("Difference = {0}.", num1 - num2);
            Console.WriteLine("Product = {0}.", num1 * num2);
            Console.WriteLine("Quotient = {0:0.0}.", num1/num2);
            Console.WriteLine("Remainder = {0}.", num1 % num2);

            Console.ReadLine();
        }
    }
}
