﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 08, 2021
 * This program will compute the sum using data type Double
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputeTheSumOfDouble
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\nThe Sum of the two numbers is: {0}", num1 + num2);
            Console.ReadLine();
        }
    }
}
