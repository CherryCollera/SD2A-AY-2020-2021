﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 08, 2021
 * This program will Declare Constants
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclaringConstants
{
    class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double AreaCircle, Radius;

            Console.Write("Enter Radius: ");
            Radius = Convert.ToDouble(Console.ReadLine());
            AreaCircle = pi * Radius * Radius;
            Console.Write("Radius: {0:0.0000}, Area: {1:0.0000} ", Radius, AreaCircle);
            Console.ReadLine();
        }
    }
}
