﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 08, 2021
 * This program will compute average
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputeAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            double grade1, grade2, grade3, grade4, grade5;

            Console.WriteLine("Enter 5 grades: ");
            grade1 = Convert.ToDouble(Console.ReadLine());
            grade2 = Convert.ToDouble(Console.ReadLine());
            grade3 = Convert.ToDouble(Console.ReadLine());
            grade4 = Convert.ToDouble(Console.ReadLine());
            grade5 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("The average is {0:0.000}.", (grade1 + grade2 + grade3 + grade4 + grade5) / 5);
            Console.ReadLine();
        }
    }
}
