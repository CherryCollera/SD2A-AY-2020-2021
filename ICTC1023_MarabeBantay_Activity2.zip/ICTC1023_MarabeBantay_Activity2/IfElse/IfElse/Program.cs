﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 08, 2021
 * This program will display the largest number using if else
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            double n1, n2, n3;
            Console.Write("Enter first number: ");
            n1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter second number: ");
            n2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter third number: ");
            n3 = Convert.ToDouble(Console.ReadLine());

            if (n1 > n2 & n1 > n3){
                Console.WriteLine("\n{0} is greater than {1} and {2}", n1, n2, n3);

            }else if (n2 > n1 & n2 > n3){
                Console.WriteLine("\n{1} is greater than {0} and {2}", n1, n2, n3);

            }else if (n3 > n1 & n3 > n2){
                Console.WriteLine("\n{3} is greater than {1} and {2}", n1, n2, n3);

            }else{
                Console.WriteLine("\n{0} is equal to {1} and {2}", n1, n2, n3);

            }
            Console.ReadLine();
        }
    }
}
