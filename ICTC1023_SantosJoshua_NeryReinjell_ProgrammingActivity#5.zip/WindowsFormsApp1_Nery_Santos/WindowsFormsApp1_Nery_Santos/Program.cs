﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 29, 2021*/
using System;
using System.Windows.Forms;

namespace WindowsFormsApp1_Nery_Santos
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
