﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Nery_Santos
{
    public partial class Form4 : Form
    {
        double a, b;
        public Form4()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            AnsBox.Text = (a + b).ToString();
        }

        private void Product_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            AnsBox.Text = (a * b).ToString();
        }

        private void Diff_Click_1(object sender, EventArgs e)
        {
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            AnsBox.Text = (a - b).ToString();
        }

        private void Divide_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            AnsBox.Text = (a / b).ToString();
        }


    }
}
