﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Nery_Santos
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Gpbutton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t     Hello "+textBox1.Text+" "+textBox2.Text+
                "\nDate of Birth\t:\tJune 6, 2001 \nCourse\t\t:\tBS ComSci"+
                "\nYear\t\t:\tII\nSection\t\t:\tA");
        }

        private void Bbutton_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }

        private void Hbutton_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }
    }
}
