﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Nery_Santos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Getbutton_Click(object sender, EventArgs e)
        {
            HappyBirthday hb = new HappyBirthday();
            MessageBox.Show(hb.GetMessage(textBox1.Text + " " + textBox2.Text));
            this.Close();
        }

        private void Hidebutton_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
    }
}
