﻿using System;

namespace ClassExample1_DeLeon
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }

    class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept();
            a.AcceptDetails();

            Console.WriteLine("\nHello " + a.FirstName + " " + a.LastName);
            Console.WriteLine("You Have Created Classes in OOP\n");

            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
    }

    class Accept
    {
        public string FirstName, LastName;

        public void AcceptDetails()
        {
            Console.Write("Enter Your First Name: ");
            FirstName = Console.ReadLine();
            Console.Write("Enter Your Last Name: ");
            LastName = Console.ReadLine();
        }
    }

    class MyProfile
    {
        public void DisplayProfile()
        {
            Console.WriteLine("\t\t  P R O F I L E");
            Console.WriteLine("Name\t\t: Ralph De Leon");
            Console.WriteLine("Date of Birth\t: June 16, 2001");
            Console.WriteLine("Course\t\t: BS in Computer Science Major in Software Development");
            Console.WriteLine("Year\t\t: 2nd Year");
            Console.WriteLine("Section\t\t: SD2A");
        }
    }


}
