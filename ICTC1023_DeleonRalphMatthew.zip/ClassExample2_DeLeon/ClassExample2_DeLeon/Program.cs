﻿using System;

namespace ClassExample2_DeLeon
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe());
            car = new Car("Green");
            Console.WriteLine(car.Describe());
        }
    }

    class Car
    {
        private string Color;

        public Car(String Color)
        {
            this.Color = Color;
        }

        public string Describe()
        {
            return "This car is " + Color;
        }
    }
}
