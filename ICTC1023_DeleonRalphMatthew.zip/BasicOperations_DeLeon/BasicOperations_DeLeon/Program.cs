﻿using System;

namespace BasicOperations_DeLeon
{
    class Program
    {
        static void Main(string[] args)
        {
            DeclareVar x = new DeclareVar();
            x.num1 = Input.AcceptNum();
            x.num2 = Input.AcceptNum();

            Console.WriteLine("\nSum: {0}", Sum.SumOf(x.num1, x.num2));
            Console.WriteLine("Diff: {0}", Difference.DiffOf(x.num1, x.num2));
            Console.WriteLine("Prouct: {0}", Product.ProductOf(x.num1, x.num2));
            Console.WriteLine("Quotient: {0}", Quotient.QuotientOf(x.num1, x.num2));
            Console.WriteLine("Remainder: {0}", Remainder.RemainderOf(x.num1, x.num2));
        }
    }

    class DeclareVar
    {
        public double num1, num2;
    }
    
    static class Input
    {
        public static double AcceptNum()
        {
            Console.Write("Enter Num: ");
            return Convert.ToDouble(Console.ReadLine());
        }
    }

    static class Sum
    {
        public static double SumOf(double num1, double num2)
        {
            return num1 + num2;
        }
    }

    static class Difference
    {
        public static double DiffOf(double num1, double num2)
        {
            return num1 - num2;
        }
    }

    static class Product
    {
        public static double ProductOf(double num1, double num2)
        {
            return num1 * num2;
        }
    }

    static class Quotient
    {
        public static double QuotientOf(double num1, double num2)
        {
            return num1 / num2;
        }
    }

    static class Remainder
    {
        public static double RemainderOf(double num1, double num2)
        {
            return num1 % num2;
        }
    }
}
