﻿using System;

namespace Activity3
{ 

    class Human
    {
        private string FullName;

        public string Fullname
        {
            get { return FullName;}
            set { FullName = value;}
        }

        //Welcome 
        public void Welcome()
        {
            Console.Write("\n \n Hello " + FullName + "!!!:) \n Welcome to OOP environment");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();

            Console.WriteLine("Enter your Full Name (firstname & lastname)");

          
            obj.Fullname = Console.ReadLine();

            obj.Welcome();

            Console.ReadKey();



        }
    }
}

