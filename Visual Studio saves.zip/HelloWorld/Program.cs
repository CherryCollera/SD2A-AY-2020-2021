﻿using System;

namespace HelloWorld

    /*Group*/
    /* Vergara, Darry Dominique S.
       Diamse, Jv C.*/
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();

        }
    }
}
