﻿using System;

namespace Act2_Personal_Information
    /* Group */
    /* Vergara, Darry Domonique S.
       Diamse, Jv C. */
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Student ID: 19-05452 \n");
            Console.WriteLine("Name: Vergara, Darry Dominique S.\n ");
            Console.WriteLine("Date of Birth: August, 31, 2001 \n");
            Console.WriteLine("Course: Bachelor of Science Computer Science Major in Software Development \n"); 
            Console.WriteLine("Year: II \n "); 
            Console.WriteLine("Section: BSCS - SD2A \n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");

            Console.WriteLine("Student ID: 19-05630 \n");
            Console.WriteLine("Name: Diamse, Jv C. \n"); 
            Console.WriteLine("Date of Birth: June, 15, 2001 \n"); 
            Console.WriteLine("Course: Bachelor of Science Computer Science Major in Software Development \n"); 
            Console.WriteLine("Year: II \n"); 
            Console.WriteLine("Section: BSCS - SD2A \n");
            Console.ReadKey();
        }
    }
}
