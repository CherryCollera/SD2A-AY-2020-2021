﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example1
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;

        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void BtnDot_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnDot.Text;
        }

        private void BtnOne_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnOne.Text;
        }

        private void BtnTwo_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnTwo.Text;
        }

        private void BtnThree_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnThree.Text;
        }

        private void BtnFour_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnFour.Text;
        }

        private void BtnFive_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnFive.Text;
        }

        private void BtnSix_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnSix.Text;
        }

        private void BtnSeven_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnSeven.Text;
        }

        private void BtnEight_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnEight.Text;
        }

        private void BtnNine_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnNine.Text;
        }

        private void BtnZero_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnZero.Text;
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            var input = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);
            if (input == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();  
        }

        private void BtnSum_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            plusButtonClicked = true;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            plusButtonClicked = false;
            minusButtonClicked = true;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void BtnProduct_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            multiplyButtonClicked = true;
            divideButtonClicked = false;
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            multiplyButtonClicked = false;
            divideButtonClicked = true;

        }
        private void BtnEquals_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)
            {
                total2 = total1 + double.Parse(textBox1.Text);
            }
            else if (minusButtonClicked == true)
            {
                total2 = total1 - double.Parse(textBox1.Text);
            }
            else if (multiplyButtonClicked == true)
            {
                total2 = total1 * double.Parse(textBox1.Text);
            }
            else if (divideButtonClicked == true)
            {
                total2 = total1 / double.Parse(textBox1.Text);
            }
            textBox1.Text = total2.ToString(); 
            total1 = 0;
        }

        private void BtnForm1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void BtnForm2_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
    }
}
