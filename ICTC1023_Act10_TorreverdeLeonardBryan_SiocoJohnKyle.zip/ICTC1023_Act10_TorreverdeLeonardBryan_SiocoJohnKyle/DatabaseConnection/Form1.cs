﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DatabaseConnection
{
    public partial class Form1 : Form
    {
        private OleDbConnection DBConnection;
        private OleDbCommand DBCommand = new OleDbCommand();
        //3 Connection String
        private String DBParameter = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\book3.accdb";
        //private String Parameter = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\book3.mdb";

        public Form1()
        {
            //Creating connection using paramater from udl
            DBConnection = new OleDbConnection(DBParameter);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DBConnection.Open();
            DBCommand.Connection = DBConnection;
            //retrieve  data from the database using sql command
            DBCommand.CommandText = "Insert into bookrecords (booktitle, description)" + " values ('" + this.txtBookTitle.Text
                                    + "' , '" + this.txtDesc.Text + "');";

            int temp = DBCommand.ExecuteNonQuery();
            if (temp > 0)
            {
                txtBookTitle.Text = null;
                txtDesc.Text = null;
                MessageBox.Show("Successfully Added");
            }
            else
            {
                MessageBox.Show("Please Try Again");
            }

            DBConnection.Close();
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter("SELECT * FROM bookrecords", DBParameter);
            OleDbDataAdapter dbAdapter2 = new OleDbDataAdapter("SELECT * FROM bookrecords", DBParameter);
            OleDbCommandBuilder dbBuilder= new OleDbCommandBuilder(dbAdapter1);

            DataTable dataTable = new DataTable();
            DataSet dataSet = new DataSet();

            dbAdapter1.Fill(dataTable);
            
            for(int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1]);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(rowIndex);
        }
    }
}
