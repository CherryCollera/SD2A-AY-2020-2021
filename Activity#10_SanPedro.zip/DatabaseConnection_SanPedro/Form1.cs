﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DatabaseConnection_SanPedro
{
    // Delete Button Starts at line 99
    public partial class Form1 : Form
    {
        private static OleDbConnection conn;
        private static OleDbCommand command = new OleDbCommand();
        private static String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;
                        Data Source=C:\Users\KN Tech\source\repos\DatabaseConnection_SanPedro\book3.accdb";
        private static String connParam1 = @"Provider=Microsoft.ACE.OLEDB.12.0;
                        Data Source=C:\Users\KN Tech\OneDrive\Documents\SD2AB_SecondSem\OOP SD2A\book3.accdb";
        public Form1()
        {
            conn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);
        }
        private void AddBtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            command.Connection = conn;
            command.CommandText = "INSERT INTO BOOKRECORDS (booktitle, description)" 
                + " values ('" + this.BookTitleTxtBox.Text + "' , '" + this.DescriptionTxtBox.Text + "')";

            int temp = command.ExecuteNonQuery();
            if (temp > 0 && BookTitleTxtBox.Text != "" && DescriptionTxtBox.Text != "")
            {
                BookTitleTxtBox.Text = null;
                DescriptionTxtBox.Text = null;
                MessageBox.Show("Record Successfully Added");
            }
            else
            {
                MessageBox.Show("Failed to Add a Record");
            }

            conn.Close();
        }
        private void ShowAllBtn_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter Adapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter Adapter1 = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam1);
            OleDbCommandBuilder commBuilder = new OleDbCommandBuilder(Adapter);

            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            Adapter.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
                dataGridView1.Rows.Add(dt.Rows[i][0], dt.Rows[i][1]);
        }
        private void showAllToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.bookrecordsTableAdapter.ShowAll(this.book3DataSet.bookrecords);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
        /*  Delete Button
         *  1. Get the selected "item"/row in the datagridview table.
         *  2. Remove the selected item by using the selected items' index.
         *  3. Initialize string called BookTitle to save the "Book Title".
         *  4. Open Connection and link connection with database.
         *  5. Create a command text where: if BookTitle is equal to a specific title in the database,
         *     then delete that record.
         *  6. If the command.ExecuteNonQuery() returns greater than 0 and the text box was not null,
         *     then the record was deleted successfuly and prompt out a message box.
         *  7. Otherwise, something went wrong: either there are no titles equal to BookTitle or the
         *     text box was nulll;
         *  8. Close connection.
         */
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.RemoveAt(item.Index);
            }

            String BookTitle = ToDeleteTxtBox.Text;

            conn.Open();
            command.Connection = conn;
            command.CommandText = "DELETE * FROM bookrecords WHERE booktitle = '" + BookTitle + "'";
            int temp = command.ExecuteNonQuery();

            if (temp > 0 && ToDeleteTxtBox.Text != "")
            {
                ToDeleteTxtBox.Text = null;
                MessageBox.Show("Record Successfully Deleted");
            }
            else
            {
                MessageBox.Show("Failed to Delete a Record");
            }

            conn.Close();
        }
        private void CellToString_Click(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewCell item in this.dataGridView1.SelectedCells)
                ToDeleteTxtBox.Text = item.Value.ToString();
        }
    }
}
