﻿
namespace DatabaseQuery_Santos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_Santos.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new DatabaseQuery_Santos.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.Btn_HighGPA = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.Btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelavg = new System.Windows.Forms.Label();
            this.labelmax = new System.Windows.Forms.Label();
            this.labelmin = new System.Windows.Forms.Label();
            this.labelcount = new System.Windows.Forms.Label();
            this.Btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_ShowRecords = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(460, 251);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // Btn_HighGPA
            // 
            this.Btn_HighGPA.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_HighGPA.Location = new System.Drawing.Point(8, 7);
            this.Btn_HighGPA.Name = "Btn_HighGPA";
            this.Btn_HighGPA.Size = new System.Drawing.Size(214, 26);
            this.Btn_HighGPA.TabIndex = 1;
            this.Btn_HighGPA.Text = "Show Students with High GPA";
            this.Btn_HighGPA.UseVisualStyleBackColor = true;
            this.Btn_HighGPA.Click += new System.EventHandler(this.Btn_HighGPA_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(55)))), ((int)(((byte)(71)))));
            this.panel1.Controls.Add(this.listBox3);
            this.panel1.Controls.Add(this.Btn_GroupRecordsGPA);
            this.panel1.Location = new System.Drawing.Point(478, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(176, 251);
            this.panel1.TabIndex = 2;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(6, 32);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(164, 212);
            this.listBox3.TabIndex = 8;
            // 
            // Btn_GroupRecordsGPA
            // 
            this.Btn_GroupRecordsGPA.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_GroupRecordsGPA.Location = new System.Drawing.Point(6, 3);
            this.Btn_GroupRecordsGPA.Name = "Btn_GroupRecordsGPA";
            this.Btn_GroupRecordsGPA.Size = new System.Drawing.Size(164, 26);
            this.Btn_GroupRecordsGPA.TabIndex = 7;
            this.Btn_GroupRecordsGPA.Text = "Group Records by GPA";
            this.Btn_GroupRecordsGPA.UseVisualStyleBackColor = true;
            this.Btn_GroupRecordsGPA.Click += new System.EventHandler(this.Btn_GroupRecordsGPA_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(55)))), ((int)(((byte)(71)))));
            this.panel2.Controls.Add(this.labelavg);
            this.panel2.Controls.Add(this.labelmax);
            this.panel2.Controls.Add(this.labelmin);
            this.panel2.Controls.Add(this.labelcount);
            this.panel2.Controls.Add(this.Btn_ViewGradeStat);
            this.panel2.Location = new System.Drawing.Point(478, 270);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(176, 164);
            this.panel2.TabIndex = 3;
            // 
            // labelavg
            // 
            this.labelavg.AutoSize = true;
            this.labelavg.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelavg.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.labelavg.Location = new System.Drawing.Point(12, 119);
            this.labelavg.Name = "labelavg";
            this.labelavg.Size = new System.Drawing.Size(56, 16);
            this.labelavg.TabIndex = 10;
            this.labelavg.Text = "------------";
            this.labelavg.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelmax
            // 
            this.labelmax.AutoSize = true;
            this.labelmax.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmax.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.labelmax.Location = new System.Drawing.Point(12, 93);
            this.labelmax.Name = "labelmax";
            this.labelmax.Size = new System.Drawing.Size(56, 16);
            this.labelmax.TabIndex = 9;
            this.labelmax.Text = "------------";
            this.labelmax.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelmin
            // 
            this.labelmin.AutoSize = true;
            this.labelmin.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmin.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.labelmin.Location = new System.Drawing.Point(12, 65);
            this.labelmin.Name = "labelmin";
            this.labelmin.Size = new System.Drawing.Size(56, 16);
            this.labelmin.TabIndex = 8;
            this.labelmin.Text = "------------";
            this.labelmin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelcount
            // 
            this.labelcount.AutoSize = true;
            this.labelcount.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcount.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.labelcount.Location = new System.Drawing.Point(12, 39);
            this.labelcount.Name = "labelcount";
            this.labelcount.Size = new System.Drawing.Size(56, 16);
            this.labelcount.TabIndex = 7;
            this.labelcount.Text = "------------";
            this.labelcount.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Btn_ViewGradeStat
            // 
            this.Btn_ViewGradeStat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_ViewGradeStat.Location = new System.Drawing.Point(6, 6);
            this.Btn_ViewGradeStat.Name = "Btn_ViewGradeStat";
            this.Btn_ViewGradeStat.Size = new System.Drawing.Size(164, 26);
            this.Btn_ViewGradeStat.TabIndex = 6;
            this.Btn_ViewGradeStat.Text = "View Grade Statistics";
            this.Btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.Btn_ViewGradeStat.Click += new System.EventHandler(this.Btn_ViewGradeStat_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(55)))), ((int)(((byte)(71)))));
            this.panel3.Controls.Add(this.listBox1);
            this.panel3.Controls.Add(this.Btn_HighGPA);
            this.panel3.Location = new System.Drawing.Point(12, 269);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(230, 165);
            this.panel3.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(8, 37);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(214, 121);
            this.listBox1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(55)))), ((int)(((byte)(71)))));
            this.panel4.Controls.Add(this.listBox2);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.Btn_ShowRecords);
            this.panel4.Location = new System.Drawing.Point(248, 269);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(224, 164);
            this.panel4.TabIndex = 5;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(7, 62);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(211, 95);
            this.listBox2.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(107, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(112, 20);
            this.textBox1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(5, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter Minimum GPA:";
            // 
            // Btn_ShowRecords
            // 
            this.Btn_ShowRecords.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_ShowRecords.Location = new System.Drawing.Point(5, 7);
            this.Btn_ShowRecords.Name = "Btn_ShowRecords";
            this.Btn_ShowRecords.Size = new System.Drawing.Size(214, 26);
            this.Btn_ShowRecords.TabIndex = 2;
            this.Btn_ShowRecords.Text = "Show Records";
            this.Btn_ShowRecords.UseVisualStyleBackColor = true;
            this.Btn_ShowRecords.Click += new System.EventHandler(this.Btn_ShowRecords_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(134)))), ((int)(((byte)(152)))));
            this.ClientSize = new System.Drawing.Size(666, 446);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database Query Santos";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Btn_HighGPA;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_ShowRecords;
        private System.Windows.Forms.Button Btn_ViewGradeStat;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button Btn_GroupRecordsGPA;
        private System.Windows.Forms.Label labelavg;
        private System.Windows.Forms.Label labelmax;
        private System.Windows.Forms.Label labelmin;
        private System.Windows.Forms.Label labelcount;
    }
}

