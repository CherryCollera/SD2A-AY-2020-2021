﻿using System;


namespace SumFloat
{
    class Program
    {
        static void Main(string[] args)
        {
            float num1, num2;

            Console.WriteLine("Enter First Number: ");
            num1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Second Number: ");
            num2 = float.Parse(Console.ReadLine());
            Console.WriteLine("Sum = {0:0.00000}", num1 + num2);
            Console.ReadLine();
        }
    }
}
