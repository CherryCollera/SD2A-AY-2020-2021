﻿using System;


namespace Averange
{
    class Program
    {
        static void Main(string[] args)
        {
            double g1, g2, g3, g4, g5, avrg;

            Console.WriteLine(" Enter 5 Grades : ");
            g1 = Convert.ToDouble(Console.ReadLine());
            g2 = Convert.ToDouble(Console.ReadLine());
            g3 = Convert.ToDouble(Console.ReadLine());
            g4 = Convert.ToDouble(Console.ReadLine());
            g5 = Convert.ToDouble(Console.ReadLine());
            avrg = (g1 + g2 + g3 + g4 + g5);

            Console.WriteLine(" The Average is {0:0.000}", avrg / 5);
            Console.ReadLine();

        }
    }
}
   