﻿using System;


namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write(" Enter First Number : ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Enter Second Number : ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
                Console.WriteLine("{0} is greater than {1}", num1, num2); 

            else if (num1 < num2)
                Console.WriteLine("{0} is greater than {1}", num2, num1);

            else
                Console.WriteLine("{0} is equal {1}", num1, num2);
            Console.ReadLine();

        }
    }
}

