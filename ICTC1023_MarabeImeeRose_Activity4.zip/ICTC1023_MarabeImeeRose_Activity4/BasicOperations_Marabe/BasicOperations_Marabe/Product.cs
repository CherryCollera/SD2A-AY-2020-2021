﻿class Product
{
    double num1 = DeclareVar.num1;
    double num2 = DeclareVar.num2;

    public double product()
    {
        return num1 * num2;
    }
}
