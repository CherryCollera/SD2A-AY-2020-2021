﻿/*19-00814
 * Marabe, Imee Rose
 * BSCS SD2A
 * March 22, 2021
 * This program will compute the sum, difference, product, quotient and remainder
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Marabe
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.InputDetails();
            Sum s = new Sum();
            Quotient q = new Quotient();
            Remainder r = new Remainder();
            Difference d = new Difference();
            Product p = new Product();
            
            Console.WriteLine("\nSum=\t\t {0}\n", s.sum());
            Console.WriteLine("Difference=\t {0}\n", d.difference());
            Console.WriteLine("Product=\t {0}\n", p.product());
            Console.WriteLine("Quotient=\t {0}\n", q.quotient());
            Console.WriteLine("Remainder=\t {0}\n", r.remainder());
            Console.ReadLine();
            
        }
    }
}
