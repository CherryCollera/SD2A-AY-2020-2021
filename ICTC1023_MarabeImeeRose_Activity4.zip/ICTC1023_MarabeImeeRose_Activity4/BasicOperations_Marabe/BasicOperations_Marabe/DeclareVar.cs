﻿using BasicOperations_Marabe;
class DeclareVar
{
    public static double num1, num2;
    
}
