﻿class Quotient
 {
    double num1 = DeclareVar.num1;
    double num2 = DeclareVar.num2;

    public double quotient()
    {
        return num1 / num2;
    }
}
