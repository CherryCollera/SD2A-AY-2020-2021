﻿class Difference
{
    double num1 = DeclareVar.num1;
    double num2 = DeclareVar.num2;

    public double difference()
    {
        return num1 - num2;
    }
}
