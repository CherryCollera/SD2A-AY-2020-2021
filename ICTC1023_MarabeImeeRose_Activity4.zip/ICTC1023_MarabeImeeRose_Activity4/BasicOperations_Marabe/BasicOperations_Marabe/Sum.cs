﻿class Sum
{
    double num1 = DeclareVar.num1;
    double num2 = DeclareVar.num2;
   
    public double sum()
    {
        return num1 + num2;
    }

}

