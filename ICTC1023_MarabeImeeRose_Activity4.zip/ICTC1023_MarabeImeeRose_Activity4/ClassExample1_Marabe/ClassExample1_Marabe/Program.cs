﻿/*19-00814
 * Marabe, Imee Rose
 * BSCS SD2A
 * March 22, 2021
 * This program will show my profile
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Marabe
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
