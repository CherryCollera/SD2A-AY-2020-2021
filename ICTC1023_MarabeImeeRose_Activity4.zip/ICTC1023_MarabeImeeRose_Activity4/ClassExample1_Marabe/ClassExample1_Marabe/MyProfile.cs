﻿class MyProfile{

    public void DisplayProfile()
    {
        System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E\n");
        System.Console.WriteLine("Name:\t\t\tImee Rose L. Marabe\n");
        System.Console.WriteLine("Birthday:\t\tMay 18, 2001\n");
        System.Console.WriteLine("Course\t\t\tBS in Computer Science Major in Software" + " and Development\n");
        System.Console.WriteLine("Year:\t\t\t2nd Year\n");
        System.Console.WriteLine("Section:\t\tA");
        System.Console.ReadLine();
    }
}

