﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 15, 2021
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, min, max, mid;

            Console.Write("Enter 1st number ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd number ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd number ");
            num3 = Convert.ToInt32(Console.ReadLine());
            if (num3 > num1)
            {
                if (num3 > num2)
                {
                    max = num3;
                    if (num1 > num2)
                    {
                        mid = num1;
                        min = num2;
                        Console.WriteLine("{0} is greater than {1} and {2}", max, mid, min);
                        Console.WriteLine("{0} is less than {1}", mid, max);
                        Console.WriteLine("{0} is less than {1}", min, max);
                    }
                    else
                    {
                        mid = num2;
                        min = num1;
                        Console.WriteLine("{0} is greater than {1} and {2}", max, mid, min);
                        Console.WriteLine("{0} is less than {1}", mid, max);
                        Console.WriteLine("{0} is less than {1}", min, max);
                    }
                }
            }
            else if (num1 > num2)
            {
                if (num1 > num3)
                {
                    max = num1;
                    if (num2 > num3)
                    {
                        mid = num2;
                        min = num3;
                        Console.WriteLine("{0} is greater than {1} and {2}", max, mid, min);
                        Console.WriteLine("{0} is less than {1}", mid, max);
                        Console.WriteLine("{0} is less than {1}", min, max);
                    }
                    else
                    {
                        mid = num3;
                        min = num2;
                        Console.WriteLine("{0} is greater than {1} and {2}", max, mid, min);
                        Console.WriteLine("{0} is less than {1}", mid, max);
                        Console.WriteLine("{0} is less than {1}", min, max);
                    }
                }
            }
            else if (num2 > num1)
            {
                if (num2 > num3)
                {
                    max = num2;
                    if (num1 > num3)
                    {
                        mid = num1;
                        min = num3;
                        Console.WriteLine("{0} is greater than {1} and {2}", max, mid, min);
                        Console.WriteLine("{0} is less than {1}", mid, max);
                        Console.WriteLine("{0} is less than {1}", min, max);
                    }
                    else
                    {
                        mid = num3;
                        min = num1;
                        Console.WriteLine("{0} is greater than {1} and {2}", max, mid, min);
                        Console.WriteLine("{0} is less than {1}", mid, max);
                        Console.WriteLine("{0} is less than {1}", min, max);
                    }
                }
            }
            else if (num1 == num2)
            {
                if (num1 == num3)
                {
                    max = num1;
                    min = num1;
                    mid = num1;
                    Console.WriteLine("{0} {1} and {2} are equal", max, mid, min);
                }
            }
            else
            {
                Console.WriteLine("Wrong Input!!");
            }

            Console.ReadKey();



        }
    }
}
