﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 15, 2021
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            try {
                double inputGrade, eq = 0;
                string remarks;

                Console.Write("\nEnter your final grade\t:\t");
                inputGrade = Convert.ToDouble(Console.ReadLine());

                if (inputGrade >= 95 && inputGrade <= 100)
                {
                    if (inputGrade >= 95 && inputGrade <= 97)
                    {
                        eq = 1.25;
                    }
                    else
                    {
                        eq = 1.00;
                    }
                    remarks = "Excellent";
                }
                else if (inputGrade >= 86 && inputGrade <= 94)
                {
                    if (inputGrade >= 86 && inputGrade <= 88) 
                    {
                        eq = 2.00;
                    }
                    else if (inputGrade >= 89 && inputGrade <= 91) 
                    {
                        eq = 1.75;
                    }
                    else if (inputGrade >= 92 && inputGrade <= 94)
                    {
                        eq = 1.50;
                    }
                    remarks = "Very Good";
                }
                else if (inputGrade >= 83 && inputGrade <= 85)
                {
                    eq = 2.25;
                    remarks = "Good";
                }
                else if (inputGrade >= 77 && inputGrade <= 82)
                {
                    if (inputGrade >= 77 && inputGrade <= 79)
                    {
                        eq = 2.75;
                    } 
                    else if (inputGrade >= 80 && inputGrade <= 82)
                    {
                        eq = 2.50;
                    }
                    remarks = "Fair";
                }
                else if (inputGrade >= 75 && inputGrade <= 76)
                {
                    eq = 3.00;
                    remarks = "Passed";
                }
                else if (inputGrade >= 72 && inputGrade <= 74)
                {
                    eq = 4.00;
                    remarks = "Conditional";
                }
                else if (inputGrade >= 60 && inputGrade <= 71)
                {
                    eq = 5.00;
                    remarks = "Failed";
                }
                else if (inputGrade < 60)
                {
                    eq = 0.00;
                    remarks = "Incomplete";
                }
                else
                {   
                    eq = 0.00;
                    remarks = " ";
                    Console.WriteLine("\nGrade cannot exceed 100!!\n");
                    return;
                }

                Console.WriteLine("Grade Equivalent\t:\t{0:N2} \nRemarks\t\t\t:\t{1}\n",eq,remarks);
                Console.ReadKey();
            } catch (FormatException) {
                Console.WriteLine("Grade Equivalent\t:\tINC\n");
                Console.ReadKey();
            }


        }
    }
}
