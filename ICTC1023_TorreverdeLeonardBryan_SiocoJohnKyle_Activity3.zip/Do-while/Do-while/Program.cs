﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 15, 2021
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] GEF06_nms = {6, 7, 8, 10};
            int GEF06_sum = 0;
            int i = 0;
            do {
                GEF06_sum += GEF06_nms[i];
                i++;
            } while (i < 4);
            Console.WriteLine(GEF06_sum);
            Console.ReadKey();


        }
    }
}
