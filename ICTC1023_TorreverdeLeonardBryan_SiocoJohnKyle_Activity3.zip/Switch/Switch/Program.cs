﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 15, 2021
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            char gender;

            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Enter your Gender M/F: ");
            gender = Convert.ToChar(Console.ReadLine());

            switch(gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("\nHi " + name + "!" + " Your gender is Male!.");
                    break;
                case 'F': case 'f':
                    Console.WriteLine("\nHi " + name + "!" + " Your gender is Female!.");
                    break;
                default:
                    Console.WriteLine("\nInvalid input... Try again...");
                    break;

            }

            Console.ReadKey();
        }
    }
}
