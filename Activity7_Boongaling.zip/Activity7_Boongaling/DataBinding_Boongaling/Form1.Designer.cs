﻿
namespace DataBinding_Boongaling
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.fillByBSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByBSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new DataBinding_Boongaling.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new DataBinding_Boongaling.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.fillByBalangaToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBalangaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBySecondYearToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBySecondYearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByLastnameA_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByLastnameA_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBySection2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBySection2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByVowelToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByVowelToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.fillByBSCSToolStrip.SuspendLayout();
            this.fillByBSITToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.fillByBalangaToolStrip.SuspendLayout();
            this.fillBySecondYearToolStrip.SuspendLayout();
            this.fillByLastnameA_CToolStrip.SuspendLayout();
            this.fillBySection2BToolStrip.SuspendLayout();
            this.fillByVowelToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightCyan;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(88, 123);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(944, 316);
            this.dataGridView1.TabIndex = 0;
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(33, 476);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(98, 37);
            this.refreshToolStrip.TabIndex = 1;
            this.refreshToolStrip.Text = "refreshToolStrip";
            this.refreshToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.refreshToolStrip_ItemClicked);
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(86, 34);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(235, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(625, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "Student Records Monitoring  System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // fillByBSCSToolStrip
            // 
            this.fillByBSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByBSCSToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByBSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBSCSToolStripButton});
            this.fillByBSCSToolStrip.Location = new System.Drawing.Point(162, 476);
            this.fillByBSCSToolStrip.Name = "fillByBSCSToolStrip";
            this.fillByBSCSToolStrip.Size = new System.Drawing.Size(76, 37);
            this.fillByBSCSToolStrip.TabIndex = 3;
            this.fillByBSCSToolStrip.Text = "fillByBSCSToolStrip";
            this.fillByBSCSToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.fillByBSCSToolStrip_ItemClicked);
            // 
            // fillByBSCSToolStripButton
            // 
            this.fillByBSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBSCSToolStripButton.Name = "fillByBSCSToolStripButton";
            this.fillByBSCSToolStripButton.Size = new System.Drawing.Size(64, 34);
            this.fillByBSCSToolStripButton.Text = "BSCS";
            this.fillByBSCSToolStripButton.Click += new System.EventHandler(this.fillByBSCSToolStripButton_Click);
            // 
            // fillByBSITToolStrip
            // 
            this.fillByBSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByBSITToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByBSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBSITToolStripButton});
            this.fillByBSITToolStrip.Location = new System.Drawing.Point(269, 476);
            this.fillByBSITToolStrip.Name = "fillByBSITToolStrip";
            this.fillByBSITToolStrip.Size = new System.Drawing.Size(69, 37);
            this.fillByBSITToolStrip.TabIndex = 4;
            this.fillByBSITToolStrip.Text = "BSIT";
            this.fillByBSITToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.fillByBSITToolStrip_ItemClicked);
            // 
            // fillByBSITToolStripButton
            // 
            this.fillByBSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBSITToolStripButton.Name = "fillByBSITToolStripButton";
            this.fillByBSITToolStripButton.Size = new System.Drawing.Size(57, 34);
            this.fillByBSITToolStripButton.Text = "BSIT";
            this.fillByBSITToolStripButton.Click += new System.EventHandler(this.fillByBSITToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // fillByBalangaToolStrip
            // 
            this.fillByBalangaToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByBalangaToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByBalangaToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBalangaToolStripButton});
            this.fillByBalangaToolStrip.Location = new System.Drawing.Point(348, 476);
            this.fillByBalangaToolStrip.Name = "fillByBalangaToolStrip";
            this.fillByBalangaToolStrip.Size = new System.Drawing.Size(103, 37);
            this.fillByBalangaToolStrip.TabIndex = 5;
            this.fillByBalangaToolStrip.Text = "fillByBalangaToolStrip";
            // 
            // fillByBalangaToolStripButton
            // 
            this.fillByBalangaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBalangaToolStripButton.Name = "fillByBalangaToolStripButton";
            this.fillByBalangaToolStripButton.Size = new System.Drawing.Size(91, 34);
            this.fillByBalangaToolStripButton.Text = "Balanga";
            this.fillByBalangaToolStripButton.Click += new System.EventHandler(this.fillByBalangaToolStripButton_Click);
            // 
            // fillBySecondYearToolStrip
            // 
            this.fillBySecondYearToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBySecondYearToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillBySecondYearToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBySecondYearToolStripButton});
            this.fillBySecondYearToolStrip.Location = new System.Drawing.Point(482, 476);
            this.fillBySecondYearToolStrip.Name = "fillBySecondYearToolStrip";
            this.fillBySecondYearToolStrip.Size = new System.Drawing.Size(142, 37);
            this.fillBySecondYearToolStrip.TabIndex = 6;
            this.fillBySecondYearToolStrip.Text = "fillBySecondYearToolStrip";
            // 
            // fillBySecondYearToolStripButton
            // 
            this.fillBySecondYearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBySecondYearToolStripButton.Name = "fillBySecondYearToolStripButton";
            this.fillBySecondYearToolStripButton.Size = new System.Drawing.Size(130, 34);
            this.fillBySecondYearToolStripButton.Text = "Second Year";
            this.fillBySecondYearToolStripButton.Click += new System.EventHandler(this.fillBySecondYearToolStripButton_Click);
            // 
            // fillByLastnameA_CToolStrip
            // 
            this.fillByLastnameA_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByLastnameA_CToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByLastnameA_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByLastnameA_CToolStripButton});
            this.fillByLastnameA_CToolStrip.Location = new System.Drawing.Point(655, 476);
            this.fillByLastnameA_CToolStrip.Name = "fillByLastnameA_CToolStrip";
            this.fillByLastnameA_CToolStrip.Size = new System.Drawing.Size(157, 37);
            this.fillByLastnameA_CToolStrip.TabIndex = 7;
            this.fillByLastnameA_CToolStrip.Text = "fillByLastnameA_CToolStrip";
            // 
            // fillByLastnameA_CToolStripButton
            // 
            this.fillByLastnameA_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByLastnameA_CToolStripButton.Name = "fillByLastnameA_CToolStripButton";
            this.fillByLastnameA_CToolStripButton.Size = new System.Drawing.Size(145, 34);
            this.fillByLastnameA_CToolStripButton.Text = "Lastname A C";
            this.fillByLastnameA_CToolStripButton.Click += new System.EventHandler(this.fillByLastnameA_CToolStripButton_Click);
            // 
            // fillBySection2BToolStrip
            // 
            this.fillBySection2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBySection2BToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillBySection2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBySection2BToolStripButton});
            this.fillBySection2BToolStrip.Location = new System.Drawing.Point(843, 476);
            this.fillBySection2BToolStrip.Name = "fillBySection2BToolStrip";
            this.fillBySection2BToolStrip.Size = new System.Drawing.Size(126, 37);
            this.fillBySection2BToolStrip.TabIndex = 8;
            this.fillBySection2BToolStrip.Text = "fillBySection2BToolStrip";
            // 
            // fillBySection2BToolStripButton
            // 
            this.fillBySection2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBySection2BToolStripButton.Name = "fillBySection2BToolStripButton";
            this.fillBySection2BToolStripButton.Size = new System.Drawing.Size(114, 34);
            this.fillBySection2BToolStripButton.Text = "Section 2B";
            this.fillBySection2BToolStripButton.Click += new System.EventHandler(this.fillBySection2BToolStripButton_Click);
            // 
            // fillByVowelToolStrip
            // 
            this.fillByVowelToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByVowelToolStrip.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByVowelToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByVowelToolStripButton});
            this.fillByVowelToolStrip.Location = new System.Drawing.Point(1000, 476);
            this.fillByVowelToolStrip.Name = "fillByVowelToolStrip";
            this.fillByVowelToolStrip.Size = new System.Drawing.Size(84, 37);
            this.fillByVowelToolStrip.TabIndex = 9;
            this.fillByVowelToolStrip.Text = "fillByVowelToolStrip";
            // 
            // fillByVowelToolStripButton
            // 
            this.fillByVowelToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByVowelToolStripButton.Name = "fillByVowelToolStripButton";
            this.fillByVowelToolStripButton.Size = new System.Drawing.Size(72, 34);
            this.fillByVowelToolStripButton.Text = "Vowel";
            this.fillByVowelToolStripButton.Click += new System.EventHandler(this.fillByVowelToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1121, 570);
            this.Controls.Add(this.fillByVowelToolStrip);
            this.Controls.Add(this.fillBySection2BToolStrip);
            this.Controls.Add(this.fillByLastnameA_CToolStrip);
            this.Controls.Add(this.fillBySecondYearToolStrip);
            this.Controls.Add(this.fillByBalangaToolStrip);
            this.Controls.Add(this.fillByBSITToolStrip);
            this.Controls.Add(this.fillByBSCSToolStrip);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Data Binding Boongaling";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.fillByBSCSToolStrip.ResumeLayout(false);
            this.fillByBSCSToolStrip.PerformLayout();
            this.fillByBSITToolStrip.ResumeLayout(false);
            this.fillByBSITToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.fillByBalangaToolStrip.ResumeLayout(false);
            this.fillByBalangaToolStrip.PerformLayout();
            this.fillBySecondYearToolStrip.ResumeLayout(false);
            this.fillBySecondYearToolStrip.PerformLayout();
            this.fillByLastnameA_CToolStrip.ResumeLayout(false);
            this.fillByLastnameA_CToolStrip.PerformLayout();
            this.fillBySection2BToolStrip.ResumeLayout(false);
            this.fillBySection2BToolStrip.PerformLayout();
            this.fillByVowelToolStrip.ResumeLayout(false);
            this.fillByVowelToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip fillByBSCSToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBSCSToolStripButton;
        private System.Windows.Forms.ToolStrip fillByBSITToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBSITToolStripButton;
        private System.Windows.Forms.ToolStrip fillByBalangaToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBalangaToolStripButton;
        private System.Windows.Forms.ToolStrip fillBySecondYearToolStrip;
        private System.Windows.Forms.ToolStripButton fillBySecondYearToolStripButton;
        private System.Windows.Forms.ToolStrip fillByLastnameA_CToolStrip;
        private System.Windows.Forms.ToolStripButton fillByLastnameA_CToolStripButton;
        private System.Windows.Forms.ToolStrip fillBySection2BToolStrip;
        private System.Windows.Forms.ToolStripButton fillBySection2BToolStripButton;
        private System.Windows.Forms.ToolStrip fillByVowelToolStrip;
        private System.Windows.Forms.ToolStripButton fillByVowelToolStripButton;
    }
}

