﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample1_Gloria
{
    class Accept //Creating 1st Class
    {
            public string firstname, lastname;
            public void AcceptDetails()
            {
                System.Console.WriteLine("Enter your Firstname and Lastname:\t");
  
                  firstname = System.Console.ReadLine();
                  lastname = System.Console.ReadLine();
            }
        }
    }

