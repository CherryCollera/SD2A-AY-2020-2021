﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample1_Gloria
{
    class MyProfile
    {
        public void DisplayProfile()
        {

            System.Console.WriteLine("Name:		    Malaya B. Gloria");
            System.Console.WriteLine("Birthday:		October 09, 2000");
            System.Console.WriteLine("Course:	    BS Computer Science Major in Software Development");
            System.Console.WriteLine("Year:			2nd Year");
            System.Console.WriteLine("Section:		SD2A");
            System.Console.WriteLine("*****************************");
            System.Console.ReadLine();
        }
    }
}
