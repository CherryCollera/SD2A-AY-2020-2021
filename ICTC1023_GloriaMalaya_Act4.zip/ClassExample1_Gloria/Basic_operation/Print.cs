﻿using System;
using System.Collections.Generic;
using ClassExample1_Gloria;
namespace ClassExample1_Gloria
{class Print //Creating 2nd Class
    {
        public void PrintDetails()
        {
            Accept a = new Accept(); //Creating object of 1st class
            a.AcceptDetails();   //executing method of 1st class
            //Printing value of name variable
            System.Console.Write("Hello " + a.firstname + "  " + a.lastname + "!!! \n You have created class in OOP \n" );
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
    }
}

