﻿using System;

namespace ClassExample1_Gloria
{
    class Program // Creating 4th Class
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
            }
        }
    }

        
    

    

