﻿using System;

namespace BasicOperations_Gloria
{
    class Program
    {
        static void Main(string[] args)
        {
            Sum s = new Sum();
            Input i = new Input();
            i.InputVals();

            Console.WriteLine("Sum:\t{0}", s.computeSum());
            Console.ReadKey();
        }
    }
}
