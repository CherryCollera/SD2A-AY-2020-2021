﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Gloria
{
    class Input
    {
        DeclareVar d = new DeclareVar();

        public void InputVals()
        {
            Console.Write("Input num1:\t");
            double num1 = Convert.ToDouble(Console.ReadLine());
            DeclareVar.num1 = num1;
            Console.Write("Input num2:\t");
            double num2 = Convert.ToDouble(Console.ReadLine());
            DeclareVar.num2 = num2;
        }
    }
}
