﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Class_Gloria
{
    class Declaration
    {
        public string Color
        {
            get
            {
                return Color;
            }
            set
            {
                Color = value;
            }
        }
    }
}

