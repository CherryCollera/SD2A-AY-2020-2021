﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DatabaseConnection_Santos
{
    public partial class Form1 : Form
    {
        private OleDbConnection bookCon;
        private OleDbCommand oleDBCmd = new OleDbCommand();

        //private String conParam = @"Provider = Microsoft.ACE.OLEDB.12.0; 
        //    Data Source = D:\Joshua\VS Community Proj\DatabaseConnection_Santos_Nery\book3.accdb";
        private String conParam = @"Provider=Microsoft.Jet.OLEDB.4.0;
            Data Source=D:\Joshua\VS Community Proj\DatabaseConnection_Santos_Nery\book3.mdb";

        public Form1()
        {
            bookCon = new OleDbConnection(conParam);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            bookCon.Open();
            oleDBCmd.Connection = bookCon;

            oleDBCmd.CommandText = "Insert into bookrecords (booktitle, description) " + " "
                +"values ('" + this.textBox_Title.Text + "' , '" + this.textBox_Desc.Text + "');";

            int temp = oleDBCmd.ExecuteNonQuery();
            if(temp > 0)
            {
                textBox_Title.Text = null;
                textBox_Desc.Text = null;
                MessageBox.Show("Records Successfully Added");
            }
            else
            {
                MessageBox.Show("Failed to Add a Record");
            }
            bookCon.Close();
        }

        private void Btn_All_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", conParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("SELECT * FROM bookrecords", conParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for(int i=0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1]);
            }
        }

        private void Btn_Dlt_Click(object sender, EventArgs e)
        {
            try
            {
                bookCon.Open();
                oleDBCmd.Connection = bookCon;

                oleDBCmd.CommandText = "delete from bookrecords where BookTitle='" +
                dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'";

                oleDBCmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Deleted");

                bookCon.Close();
            }
            catch
            {
                MessageBox.Show("Please Select The Index of the Record you want to Delete");
                bookCon.Close();
            }
        }
    }
}
