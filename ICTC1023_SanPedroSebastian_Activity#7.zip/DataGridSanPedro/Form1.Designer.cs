﻿
namespace DataGridSanPedro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet1 = new DataGridSanPedro.studentsDataSet();
            this.bSIT1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSIT1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studentsDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new DataGridSanPedro.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new DataGridSanPedro.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.refresh1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.refresh1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSCS1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCS1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_BalangaToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_BalangaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.secondYearStudents1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.secondYearStudents1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastnameStartsWithAandCToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastnameStartsWithAandCToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.firstNamesThatStartsWithConsonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstNamesThatStartsWithConsonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet1)).BeginInit();
            this.bSIT1ToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.refresh1ToolStrip.SuspendLayout();
            this.bSCS1ToolStrip.SuspendLayout();
            this.address_BalangaToolStrip.SuspendLayout();
            this.secondYearStudents1ToolStrip.SuspendLayout();
            this.lastnameStartsWithAandCToolStrip.SuspendLayout();
            this.section2BToolStrip.SuspendLayout();
            this.firstNamesThatStartsWithConsonantToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(42, 64);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(678, 244);
            this.dataGridView1.TabIndex = 0;
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet1;
            // 
            // studentsDataSet1
            // 
            this.studentsDataSet1.DataSetName = "studentsDataSet";
            this.studentsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bSIT1ToolStrip
            // 
            this.bSIT1ToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.bSIT1ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSIT1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSIT1ToolStripButton});
            this.bSIT1ToolStrip.Location = new System.Drawing.Point(112, 326);
            this.bSIT1ToolStrip.Name = "bSIT1ToolStrip";
            this.bSIT1ToolStrip.Size = new System.Drawing.Size(49, 25);
            this.bSIT1ToolStrip.TabIndex = 3;
            this.bSIT1ToolStrip.Text = "bSIT1ToolStrip";
            // 
            // bSIT1ToolStripButton
            // 
            this.bSIT1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSIT1ToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.bSIT1ToolStripButton.Name = "bSIT1ToolStripButton";
            this.bSIT1ToolStripButton.Size = new System.Drawing.Size(37, 22);
            this.bSIT1ToolStripButton.Text = "BSIT";
            this.bSIT1ToolStripButton.Click += new System.EventHandler(this.bSIT1ToolStripButton_Click);
            // 
            // studentsDataSetBindingSource
            // 
            this.studentsDataSetBindingSource.DataSource = this.studentsDataSet;
            this.studentsDataSetBindingSource.Position = 0;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // refresh1ToolStrip
            // 
            this.refresh1ToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(80)))), ((int)(((byte)(34)))));
            this.refresh1ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refresh1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refresh1ToolStripButton});
            this.refresh1ToolStrip.Location = new System.Drawing.Point(647, 366);
            this.refresh1ToolStrip.Name = "refresh1ToolStrip";
            this.refresh1ToolStrip.Size = new System.Drawing.Size(71, 25);
            this.refresh1ToolStrip.TabIndex = 4;
            this.refresh1ToolStrip.Text = "refresh1ToolStrip";
            // 
            // refresh1ToolStripButton
            // 
            this.refresh1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refresh1ToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh1ToolStripButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.refresh1ToolStripButton.Name = "refresh1ToolStripButton";
            this.refresh1ToolStripButton.Size = new System.Drawing.Size(59, 22);
            this.refresh1ToolStripButton.Text = "Refresh";
            this.refresh1ToolStripButton.Click += new System.EventHandler(this.refresh1ToolStripButton_Click);
            // 
            // bSCS1ToolStrip
            // 
            this.bSCS1ToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.bSCS1ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCS1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCS1ToolStripButton});
            this.bSCS1ToolStrip.Location = new System.Drawing.Point(42, 326);
            this.bSCS1ToolStrip.Name = "bSCS1ToolStrip";
            this.bSCS1ToolStrip.Size = new System.Drawing.Size(56, 25);
            this.bSCS1ToolStrip.TabIndex = 5;
            this.bSCS1ToolStrip.Text = "bSCS1ToolStrip";
            // 
            // bSCS1ToolStripButton
            // 
            this.bSCS1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCS1ToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bSCS1ToolStripButton.ForeColor = System.Drawing.Color.Black;
            this.bSCS1ToolStripButton.Name = "bSCS1ToolStripButton";
            this.bSCS1ToolStripButton.Size = new System.Drawing.Size(44, 22);
            this.bSCS1ToolStripButton.Text = "BSCS";
            this.bSCS1ToolStripButton.Click += new System.EventHandler(this.bSCS1ToolStripButton_Click);
            // 
            // address_BalangaToolStrip
            // 
            this.address_BalangaToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.address_BalangaToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_BalangaToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_BalangaToolStripButton});
            this.address_BalangaToolStrip.Location = new System.Drawing.Point(176, 326);
            this.address_BalangaToolStrip.Name = "address_BalangaToolStrip";
            this.address_BalangaToolStrip.Size = new System.Drawing.Size(137, 25);
            this.address_BalangaToolStrip.TabIndex = 6;
            this.address_BalangaToolStrip.Text = "address_BalangaToolStrip";
            // 
            // address_BalangaToolStripButton
            // 
            this.address_BalangaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_BalangaToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.address_BalangaToolStripButton.Name = "address_BalangaToolStripButton";
            this.address_BalangaToolStripButton.Size = new System.Drawing.Size(125, 22);
            this.address_BalangaToolStripButton.Text = "Address Balanga";
            this.address_BalangaToolStripButton.Click += new System.EventHandler(this.address_BalangaToolStripButton_Click);
            // 
            // secondYearStudents1ToolStrip
            // 
            this.secondYearStudents1ToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.secondYearStudents1ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.secondYearStudents1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.secondYearStudents1ToolStripButton});
            this.secondYearStudents1ToolStrip.Location = new System.Drawing.Point(327, 326);
            this.secondYearStudents1ToolStrip.Name = "secondYearStudents1ToolStrip";
            this.secondYearStudents1ToolStrip.Size = new System.Drawing.Size(164, 25);
            this.secondYearStudents1ToolStrip.TabIndex = 7;
            this.secondYearStudents1ToolStrip.Text = "secondYearStudents1ToolStrip";
            // 
            // secondYearStudents1ToolStripButton
            // 
            this.secondYearStudents1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.secondYearStudents1ToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.secondYearStudents1ToolStripButton.Name = "secondYearStudents1ToolStripButton";
            this.secondYearStudents1ToolStripButton.Size = new System.Drawing.Size(152, 22);
            this.secondYearStudents1ToolStripButton.Text = "Second Year Students";
            this.secondYearStudents1ToolStripButton.Click += new System.EventHandler(this.secondYearStudents1ToolStripButton_Click);
            // 
            // lastnameStartsWithAandCToolStrip
            // 
            this.lastnameStartsWithAandCToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.lastnameStartsWithAandCToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastnameStartsWithAandCToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastnameStartsWithAandCToolStripButton});
            this.lastnameStartsWithAandCToolStrip.Location = new System.Drawing.Point(505, 326);
            this.lastnameStartsWithAandCToolStrip.Name = "lastnameStartsWithAandCToolStrip";
            this.lastnameStartsWithAandCToolStrip.Size = new System.Drawing.Size(213, 25);
            this.lastnameStartsWithAandCToolStrip.TabIndex = 8;
            this.lastnameStartsWithAandCToolStrip.Text = "Lastnames that start with A and C";
            // 
            // lastnameStartsWithAandCToolStripButton
            // 
            this.lastnameStartsWithAandCToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastnameStartsWithAandCToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.lastnameStartsWithAandCToolStripButton.Name = "lastnameStartsWithAandCToolStripButton";
            this.lastnameStartsWithAandCToolStripButton.Size = new System.Drawing.Size(201, 22);
            this.lastnameStartsWithAandCToolStripButton.Text = "Lastname Starts with A and C";
            this.lastnameStartsWithAandCToolStripButton.Click += new System.EventHandler(this.lastnameStartsWithAandCToolStripButton_Click);
            // 
            // section2BToolStrip
            // 
            this.section2BToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.section2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section2BToolStripButton});
            this.section2BToolStrip.Location = new System.Drawing.Point(42, 377);
            this.section2BToolStrip.Name = "section2BToolStrip";
            this.section2BToolStrip.Size = new System.Drawing.Size(86, 25);
            this.section2BToolStrip.TabIndex = 9;
            this.section2BToolStrip.Text = "section2BToolStrip";
            // 
            // section2BToolStripButton
            // 
            this.section2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section2BToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.section2BToolStripButton.Name = "section2BToolStripButton";
            this.section2BToolStripButton.Size = new System.Drawing.Size(74, 22);
            this.section2BToolStripButton.Text = "Section2B";
            this.section2BToolStripButton.Click += new System.EventHandler(this.section2BToolStripButton_Click);
            // 
            // firstNamesThatStartsWithConsonantToolStrip
            // 
            this.firstNamesThatStartsWithConsonantToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(186)))), ((int)(((byte)(0)))));
            this.firstNamesThatStartsWithConsonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstNamesThatStartsWithConsonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstNamesThatStartsWithConsonantToolStripButton});
            this.firstNamesThatStartsWithConsonantToolStrip.Location = new System.Drawing.Point(146, 377);
            this.firstNamesThatStartsWithConsonantToolStrip.Name = "firstNamesThatStartsWithConsonantToolStrip";
            this.firstNamesThatStartsWithConsonantToolStrip.Size = new System.Drawing.Size(273, 25);
            this.firstNamesThatStartsWithConsonantToolStrip.TabIndex = 10;
            this.firstNamesThatStartsWithConsonantToolStrip.Text = "firstNamesThatStartsWithConsonantToolStrip";
            // 
            // firstNamesThatStartsWithConsonantToolStripButton
            // 
            this.firstNamesThatStartsWithConsonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstNamesThatStartsWithConsonantToolStripButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.firstNamesThatStartsWithConsonantToolStripButton.Name = "firstNamesThatStartsWithConsonantToolStripButton";
            this.firstNamesThatStartsWithConsonantToolStripButton.Size = new System.Drawing.Size(261, 22);
            this.firstNamesThatStartsWithConsonantToolStripButton.Text = "First Names That Starts With Consonant";
            this.firstNamesThatStartsWithConsonantToolStripButton.Click += new System.EventHandler(this.firstNamesThatStartsWithConsonantToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.studIDDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            this.studIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            this.middleNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            this.birthdayDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            this.programDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            this.sectionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            this.yearLevelDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(758, 472);
            this.Controls.Add(this.firstNamesThatStartsWithConsonantToolStrip);
            this.Controls.Add(this.section2BToolStrip);
            this.Controls.Add(this.lastnameStartsWithAandCToolStrip);
            this.Controls.Add(this.secondYearStudents1ToolStrip);
            this.Controls.Add(this.address_BalangaToolStrip);
            this.Controls.Add(this.bSCS1ToolStrip);
            this.Controls.Add(this.refresh1ToolStrip);
            this.Controls.Add(this.bSIT1ToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "                                                                                 " +
    "                          Data Grid San Pedro";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet1)).EndInit();
            this.bSIT1ToolStrip.ResumeLayout(false);
            this.bSIT1ToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.refresh1ToolStrip.ResumeLayout(false);
            this.refresh1ToolStrip.PerformLayout();
            this.bSCS1ToolStrip.ResumeLayout(false);
            this.bSCS1ToolStrip.PerformLayout();
            this.address_BalangaToolStrip.ResumeLayout(false);
            this.address_BalangaToolStrip.PerformLayout();
            this.secondYearStudents1ToolStrip.ResumeLayout(false);
            this.secondYearStudents1ToolStrip.PerformLayout();
            this.lastnameStartsWithAandCToolStrip.ResumeLayout(false);
            this.lastnameStartsWithAandCToolStrip.PerformLayout();
            this.section2BToolStrip.ResumeLayout(false);
            this.section2BToolStrip.PerformLayout();
            this.firstNamesThatStartsWithConsonantToolStrip.ResumeLayout(false);
            this.firstNamesThatStartsWithConsonantToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource studentsDataSetBindingSource;
        private studentsDataSet studentsDataSet;
        private studentsDataSet studentsDataSet1;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.ToolStrip bSIT1ToolStrip;
        private System.Windows.Forms.ToolStripButton bSIT1ToolStripButton;
        private System.Windows.Forms.ToolStrip refresh1ToolStrip;
        private System.Windows.Forms.ToolStripButton refresh1ToolStripButton;
        private System.Windows.Forms.ToolStrip bSCS1ToolStrip;
        private System.Windows.Forms.ToolStripButton bSCS1ToolStripButton;
        private System.Windows.Forms.ToolStrip address_BalangaToolStrip;
        private System.Windows.Forms.ToolStripButton address_BalangaToolStripButton;
        private System.Windows.Forms.ToolStrip secondYearStudents1ToolStrip;
        private System.Windows.Forms.ToolStripButton secondYearStudents1ToolStripButton;
        private System.Windows.Forms.ToolStrip lastnameStartsWithAandCToolStrip;
        private System.Windows.Forms.ToolStripButton lastnameStartsWithAandCToolStripButton;
        private System.Windows.Forms.ToolStrip section2BToolStrip;
        private System.Windows.Forms.ToolStripButton section2BToolStripButton;
        private System.Windows.Forms.ToolStrip firstNamesThatStartsWithConsonantToolStrip;
        private System.Windows.Forms.ToolStripButton firstNamesThatStartsWithConsonantToolStripButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
    }
}

