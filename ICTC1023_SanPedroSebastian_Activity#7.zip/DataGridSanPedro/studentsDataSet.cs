﻿namespace DataGridSanPedro
{


    partial class studentsDataSet
    {
    }
}

namespace DataGridSanPedro.studentsDataSetTableAdapters {
    
    
    public partial class tblStudent_InfoTableAdapter {
    }
}
