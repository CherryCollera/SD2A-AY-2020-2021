﻿
namespace WindowsFormsApp1_SanPedro
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.fnumTxtBox = new System.Windows.Forms.TextBox();
            this.snumTxtBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RemBtn = new System.Windows.Forms.Button();
            this.DivideBtn = new System.Windows.Forms.Button();
            this.MultiplyBtn = new System.Windows.Forms.Button();
            this.SubtracBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.AnswerTxtBox = new System.Windows.Forms.TextBox();
            this.BackBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(35, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "First Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(12, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Second Number:";
            // 
            // fnumTxtBox
            // 
            this.fnumTxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(143)))), ((int)(((byte)(156)))));
            this.fnumTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fnumTxtBox.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnumTxtBox.ForeColor = System.Drawing.Color.White;
            this.fnumTxtBox.Location = new System.Drawing.Point(134, 8);
            this.fnumTxtBox.Name = "fnumTxtBox";
            this.fnumTxtBox.Size = new System.Drawing.Size(100, 14);
            this.fnumTxtBox.TabIndex = 1;
            this.fnumTxtBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // snumTxtBox
            // 
            this.snumTxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(143)))), ((int)(((byte)(156)))));
            this.snumTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.snumTxtBox.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snumTxtBox.ForeColor = System.Drawing.Color.White;
            this.snumTxtBox.Location = new System.Drawing.Point(134, 35);
            this.snumTxtBox.Name = "snumTxtBox";
            this.snumTxtBox.Size = new System.Drawing.Size(100, 14);
            this.snumTxtBox.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.RemBtn);
            this.panel1.Controls.Add(this.DivideBtn);
            this.panel1.Controls.Add(this.MultiplyBtn);
            this.panel1.Controls.Add(this.SubtracBtn);
            this.panel1.Controls.Add(this.AddBtn);
            this.panel1.Location = new System.Drawing.Point(15, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(130, 71);
            this.panel1.TabIndex = 2;
            // 
            // RemBtn
            // 
            this.RemBtn.BackColor = System.Drawing.Color.Gray;
            this.RemBtn.FlatAppearance.BorderSize = 0;
            this.RemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemBtn.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RemBtn.Location = new System.Drawing.Point(88, 1);
            this.RemBtn.Name = "RemBtn";
            this.RemBtn.Size = new System.Drawing.Size(39, 31);
            this.RemBtn.TabIndex = 4;
            this.RemBtn.Text = "%";
            this.RemBtn.UseVisualStyleBackColor = false;
            this.RemBtn.Click += new System.EventHandler(this.RemBtn_Click);
            // 
            // DivideBtn
            // 
            this.DivideBtn.BackColor = System.Drawing.Color.Gray;
            this.DivideBtn.FlatAppearance.BorderSize = 0;
            this.DivideBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DivideBtn.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DivideBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DivideBtn.Location = new System.Drawing.Point(45, 38);
            this.DivideBtn.Name = "DivideBtn";
            this.DivideBtn.Size = new System.Drawing.Size(39, 31);
            this.DivideBtn.TabIndex = 3;
            this.DivideBtn.Text = "/";
            this.DivideBtn.UseVisualStyleBackColor = false;
            this.DivideBtn.Click += new System.EventHandler(this.DivideBtn_Click);
            // 
            // MultiplyBtn
            // 
            this.MultiplyBtn.BackColor = System.Drawing.Color.Gray;
            this.MultiplyBtn.FlatAppearance.BorderSize = 0;
            this.MultiplyBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MultiplyBtn.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MultiplyBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MultiplyBtn.Location = new System.Drawing.Point(1, 38);
            this.MultiplyBtn.Name = "MultiplyBtn";
            this.MultiplyBtn.Size = new System.Drawing.Size(39, 31);
            this.MultiplyBtn.TabIndex = 2;
            this.MultiplyBtn.Text = "*";
            this.MultiplyBtn.UseVisualStyleBackColor = false;
            this.MultiplyBtn.Click += new System.EventHandler(this.MultiplyBtn_Click);
            // 
            // SubtracBtn
            // 
            this.SubtracBtn.BackColor = System.Drawing.Color.Gray;
            this.SubtracBtn.FlatAppearance.BorderSize = 0;
            this.SubtracBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubtracBtn.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubtracBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SubtracBtn.Location = new System.Drawing.Point(45, 1);
            this.SubtracBtn.Name = "SubtracBtn";
            this.SubtracBtn.Size = new System.Drawing.Size(39, 31);
            this.SubtracBtn.TabIndex = 1;
            this.SubtracBtn.Text = "-";
            this.SubtracBtn.UseVisualStyleBackColor = false;
            this.SubtracBtn.Click += new System.EventHandler(this.SubtractBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.BackColor = System.Drawing.Color.Gray;
            this.AddBtn.FlatAppearance.BorderSize = 0;
            this.AddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddBtn.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AddBtn.Location = new System.Drawing.Point(0, 1);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(39, 31);
            this.AddBtn.TabIndex = 0;
            this.AddBtn.Text = "+";
            this.AddBtn.UseVisualStyleBackColor = false;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(148, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Answer:";
            // 
            // AnswerTxtBox
            // 
            this.AnswerTxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(143)))), ((int)(((byte)(156)))));
            this.AnswerTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AnswerTxtBox.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AnswerTxtBox.ForeColor = System.Drawing.Color.White;
            this.AnswerTxtBox.Location = new System.Drawing.Point(148, 81);
            this.AnswerTxtBox.Name = "AnswerTxtBox";
            this.AnswerTxtBox.Size = new System.Drawing.Size(86, 14);
            this.AnswerTxtBox.TabIndex = 1;
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.Color.Gray;
            this.BackBtn.FlatAppearance.BorderSize = 0;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackBtn.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackBtn.Location = new System.Drawing.Point(181, 106);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(53, 22);
            this.BackBtn.TabIndex = 3;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(164)))), ((int)(((byte)(239)))));
            this.ClientSize = new System.Drawing.Size(248, 160);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AnswerTxtBox);
            this.Controls.Add(this.snumTxtBox);
            this.Controls.Add(this.fnumTxtBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox fnumTxtBox;
        private System.Windows.Forms.TextBox snumTxtBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button DivideBtn;
        private System.Windows.Forms.Button MultiplyBtn;
        private System.Windows.Forms.Button SubtracBtn;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AnswerTxtBox;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button RemBtn;
    }
}