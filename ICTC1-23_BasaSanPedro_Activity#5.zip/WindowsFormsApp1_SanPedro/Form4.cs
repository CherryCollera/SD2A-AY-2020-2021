﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_BasaSanPedro
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            if (fnumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = snumTxtBox.Text;
                return;
            }
            if (snumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = fnumTxtBox.Text;
                return;
            }
            int answer = Convert.ToInt32(fnumTxtBox.Text) + Convert.ToInt32(snumTxtBox.Text);
            AnswerTxtBox.Text = Convert.ToString(answer);
        }

        private void SubtractBtn_Click(object sender, EventArgs e)
        {
            if (fnumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = snumTxtBox.Text;
                return;
            }
            if (snumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = fnumTxtBox.Text;
                return;
            }
            int answer = Convert.ToInt32(fnumTxtBox.Text) - Convert.ToInt32(snumTxtBox.Text);
            AnswerTxtBox.Text = Convert.ToString(answer);
        }

        private void MultiplyBtn_Click(object sender, EventArgs e)
        {
            if (fnumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = snumTxtBox.Text;
                return;
            }
            if (snumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = fnumTxtBox.Text;
                return;
            }
            int answer = Convert.ToInt32(fnumTxtBox.Text) * Convert.ToInt32(snumTxtBox.Text);
            AnswerTxtBox.Text = Convert.ToString(answer);
        }

        private void DivideBtn_Click(object sender, EventArgs e)
        {
            if (fnumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = snumTxtBox.Text;
                return;
            }
            if (snumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = fnumTxtBox.Text;
                return;
            }
            int answer = Convert.ToInt32(fnumTxtBox.Text) / Convert.ToInt32(snumTxtBox.Text);
            AnswerTxtBox.Text = Convert.ToString(answer);
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            this.Hide();
            f3.Show();
        }

        private void RemBtn_Click(object sender, EventArgs e)
        {
            if (fnumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = snumTxtBox.Text;
                return;
            }
            if (snumTxtBox.Text == "")
            {
                AnswerTxtBox.Text = fnumTxtBox.Text;
                return;
            }
            int answer = Convert.ToInt32(fnumTxtBox.Text) % Convert.ToInt32(snumTxtBox.Text);
            AnswerTxtBox.Text = Convert.ToString(answer);
        }
    }
}
