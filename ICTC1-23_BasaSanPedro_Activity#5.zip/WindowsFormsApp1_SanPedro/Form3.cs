﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_SanPedro
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void GetMyProfileBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t\tHello " + FirstNameTxtBox.Text + " " + LastNameTxtBox.Text +
                            "\nDate of Birth\t:\t August 6, 2001\n" +
                            "Course\t\t:\tBS Computer Science\n" +
                            "Year\t\t:\tII\n" +
                            "Section\t\t:\tA");
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Hide();
            f2.Show();
        }

        private void HideBtn_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            this.Hide();
            f4.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
