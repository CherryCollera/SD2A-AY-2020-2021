﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1_SanPedro
{
    class HappyBirthday
    {
        public string GetMessage(string firstName)
        {
            return "Happy Birthday " + firstName + "!";
        }
    }
}
