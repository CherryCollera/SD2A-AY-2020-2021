﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    /*
     * 19-02959                         19-01612
     * Basa, Lance Evander Tapang       San Pedro, Sebastian Miguel Soriano
     * BSCS-SD2A                        BSCS-SD2A
     * March 12, 2021
     * This program will display the converted grades
     */
    class LanceEvanderBasaSebastianMiguelSanPedro
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your final grade : ");
            string Grade = Console.ReadLine();
            double ConvertedGrade = 0;
            string Remarks = "";

            if (Grade == "INC" || Grade == "inc")
            {
                Console.WriteLine("Grade Equivalent : Incomplete \n" +
                                  "Remarks : ");
            }
            else
            {
                double NumGrade = Convert.ToDouble(Grade);

                if (100 >= NumGrade && NumGrade >= 98)
                {
                    ConvertedGrade = 1;
                    Remarks = "Excellent";
                }
                else if (97 >= NumGrade && NumGrade >= 95)
                {
                    ConvertedGrade = 1.25;
                    Remarks = "";
                }
                else if (94 >= NumGrade && NumGrade >= 92)
                {
                    ConvertedGrade = 1.50;
                    Remarks = "Very Good";
                }
                else if (91 >= NumGrade && NumGrade >= 89)
                {
                    ConvertedGrade = 1.75;
                    Remarks = "";
                }
                else if (88 >= NumGrade && NumGrade >= 86)
                {
                    ConvertedGrade = 2;
                    Remarks = "Good";
                }
                else if (85 >= NumGrade && NumGrade >= 83)
                {
                    ConvertedGrade = 2.25;
                    Remarks = "Good";
                }
                else if (82 >= NumGrade && NumGrade >= 80)
                {
                    ConvertedGrade = 2.50;
                    Remarks = "Fair";
                }
                else if (79 >= NumGrade && NumGrade >= 77)
                {
                    ConvertedGrade = 2.50;
                    Remarks = "Passed";
                }
                else if (76 >= NumGrade && NumGrade >= 75)
                {
                    ConvertedGrade = 2.75;
                    Remarks = "Passed";
                }
                else if (74 >= NumGrade && NumGrade >= 72)
                {
                    ConvertedGrade = 4;
                    Remarks = "Conditional";
                }
                else if (71 >= NumGrade && NumGrade >= 60)
                {
                    ConvertedGrade = 5;
                    Remarks = "Failed";
                }
                else if (100 < NumGrade || NumGrade < 0)
                {
                    Console.WriteLine("Your input {0} is not valid.", NumGrade);
                    return;
                }

                Console.WriteLine("Grade Equivalent       : {0:0.00} \n" +
                                  "Remarks                : {1}", ConvertedGrade, Remarks);
            }

            Console.ReadKey();
        }
    }
}
