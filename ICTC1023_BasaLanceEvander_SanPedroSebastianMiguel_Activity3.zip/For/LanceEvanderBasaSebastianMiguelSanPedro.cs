﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace For
{
    /*
     * 19-02959                         19-01612
     * Basa, Lance Evander Tapang       San Pedro, Sebastian Miguel Soriano
     * BSCS-SD2A                        BSCS-SD2A
     * March 12, 2021
     * This program will demonstate functionality of a for loop
     */
    class LanceEvanderBasaSebastianMiguelSanPedro
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
