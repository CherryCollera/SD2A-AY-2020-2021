﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    /*
     * 19-02959                         19-01612
     * Basa, Lance Evander Tapang       San Pedro, Sebastian Miguel Soriano
     * BSCS-SD2A                        BSCS-SD2A
     * March 03, 2021
     * This program will display if the numbers are equal or finding the largest number
     */
    class LanceEvanderBasaSebastianMiguelSanPedro
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();
            Console.Write("Enter your Gender M/F: ");
            char gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("\nHi {0}! Your gender is Male!", name);
                    break;
                case 'F': case 'f':
                    Console.WriteLine("\nHi {0}! Your gender is Female!", name);
                    break;
                default:
                    Console.WriteLine("\nInvalid input... Try again...");
                    break;
            }
            Console.ReadKey();
        }
    }
}
