﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNumbers
{
    /*
     * 19-02959                         19-01612
     * Basa, Lance Evander Tapang       San Pedro, Sebastian Miguel Soriano
     * BSCS-SD2A                        BSCS-SD2A
     * March 12, 2021
     * This program will display if the numbers are equal or finding the largest number
     */
    class LanceEvanderBasaSebastianMiguelSanPedro
    {
        static void Main(string[] args)
        {
            Console.Write("Enter 1st number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd number: ");
            int num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 == num2 && num1 == num3)
            {
                Console.WriteLine("{0}, {1} and {2} are equal", num1, num2, num3);
            }
            else
            {
                if (num1 > num2 && num1 > num3)
                {
                    Console.WriteLine("{0} is greater than {1} and {2} \n" +
                                      "{1} is less than {0} \n" +
                                      "{2} is less than {0}", num1, num2, num3);

                }
                else if (num2 > num1 && num2 > num3)
                {
                    Console.WriteLine("{0} is greater than {1} and {2} \n" +
                                      "{1} is less than {0} \n" +
                                      "{2} is less than {0}", num2, num1, num3);
                }
                else
                {
                    Console.WriteLine("{0} is greater than {1} and {2} \n" +
                                      "{1} is less than {0} \n" +
                                      "{2} is less than {0}", num3, num1, num2);
                }
            }
        }
    }
}
