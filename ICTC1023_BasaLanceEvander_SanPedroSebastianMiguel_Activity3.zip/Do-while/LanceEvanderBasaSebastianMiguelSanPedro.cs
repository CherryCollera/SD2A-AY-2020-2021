﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_while
{
    /*
     * 19-02959                         19-01612
     * Basa, Lance Evander Tapang       San Pedro, Sebastian Miguel Soriano
     * BSCS-SD2A                        BSCS-SD2A
     * March 12, 2021
     * This program will display 
     */
    class LanceEvanderBasaSebastianMiguelSanPedro
    {
        static void Main(string[] args)
        {
            int[] LEBSMSP_nms = new int[] { 6, 7, 8, 10 };
            int LEBSMSP_sum = 0;
            int i = 0;

            do
            {
                LEBSMSP_sum += LEBSMSP_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(LEBSMSP_sum);
            Console.ReadKey();
        }
    }
}
