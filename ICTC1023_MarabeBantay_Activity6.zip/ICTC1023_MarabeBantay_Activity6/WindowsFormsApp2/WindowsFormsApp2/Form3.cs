﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm = new Form1();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnInteger_Click(object sender, EventArgs e)
        {
            int number = 25;
            MessageBox.Show(number.ToString(), "Integer");
        }

        private void btnFloat_Click(object sender, EventArgs e)
        {
            float number = 25.78F;
            MessageBox.Show(number.ToString(), "Float");
        }

        private void btnDouble_Click(object sender, EventArgs e)
        {
            double number = 25.7889;
            MessageBox.Show(number.ToString(), "Double");
        }

        private void btnComputeSum_Click(object sender, EventArgs e)
        {
            int num1, num2, sum;

            num1 = Convert.ToInt32(txtFnumber.Text);
            num2 = Convert.ToInt32(txtSnumber.Text);

            sum = num1 + num2;

            MessageBox.Show("The sum is " + Convert.ToString(sum), "SUM");
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            this.Close();
            Calculator frm = new Calculator();
            frm.Show();
        }
    }
}
