﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_Torreverde
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

        }

        private void button_MinGPA_Click(object sender, EventArgs e)
        {
            listBox_MinGPA.Items.Clear();
            double minGPA = Convert.ToDouble(textBox_MinGPA.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox_MinGPA.Items.Add(s.LastName + ", " + s.FirstName);
        }

        private void btn_HighGPA_Click(object sender, EventArgs e)
        {
            listBox_HighGPA.Items.Clear();
            const double cutoff = 3.00;
            this.tblStudentsTableAdapter.Fill(cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > cutoff
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox_HighGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void button_GradeStats_Click(object sender, EventArgs e)
        {
            var gpa =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;
            labelCount.Text = " Count = " + "\t" + gpa.Count();
            labelMin.Text = " Lowest = " + "\t" + gpa.Min();
            labelMax.Text = " Highest = " + "\t" + gpa.Max();
            labelAvg.Text = " Average of all GPAs = " + "\t" + gpa.Average();
        }

        private void button_GroupGPA_Click(object sender, EventArgs e)
        {
            listBox_GroupGPA.Items.Clear();
            var studgpa =
                from s in this.cartmanCollegeDataSet.tblStudents
                group s by (int)s.GradePointAverage;

            foreach (var GroupGPA in studgpa)
            {
                listBox_GroupGPA.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    listBox_GroupGPA.Items.Add(" " + s.GradePointAverage + " " + s.LastName);
            }
        }
    }
}
