﻿namespace DataBinding_Nery
{


    partial class studentsDataSet
    {
    }
}

namespace DataBinding_Nery.studentsDataSetTableAdapters {
    
    
    public partial class tblStudent_InfoTableAdapter {
    }
}
