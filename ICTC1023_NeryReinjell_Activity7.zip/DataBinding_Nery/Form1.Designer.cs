﻿
namespace DataBinding_Nery
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.addressToolStrip = new System.Windows.Forms.ToolStrip();
            this.addressToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.secondYearToolStrip = new System.Windows.Forms.ToolStrip();
            this.secondYearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastnameThatStartsWithACToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastnameThatStartsWithACToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new DataBinding_Nery.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new DataBinding_Nery.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.firstnameStartsWithVowelsToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstnameStartsWithVowelsToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.bSCSToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.addressToolStrip.SuspendLayout();
            this.secondYearToolStrip.SuspendLayout();
            this.section2BToolStrip.SuspendLayout();
            this.lastnameThatStartsWithACToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.firstnameStartsWithVowelsToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(822, 245);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(262, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(338, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Student Records Monitoring System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(364, 414);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 2;
            this.refreshToolStrip.Text = "refreshToolStrip";
            this.refreshToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.refreshToolStrip_ItemClicked);
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(97, 331);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.bSCSToolStrip.TabIndex = 3;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(218, 331);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.bSITToolStrip.TabIndex = 4;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // addressToolStrip
            // 
            this.addressToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.addressToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addressToolStripButton});
            this.addressToolStrip.Location = new System.Drawing.Point(364, 331);
            this.addressToolStrip.Name = "addressToolStrip";
            this.addressToolStrip.Size = new System.Drawing.Size(65, 25);
            this.addressToolStrip.TabIndex = 5;
            this.addressToolStrip.Text = "addressToolStrip";
            // 
            // addressToolStripButton
            // 
            this.addressToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.addressToolStripButton.Name = "addressToolStripButton";
            this.addressToolStripButton.Size = new System.Drawing.Size(53, 22);
            this.addressToolStripButton.Text = "Address";
            this.addressToolStripButton.Click += new System.EventHandler(this.addressToolStripButton_Click);
            // 
            // secondYearToolStrip
            // 
            this.secondYearToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.secondYearToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.secondYearToolStripButton});
            this.secondYearToolStrip.Location = new System.Drawing.Point(516, 331);
            this.secondYearToolStrip.Name = "secondYearToolStrip";
            this.secondYearToolStrip.Size = new System.Drawing.Size(84, 25);
            this.secondYearToolStrip.TabIndex = 6;
            this.secondYearToolStrip.Text = "secondYearToolStrip";
            // 
            // secondYearToolStripButton
            // 
            this.secondYearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.secondYearToolStripButton.Name = "secondYearToolStripButton";
            this.secondYearToolStripButton.Size = new System.Drawing.Size(72, 22);
            this.secondYearToolStripButton.Text = "SecondYear";
            this.secondYearToolStripButton.Click += new System.EventHandler(this.secondYearToolStripButton_Click);
            // 
            // section2BToolStrip
            // 
            this.section2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section2BToolStripButton});
            this.section2BToolStrip.Location = new System.Drawing.Point(676, 331);
            this.section2BToolStrip.Name = "section2BToolStrip";
            this.section2BToolStrip.Size = new System.Drawing.Size(75, 25);
            this.section2BToolStrip.TabIndex = 7;
            this.section2BToolStrip.Text = "section2BToolStrip";
            // 
            // section2BToolStripButton
            // 
            this.section2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section2BToolStripButton.Name = "section2BToolStripButton";
            this.section2BToolStripButton.Size = new System.Drawing.Size(63, 22);
            this.section2BToolStripButton.Text = "Section2B";
            this.section2BToolStripButton.Click += new System.EventHandler(this.section2BToolStripButton_Click);
            // 
            // lastnameThatStartsWithACToolStrip
            // 
            this.lastnameThatStartsWithACToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastnameThatStartsWithACToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastnameThatStartsWithACToolStripButton});
            this.lastnameThatStartsWithACToolStrip.Location = new System.Drawing.Point(176, 373);
            this.lastnameThatStartsWithACToolStrip.Name = "lastnameThatStartsWithACToolStrip";
            this.lastnameThatStartsWithACToolStrip.Size = new System.Drawing.Size(167, 25);
            this.lastnameThatStartsWithACToolStrip.TabIndex = 8;
            this.lastnameThatStartsWithACToolStrip.Text = "lastnameThatStartsWithACToolStrip";
            // 
            // lastnameThatStartsWithACToolStripButton
            // 
            this.lastnameThatStartsWithACToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastnameThatStartsWithACToolStripButton.Name = "lastnameThatStartsWithACToolStripButton";
            this.lastnameThatStartsWithACToolStripButton.Size = new System.Drawing.Size(155, 22);
            this.lastnameThatStartsWithACToolStripButton.Text = "LastnameThatStartsWithAC";
            this.lastnameThatStartsWithACToolStripButton.Click += new System.EventHandler(this.lastnameThatStartsWithACToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // firstnameStartsWithVowelsToolStrip
            // 
            this.firstnameStartsWithVowelsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstnameStartsWithVowelsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstnameStartsWithVowelsToolStripButton});
            this.firstnameStartsWithVowelsToolStrip.Location = new System.Drawing.Point(454, 373);
            this.firstnameStartsWithVowelsToolStrip.Name = "firstnameStartsWithVowelsToolStrip";
            this.firstnameStartsWithVowelsToolStrip.Size = new System.Drawing.Size(196, 25);
            this.firstnameStartsWithVowelsToolStrip.TabIndex = 9;
            this.firstnameStartsWithVowelsToolStrip.Text = "firstnameStartsWithVowelsToolStrip";
            // 
            // firstnameStartsWithVowelsToolStripButton
            // 
            this.firstnameStartsWithVowelsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstnameStartsWithVowelsToolStripButton.Name = "firstnameStartsWithVowelsToolStripButton";
            this.firstnameStartsWithVowelsToolStripButton.Size = new System.Drawing.Size(153, 22);
            this.firstnameStartsWithVowelsToolStripButton.Text = "FirstnameStartsWithVowels";
            this.firstnameStartsWithVowelsToolStripButton.Click += new System.EventHandler(this.firstnameStartsWithVowelsToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 461);
            this.Controls.Add(this.firstnameStartsWithVowelsToolStrip);
            this.Controls.Add(this.lastnameThatStartsWithACToolStrip);
            this.Controls.Add(this.section2BToolStrip);
            this.Controls.Add(this.secondYearToolStrip);
            this.Controls.Add(this.addressToolStrip);
            this.Controls.Add(this.bSITToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.addressToolStrip.ResumeLayout(false);
            this.addressToolStrip.PerformLayout();
            this.secondYearToolStrip.ResumeLayout(false);
            this.secondYearToolStrip.PerformLayout();
            this.section2BToolStrip.ResumeLayout(false);
            this.section2BToolStrip.PerformLayout();
            this.lastnameThatStartsWithACToolStrip.ResumeLayout(false);
            this.lastnameThatStartsWithACToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.firstnameStartsWithVowelsToolStrip.ResumeLayout(false);
            this.firstnameStartsWithVowelsToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip bSITToolStrip;
        private System.Windows.Forms.ToolStripButton bSITToolStripButton;
        private System.Windows.Forms.ToolStrip addressToolStrip;
        private System.Windows.Forms.ToolStripButton addressToolStripButton;
        private System.Windows.Forms.ToolStrip secondYearToolStrip;
        private System.Windows.Forms.ToolStripButton secondYearToolStripButton;
        private System.Windows.Forms.ToolStrip section2BToolStrip;
        private System.Windows.Forms.ToolStripButton section2BToolStripButton;
        private System.Windows.Forms.ToolStrip lastnameThatStartsWithACToolStrip;
        private System.Windows.Forms.ToolStripButton lastnameThatStartsWithACToolStripButton;
        private System.Windows.Forms.ToolStrip firstnameStartsWithVowelsToolStrip;
        private System.Windows.Forms.ToolStripButton firstnameStartsWithVowelsToolStripButton;
    }
}

