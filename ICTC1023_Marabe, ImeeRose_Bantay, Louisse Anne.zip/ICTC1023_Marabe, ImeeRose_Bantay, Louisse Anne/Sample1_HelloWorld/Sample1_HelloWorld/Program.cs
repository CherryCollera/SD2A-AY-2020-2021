﻿/* 19-00814
 * Marabe, Imee Rose L.
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * February 25, 2021
 * This program will display our profile
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample1_HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
