﻿/* 19-00814
 * Marabe, Imee Rose L.
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * February 25, 2021
 * This program will display our profile
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample3_InputMyName
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 2;
            for (int i = 0; i < number; i++)
            {
                Console.Write("Enter your name (firstname lastname): ");
                var myname = Console.ReadLine();
                Console.WriteLine("\nHello " + myname + "!!!");
                Console.Write("Welcome to OOP environment.\n\n");
            }
            Console.ReadLine();
        }
    }
}
