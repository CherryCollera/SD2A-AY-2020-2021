﻿/* 19-00814
 * Marabe, Imee Rose L.
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * February 25, 2021
 * This program will display our profile
 */
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2_MyProfile
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("#1");
            System.Console.Write("Name: Imee Rose L. Marabe\n");
            System.Console.Write("\nDate of Birth: May 18, 2001\n");
            System.Console.Write("\nCourse: BS Computer Science\n");
            System.Console.Write("\nYear: 2nd\n");
            System.Console.WriteLine("\nSection: Software Development 2A");
            System.Console.WriteLine("\n\n#2");
            System.Console.Write("Name: Louisse Anne A. Bantay\n");
            System.Console.Write("\nDate of Birth: September 23, 2001\n");
            System.Console.Write("\nCourse: BS Computer Science\n");
            System.Console.Write("\nYear: 2nd\n");
            System.Console.WriteLine("\nSection: Software Development 2A");
            System.Console.ReadKey();
        }
    }
}
