﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataQuery_Sabado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_HighGPA_Click(object sender, EventArgs e)
        {
            listbox_HighGPA.Items.Clear();
            const double CUTOFF = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > CUTOFF
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listbox_HighGPA.Items.Add(s.LastName + "    " + s.FirstName);
        }

        private void btn_ShowRecords_Click(object sender, EventArgs e)
        {
            listBox_MinGPA.Items.Clear();
            double minGPA = Convert.ToDouble(tbox_enterMin.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox_MinGPA.Items.Add(s.LastName + ", " + s.FirstName);
        }

        private void btn_ViewGradeStat_Click(object sender, EventArgs e)
        {
            var gpas =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;
            labelCount.Text = " Count is " + "\t" + gpas.Count();
            labelMin.Text = "Lowest is " + "\t" + gpas.Min();
            labelMax.Text = " Highest is " + "\t" + gpas.Max();
            labelAverage.Text = "Average of all GPAs is " + "\t" + gpas.Average();

        }

        private void btn_GroupRecordsGPA_Click(object sender, EventArgs e)
        {
            listBoxGroupByGPA.Items.Clear();
            var studgpa =
                from s in this.cartmanCollegeDataSet.tblStudents
                group s by (int)s.GradePointAverage;

            foreach (var GroupGPA in studgpa)
            {
                listBoxGroupByGPA.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    listBoxGroupByGPA.Items.Add(" " + s.GradePointAverage + " " + s.LastName);
            } 
        }
    }
}
