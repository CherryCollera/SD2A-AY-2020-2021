﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t       Hello " + tbox_fname3.Text + " " + tbox_lname3.Text
                          + "\nDate of Birth      :        March 01, 1998"
                          + "\nCourse                :        BS Computer Science"
                          + "\nYear                     :        2" +
                          "\nSection               :        A");
        }

        private void btn_hide3_Click_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();

            f4.Show();
            this.Hide();
        }

        private void tbox_fname3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("\t       Hello " + tbox_fname3.Text + " " + tbox_lname3.Text
                          + "\nDate of Birth      :        March 01, 1998"
                          + "\nCourse                :        BS Computer Science"
                          + "\nYear                     :        2" +
                          "\nSection               :        A");
        }

        private void btn_back3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }
    }
    }

   
    

