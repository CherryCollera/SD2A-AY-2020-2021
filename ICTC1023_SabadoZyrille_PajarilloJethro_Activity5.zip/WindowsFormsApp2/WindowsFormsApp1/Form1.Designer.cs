﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GetMessage_2 = new System.Windows.Forms.Button();
            this.btn_Hide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_GetMessage_2
            // 
            this.btn_GetMessage_2.Location = new System.Drawing.Point(115, 77);
            this.btn_GetMessage_2.Name = "btn_GetMessage_2";
            this.btn_GetMessage_2.Size = new System.Drawing.Size(168, 52);
            this.btn_GetMessage_2.TabIndex = 0;
            this.btn_GetMessage_2.Text = "Get Message";
            this.btn_GetMessage_2.UseVisualStyleBackColor = true;
            this.btn_GetMessage_2.Click += new System.EventHandler(this.btn_GetMessage_Click2_Click);
            // 
            // btn_Hide
            // 
            this.btn_Hide.Location = new System.Drawing.Point(298, 279);
            this.btn_Hide.Name = "btn_Hide";
            this.btn_Hide.Size = new System.Drawing.Size(75, 23);
            this.btn_Hide.TabIndex = 1;
            this.btn_Hide.Text = "Hide";
            this.btn_Hide.UseVisualStyleBackColor = true;
            this.btn_Hide.Click += new System.EventHandler(this.btn_Hide_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(399, 324);
            this.Controls.Add(this.btn_Hide);
            this.Controls.Add(this.btn_GetMessage_2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

        }

        #endregion

        
        
        private System.Windows.Forms.Button btn_GetMessage_2;
        private Button btn_Hide;
    }
}

