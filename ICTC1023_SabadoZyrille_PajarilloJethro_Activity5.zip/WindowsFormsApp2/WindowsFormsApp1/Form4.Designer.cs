﻿
namespace WindowsFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbox_fnum = new System.Windows.Forms.TextBox();
            this.tbox_lnum = new System.Windows.Forms.TextBox();
            this.btn_plus = new System.Windows.Forms.Button();
            this.btn_multiply = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_divide = new System.Windows.Forms.Button();
            this.btn_answer = new System.Windows.Forms.Label();
            this.tbox_answer = new System.Windows.Forms.TextBox();
            this.btn_back4 = new System.Windows.Forms.Button();
            this.btn_modulo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "First number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last number:";
            // 
            // tbox_fnum
            // 
            this.tbox_fnum.Location = new System.Drawing.Point(160, 38);
            this.tbox_fnum.Name = "tbox_fnum";
            this.tbox_fnum.Size = new System.Drawing.Size(93, 22);
            this.tbox_fnum.TabIndex = 2;
            // 
            // tbox_lnum
            // 
            this.tbox_lnum.Location = new System.Drawing.Point(160, 92);
            this.tbox_lnum.Name = "tbox_lnum";
            this.tbox_lnum.Size = new System.Drawing.Size(93, 22);
            this.tbox_lnum.TabIndex = 3;
            // 
            // btn_plus
            // 
            this.btn_plus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_plus.Location = new System.Drawing.Point(56, 146);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(145, 68);
            this.btn_plus.TabIndex = 4;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = false;
            this.btn_plus.Click += new System.EventHandler(this.btn_plus_Click);
            // 
            // btn_multiply
            // 
            this.btn_multiply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_multiply.Location = new System.Drawing.Point(56, 243);
            this.btn_multiply.Name = "btn_multiply";
            this.btn_multiply.Size = new System.Drawing.Size(145, 70);
            this.btn_multiply.TabIndex = 5;
            this.btn_multiply.Text = "*";
            this.btn_multiply.UseVisualStyleBackColor = false;
            this.btn_multiply.Click += new System.EventHandler(this.btn_multiply_Click);
            // 
            // btn_minus
            // 
            this.btn_minus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_minus.Location = new System.Drawing.Point(225, 146);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(147, 68);
            this.btn_minus.TabIndex = 6;
            this.btn_minus.Text = "_";
            this.btn_minus.UseVisualStyleBackColor = false;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_Click);
            // 
            // btn_divide
            // 
            this.btn_divide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_divide.Location = new System.Drawing.Point(225, 243);
            this.btn_divide.Name = "btn_divide";
            this.btn_divide.Size = new System.Drawing.Size(147, 70);
            this.btn_divide.TabIndex = 7;
            this.btn_divide.Text = "\\";
            this.btn_divide.UseVisualStyleBackColor = false;
            this.btn_divide.Click += new System.EventHandler(this.btn_divide_Click);
            // 
            // btn_answer
            // 
            this.btn_answer.AutoSize = true;
            this.btn_answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_answer.Location = new System.Drawing.Point(18, 442);
            this.btn_answer.Name = "btn_answer";
            this.btn_answer.Size = new System.Drawing.Size(80, 24);
            this.btn_answer.TabIndex = 8;
            this.btn_answer.Text = "Answer";
            // 
            // tbox_answer
            // 
            this.tbox_answer.Location = new System.Drawing.Point(104, 444);
            this.tbox_answer.Name = "tbox_answer";
            this.tbox_answer.Size = new System.Drawing.Size(113, 22);
            this.tbox_answer.TabIndex = 9;
            // 
            // btn_back4
            // 
            this.btn_back4.Location = new System.Drawing.Point(306, 442);
            this.btn_back4.Name = "btn_back4";
            this.btn_back4.Size = new System.Drawing.Size(85, 33);
            this.btn_back4.TabIndex = 10;
            this.btn_back4.Text = "Back";
            this.btn_back4.UseVisualStyleBackColor = true;
            this.btn_back4.Click += new System.EventHandler(this.btn_back4_Click);
            // 
            // btn_modulo
            // 
            this.btn_modulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_modulo.Location = new System.Drawing.Point(141, 330);
            this.btn_modulo.Name = "btn_modulo";
            this.btn_modulo.Size = new System.Drawing.Size(149, 82);
            this.btn_modulo.TabIndex = 11;
            this.btn_modulo.Text = "%";
            this.btn_modulo.UseVisualStyleBackColor = false;
            this.btn_modulo.Click += new System.EventHandler(this.btn_modulo_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 514);
            this.Controls.Add(this.btn_modulo);
            this.Controls.Add(this.btn_back4);
            this.Controls.Add(this.tbox_answer);
            this.Controls.Add(this.btn_answer);
            this.Controls.Add(this.btn_divide);
            this.Controls.Add(this.btn_minus);
            this.Controls.Add(this.btn_multiply);
            this.Controls.Add(this.btn_plus);
            this.Controls.Add(this.tbox_lnum);
            this.Controls.Add(this.tbox_fnum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbox_fnum;
        private System.Windows.Forms.TextBox tbox_lnum;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.Button btn_multiply;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_divide;
        private System.Windows.Forms.Label btn_answer;
        private System.Windows.Forms.TextBox tbox_answer;
        private System.Windows.Forms.Button btn_back4;
        private System.Windows.Forms.Button btn_modulo;
    }
}