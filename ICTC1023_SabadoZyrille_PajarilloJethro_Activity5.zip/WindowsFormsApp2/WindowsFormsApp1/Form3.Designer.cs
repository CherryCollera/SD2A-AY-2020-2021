﻿
namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btn_hide3_Click = new System.Windows.Forms.Button();
            this.btn_back3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbox_fname3 = new System.Windows.Forms.TextBox();
            this.tbox_lname3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(113, 259);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(183, 45);
            this.button1.TabIndex = 0;
            this.button1.Text = "Get My Profile";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_hide3_Click
            // 
            this.btn_hide3_Click.Location = new System.Drawing.Point(325, 259);
            this.btn_hide3_Click.Name = "btn_hide3_Click";
            this.btn_hide3_Click.Size = new System.Drawing.Size(94, 45);
            this.btn_hide3_Click.TabIndex = 1;
            this.btn_hide3_Click.Text = "Hide";
            this.btn_hide3_Click.UseVisualStyleBackColor = true;
            this.btn_hide3_Click.Click += new System.EventHandler(this.btn_hide3_Click_Click);
            // 
            // btn_back3
            // 
            this.btn_back3.Location = new System.Drawing.Point(441, 259);
            this.btn_back3.Name = "btn_back3";
            this.btn_back3.Size = new System.Drawing.Size(92, 45);
            this.btn_back3.TabIndex = 2;
            this.btn_back3.Text = "Back";
            this.btn_back3.UseVisualStyleBackColor = true;
            this.btn_back3.Click += new System.EventHandler(this.btn_back3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cooper Black", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(255, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 27);
            this.label4.TabIndex = 3;
            this.label4.Text = "My Profile";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(109, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "First name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(110, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Last name:";
            // 
            // tbox_fname3
            // 
            this.tbox_fname3.Location = new System.Drawing.Point(244, 80);
            this.tbox_fname3.Name = "tbox_fname3";
            this.tbox_fname3.Size = new System.Drawing.Size(266, 22);
            this.tbox_fname3.TabIndex = 6;
            this.tbox_fname3.TextChanged += new System.EventHandler(this.tbox_fname3_TextChanged);
            // 
            // tbox_lname3
            // 
            this.tbox_lname3.Location = new System.Drawing.Point(244, 143);
            this.tbox_lname3.Name = "tbox_lname3";
            this.tbox_lname3.Size = new System.Drawing.Size(266, 22);
            this.tbox_lname3.TabIndex = 7;
            // 
            // Form3
            // 
            this.ClientSize = new System.Drawing.Size(655, 435);
            this.Controls.Add(this.tbox_lname3);
            this.Controls.Add(this.tbox_fname3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_back3);
            this.Controls.Add(this.btn_hide3_Click);
            this.Controls.Add(this.button1);
            this.Name = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbox_fname2;
        private System.Windows.Forms.TextBox tbox_lname2;
        private System.Windows.Forms.Button btn_getprof;
        private System.Windows.Forms.Button btn_hide3;
        private System.Windows.Forms.Button btn_back1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_hide3_Click;
        private System.Windows.Forms.Button btn_back3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbox_fname3;
        private System.Windows.Forms.TextBox tbox_lname3;
    }
}