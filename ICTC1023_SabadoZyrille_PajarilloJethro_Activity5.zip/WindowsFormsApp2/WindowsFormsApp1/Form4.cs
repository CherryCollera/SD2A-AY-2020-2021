﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_plus_Click(object sender, EventArgs e)
        {

            int fnum = Convert.ToInt32(tbox_fnum.Text);
            int snum = Convert.ToInt32(tbox_lnum.Text);
            int result;

            result = fnum + snum;
            tbox_answer.Text = Convert.ToString(result);
        }

        private void btn_minus_Click(object sender, EventArgs e)
        {
            int fnum = Convert.ToInt32(tbox_fnum.Text);
            int snum = Convert.ToInt32(tbox_lnum.Text);
            int result;

            result = fnum - snum;
            tbox_answer.Text = Convert.ToString(result);
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            int fnum = Convert.ToInt32(tbox_fnum.Text);
            int snum = Convert.ToInt32(tbox_lnum.Text);
            int result;

            result = fnum * snum;
            tbox_answer.Text = Convert.ToString(result);
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            int fnum = Convert.ToInt32(tbox_fnum.Text);
            int snum = Convert.ToInt32(tbox_lnum.Text);
            int result;

            result = fnum / snum;
            tbox_answer.Text = Convert.ToString(result);
        }

        private void btn_modulo_Click(object sender, EventArgs e)
        {
            int fnum = Convert.ToInt32(tbox_fnum.Text);
            int snum = Convert.ToInt32(tbox_lnum.Text);
            int result;

            result = fnum % snum;
            tbox_answer.Text = Convert.ToString(result);
        }

        private void btn_back4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }
    }
}
