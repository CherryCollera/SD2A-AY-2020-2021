﻿
namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_fname = new System.Windows.Forms.Label();
            this.tbox_fname = new System.Windows.Forms.TextBox();
            this.tbox_lname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_GetMessages2 = new System.Windows.Forms.Button();
            this.btn_Hide2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_fname
            // 
            this.lbl_fname.AutoSize = true;
            this.lbl_fname.Location = new System.Drawing.Point(139, 47);
            this.lbl_fname.Name = "lbl_fname";
            this.lbl_fname.Size = new System.Drawing.Size(78, 17);
            this.lbl_fname.TabIndex = 2;
            this.lbl_fname.Text = "First name:";
            this.lbl_fname.Click += new System.EventHandler(this.lbl_fname_Click);
            // 
            // tbox_fname
            // 
            this.tbox_fname.Location = new System.Drawing.Point(232, 47);
            this.tbox_fname.Name = "tbox_fname";
            this.tbox_fname.Size = new System.Drawing.Size(214, 22);
            this.tbox_fname.TabIndex = 3;
            // 
            // tbox_lname
            // 
            this.tbox_lname.Location = new System.Drawing.Point(232, 88);
            this.tbox_lname.Name = "tbox_lname";
            this.tbox_lname.Size = new System.Drawing.Size(214, 22);
            this.tbox_lname.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(139, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Last name:";
            // 
            // btn_GetMessages2
            // 
            this.btn_GetMessages2.Location = new System.Drawing.Point(232, 165);
            this.btn_GetMessages2.Name = "btn_GetMessages2";
            this.btn_GetMessages2.Size = new System.Drawing.Size(201, 48);
            this.btn_GetMessages2.TabIndex = 6;
            this.btn_GetMessages2.Text = "Get Message";
            this.btn_GetMessages2.UseVisualStyleBackColor = true;
            this.btn_GetMessages2.Click += new System.EventHandler(this.btn_GetMessages2_Click);
            // 
            // btn_Hide2
            // 
            this.btn_Hide2.Location = new System.Drawing.Point(487, 326);
            this.btn_Hide2.Name = "btn_Hide2";
            this.btn_Hide2.Size = new System.Drawing.Size(99, 24);
            this.btn_Hide2.TabIndex = 7;
            this.btn_Hide2.Text = "Hide";
            this.btn_Hide2.UseVisualStyleBackColor = true;
            this.btn_Hide2.Click += new System.EventHandler(this.btn_Hide2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 382);
            this.Controls.Add(this.btn_Hide2);
            this.Controls.Add(this.btn_GetMessages2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbox_lname);
            this.Controls.Add(this.tbox_fname);
            this.Controls.Add(this.lbl_fname);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_fname;
        private System.Windows.Forms.TextBox tbox_fname;
        private System.Windows.Forms.TextBox tbox_lname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_GetMessages2;
        private System.Windows.Forms.Button btn_Hide2;
    }
}