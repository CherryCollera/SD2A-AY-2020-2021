﻿/*19-00140
Joshua M. Santos
SD2A
March 22, 2021*/
using System;

namespace ClassExample2_Collera
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe());
            car = new Car("Green");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }
}
