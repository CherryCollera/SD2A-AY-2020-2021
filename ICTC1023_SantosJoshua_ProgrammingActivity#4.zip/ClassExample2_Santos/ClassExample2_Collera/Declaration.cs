﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample2_Collera
{
    class Declaration
    {
        public string Color
        {
            get
            {
                return Color;
            }
            set
            {
                Color = value;
            }
        }
    }
}
