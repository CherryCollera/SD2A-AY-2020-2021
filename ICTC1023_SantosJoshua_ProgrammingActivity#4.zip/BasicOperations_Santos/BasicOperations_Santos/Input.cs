﻿namespace BasicOperations_Collera
{
    class Input
    {
        DeclareVar d = new DeclareVar();
        public void InputNum()
        {
            System.Console.Write("Enter First Number: ");
            DeclareVar.Set1 = System.Convert.ToInt32(System.Console.ReadLine());
            System.Console.Write("Enter Second Number: ");
            DeclareVar.Set2 = System.Convert.ToInt32(System.Console.ReadLine());
        }

        

    }
}
