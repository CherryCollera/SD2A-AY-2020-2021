﻿namespace BasicOperations_Collera
{
    class Product : DeclareVar
    {
        public double ProdSolve()
        {
            double prod = num1 * num2;
            return prod;
        }
    }
}
