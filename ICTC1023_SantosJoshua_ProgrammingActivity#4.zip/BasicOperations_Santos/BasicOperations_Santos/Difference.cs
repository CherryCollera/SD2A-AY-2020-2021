﻿namespace BasicOperations_Collera
{
    class Difference : DeclareVar
    {
        public double DiffSolve()
        {
            double diff = num1 - num2;
            return diff;
        }
    }
}
