﻿namespace BasicOperations_Collera
{
    class Remainder : DeclareVar
    {
        public double RemSolve()
        {
            double rem = num1 % num2;
            return rem;
        }
    }
}
