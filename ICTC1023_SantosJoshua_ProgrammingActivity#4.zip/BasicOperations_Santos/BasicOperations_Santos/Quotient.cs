﻿namespace BasicOperations_Collera
{
    class Quotient : DeclareVar
    {
        public double QuoSolve()
        {
            double quo = num1 / num2;
            return quo;
        }
    }
}
