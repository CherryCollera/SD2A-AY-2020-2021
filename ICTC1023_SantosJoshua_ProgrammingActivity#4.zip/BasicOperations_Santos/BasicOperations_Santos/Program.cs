﻿
using System;

/*19-00140
Joshua M. Santos
SD2A
March 22, 2021*/
namespace BasicOperations_Collera
{
    class Program
    {
        static void Main(string[] args)
        {
            Input obj = new Input();
            obj.InputNum();

            Sum add = new Sum();
            Difference minus = new Difference();
            Product times = new Product();
            Quotient divide = new Quotient();
            Remainder remain = new Remainder();
            
            Console.WriteLine("\nSum = {0}", add.SumSolve());
            Console.WriteLine("Difference = {0}", minus.DiffSolve());
            Console.WriteLine("Product = {0}", times.ProdSolve());
            Console.WriteLine("Quotient = {0}", divide.QuoSolve());
            Console.WriteLine("Remainder = {0}", remain.RemSolve());
        }
    }
}
