﻿namespace BasicOperations_Collera
{
    class DeclareVar
    {
        public static double num1, num2;

        public static double Set1   
        {
            get { return num1; }
            set { num1 = value; }
        }
        public static double Set2
        {
            get { return num2; }
            set { num2 = value; }
        }

        


    }
}
