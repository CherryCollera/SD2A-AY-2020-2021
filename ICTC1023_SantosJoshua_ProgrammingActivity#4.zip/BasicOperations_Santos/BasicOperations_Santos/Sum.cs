﻿namespace BasicOperations_Collera
{
    class Sum:DeclareVar
    {
        
        public double SumSolve()
        {
            double sum = num1 + num2;
            return sum;
        }
    }
}
