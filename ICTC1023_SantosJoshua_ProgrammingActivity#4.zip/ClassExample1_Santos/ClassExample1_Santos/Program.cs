﻿/*19-00140
Joshua M. Santos
SD2A
March 22, 2021*/
using System;

namespace ClassExample1_Santos
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
