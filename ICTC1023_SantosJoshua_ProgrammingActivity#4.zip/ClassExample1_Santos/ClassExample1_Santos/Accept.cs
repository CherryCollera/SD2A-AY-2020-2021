﻿

namespace ClassExample1_Santos
{
    class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            System.Console.Write("Enter your firstname: \t");
            firstname = System.Console.ReadLine();
            System.Console.Write("Enter your lastname: \t");
            lastname = System.Console.ReadLine();
        }
    }
}
