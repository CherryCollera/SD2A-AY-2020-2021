﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DatabaseConnection_SanPedro
{
    public partial class Form1 : Form
    {
        private static OleDbConnection conn;
        private static OleDbCommand command = new OleDbCommand();
        private static String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;
                        Data Source=C:\Users\KN Tech\source\repos\DatabaseConnection_SanPedro\book3.accdb";
        private static String connParam1 = @"Provider=Microsoft.ACE.OLEDB.12.0;
                        Data Source=C:\Users\KN Tech\OneDrive\Documents\SD2AB_SecondSem\OOP SD2A\book3.accdb";
        public Form1()
        {
            conn = new OleDbConnection(connParam);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);
        }
        private void AddBtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            command.Connection = conn;
            command.CommandText = "INSERT INTO BOOKRECORDS (booktitle, description)" 
                + " values ('" + this.BookTitleTxtBox.Text + "' , '" + this.DescriptionTxtBox.Text + "')";

            int temp = command.ExecuteNonQuery();
            if (temp > 0 && BookTitleTxtBox.Text != "" && DescriptionTxtBox.Text != "")
            {
                BookTitleTxtBox.Text = null;
                DescriptionTxtBox.Text = null;
                MessageBox.Show("Record Successfully Added");
            }
            else
            {
                MessageBox.Show("Failed to Add a Record");
            }

            conn.Close();
        }
        private void ShowAllBtn_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter Adapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter Adapter1 = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam1);
            OleDbCommandBuilder commBuilder = new OleDbCommandBuilder(Adapter);

            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            Adapter.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
                dataGridView1.Rows.Add(dt.Rows[i][0], dt.Rows[i][1]);
        }
        private void showAllToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.bookrecordsTableAdapter.ShowAll(this.book3DataSet.bookrecords);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
