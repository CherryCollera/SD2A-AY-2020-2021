﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_SanPedro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

        }

        private void HighGPA_Click(object sender, EventArgs e)
        {
            highGPAListBox.Items.Clear();
            const double CUTOFF = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > CUTOFF
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                highGPAListBox.Items.Add(s.LastName + ", " + s.FirstName);
        }

        private void ShowRecordsBtn_Click(object sender, EventArgs e)
        {
            MinGPAListBox.Items.Clear();
            if (minGPAtxt.Text == "")
            {
                MessageBox.Show("No text detected", "TEXT ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            double MinGPA = Convert.ToDouble(minGPAtxt.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodstudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > MinGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodstudents)
                MinGPAListBox.Items.Add(s.LastName + ", " + s.FirstName);
        }

        private void ViewGradeStatBtn_Click(object sender, EventArgs e)
        {
            var gpas =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;
            CountLbl.Text = "Count is " + "\t" + gpas.Count();
            MinLbl.Text = "Lowest is " + "\t" + gpas.Min();
            MaxLbl.Text = "Highest is " + "\t" + gpas.Max();
            AverageLbl.Text = "Average of all GPAs is " + "\t" + gpas.Average();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            GroupGPAListBox.Items.Clear();
            var studgpa =
                from s in this.cartmanCollegeDataSet.tblStudents
                group s by (int)s.GradePointAverage;

            foreach (var GroupGPA in studgpa)
            {
                GroupGPAListBox.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    GroupGPAListBox.Items.Add(s.GradePointAverage + " " + s.LastName);
            }
        }

        private void AboutBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not yet implemented", "Not continued", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void InfoBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Made By: Sebastian Miguel S. San Pedro\nSection: SD2A", "Info");
        }
    }
}
