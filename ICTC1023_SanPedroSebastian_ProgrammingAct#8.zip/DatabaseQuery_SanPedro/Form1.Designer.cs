﻿
namespace DatabaseQuery_SanPedro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_SanPedro.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new DatabaseQuery_SanPedro.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.highGPAListBox = new System.Windows.Forms.ListBox();
            this.HighGpaBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.minGPAtxt = new System.Windows.Forms.TextBox();
            this.ShowRecordsBtn = new System.Windows.Forms.Button();
            this.MinGPAListBox = new System.Windows.Forms.ListBox();
            this.ViewGradeStatBtn = new System.Windows.Forms.Button();
            this.CountLbl = new System.Windows.Forms.Label();
            this.MinLbl = new System.Windows.Forms.Label();
            this.MaxLbl = new System.Windows.Forms.Label();
            this.AverageLbl = new System.Windows.Forms.Label();
            this.GroupRecordsGPABtn = new System.Windows.Forms.Button();
            this.GroupGPAListBox = new System.Windows.Forms.ListBox();
            this.HeadPanel = new System.Windows.Forms.Panel();
            this.InfoBtn = new System.Windows.Forms.Button();
            this.AboutBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.HeadPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(119)))), ((int)(((byte)(134)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(119)))), ((int)(((byte)(134)))));
            this.dataGridView1.Location = new System.Drawing.Point(23, 46);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(501, 202);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.ReadOnly = true;
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 140;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // highGPAListBox
            // 
            this.highGPAListBox.FormattingEnabled = true;
            this.highGPAListBox.ItemHeight = 17;
            this.highGPAListBox.Location = new System.Drawing.Point(23, 289);
            this.highGPAListBox.Margin = new System.Windows.Forms.Padding(4);
            this.highGPAListBox.Name = "highGPAListBox";
            this.highGPAListBox.Size = new System.Drawing.Size(240, 157);
            this.highGPAListBox.TabIndex = 1;
            // 
            // HighGpaBtn
            // 
            this.HighGpaBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(165)))), ((int)(((byte)(115)))));
            this.HighGpaBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HighGpaBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HighGpaBtn.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HighGpaBtn.Location = new System.Drawing.Point(23, 256);
            this.HighGpaBtn.Margin = new System.Windows.Forms.Padding(4);
            this.HighGpaBtn.Name = "HighGpaBtn";
            this.HighGpaBtn.Size = new System.Drawing.Size(240, 24);
            this.HighGpaBtn.TabIndex = 2;
            this.HighGpaBtn.Text = "Show Students with High GPA";
            this.HighGpaBtn.UseVisualStyleBackColor = false;
            this.HighGpaBtn.Click += new System.EventHandler(this.HighGPA_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(271, 260);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter minimum GPA";
            // 
            // minGPAtxt
            // 
            this.minGPAtxt.BackColor = System.Drawing.Color.White;
            this.minGPAtxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.minGPAtxt.Location = new System.Drawing.Point(382, 260);
            this.minGPAtxt.Name = "minGPAtxt";
            this.minGPAtxt.Size = new System.Drawing.Size(142, 16);
            this.minGPAtxt.TabIndex = 4;
            // 
            // ShowRecordsBtn
            // 
            this.ShowRecordsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(165)))), ((int)(((byte)(115)))));
            this.ShowRecordsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowRecordsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ShowRecordsBtn.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowRecordsBtn.Location = new System.Drawing.Point(274, 289);
            this.ShowRecordsBtn.Name = "ShowRecordsBtn";
            this.ShowRecordsBtn.Size = new System.Drawing.Size(100, 23);
            this.ShowRecordsBtn.TabIndex = 5;
            this.ShowRecordsBtn.Text = "Show Records";
            this.ShowRecordsBtn.UseVisualStyleBackColor = false;
            this.ShowRecordsBtn.Click += new System.EventHandler(this.ShowRecordsBtn_Click);
            // 
            // MinGPAListBox
            // 
            this.MinGPAListBox.FormattingEnabled = true;
            this.MinGPAListBox.ItemHeight = 17;
            this.MinGPAListBox.Location = new System.Drawing.Point(382, 289);
            this.MinGPAListBox.Name = "MinGPAListBox";
            this.MinGPAListBox.Size = new System.Drawing.Size(142, 157);
            this.MinGPAListBox.TabIndex = 6;
            // 
            // ViewGradeStatBtn
            // 
            this.ViewGradeStatBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(165)))), ((int)(((byte)(115)))));
            this.ViewGradeStatBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewGradeStatBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ViewGradeStatBtn.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewGradeStatBtn.Location = new System.Drawing.Point(540, 46);
            this.ViewGradeStatBtn.Name = "ViewGradeStatBtn";
            this.ViewGradeStatBtn.Size = new System.Drawing.Size(165, 23);
            this.ViewGradeStatBtn.TabIndex = 7;
            this.ViewGradeStatBtn.Text = "View Grade Statistics";
            this.ViewGradeStatBtn.UseVisualStyleBackColor = false;
            this.ViewGradeStatBtn.Click += new System.EventHandler(this.ViewGradeStatBtn_Click);
            // 
            // CountLbl
            // 
            this.CountLbl.AutoSize = true;
            this.CountLbl.ForeColor = System.Drawing.Color.White;
            this.CountLbl.Location = new System.Drawing.Point(537, 83);
            this.CountLbl.Name = "CountLbl";
            this.CountLbl.Size = new System.Drawing.Size(0, 17);
            this.CountLbl.TabIndex = 8;
            // 
            // MinLbl
            // 
            this.MinLbl.AutoSize = true;
            this.MinLbl.ForeColor = System.Drawing.Color.White;
            this.MinLbl.Location = new System.Drawing.Point(537, 120);
            this.MinLbl.Name = "MinLbl";
            this.MinLbl.Size = new System.Drawing.Size(0, 17);
            this.MinLbl.TabIndex = 9;
            // 
            // MaxLbl
            // 
            this.MaxLbl.AutoSize = true;
            this.MaxLbl.ForeColor = System.Drawing.Color.White;
            this.MaxLbl.Location = new System.Drawing.Point(537, 157);
            this.MaxLbl.Name = "MaxLbl";
            this.MaxLbl.Size = new System.Drawing.Size(0, 17);
            this.MaxLbl.TabIndex = 10;
            // 
            // AverageLbl
            // 
            this.AverageLbl.AutoSize = true;
            this.AverageLbl.ForeColor = System.Drawing.Color.White;
            this.AverageLbl.Location = new System.Drawing.Point(537, 194);
            this.AverageLbl.Name = "AverageLbl";
            this.AverageLbl.Size = new System.Drawing.Size(0, 17);
            this.AverageLbl.TabIndex = 11;
            // 
            // GroupRecordsGPABtn
            // 
            this.GroupRecordsGPABtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(165)))), ((int)(((byte)(115)))));
            this.GroupRecordsGPABtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GroupRecordsGPABtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GroupRecordsGPABtn.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupRecordsGPABtn.Location = new System.Drawing.Point(540, 256);
            this.GroupRecordsGPABtn.Name = "GroupRecordsGPABtn";
            this.GroupRecordsGPABtn.Size = new System.Drawing.Size(165, 23);
            this.GroupRecordsGPABtn.TabIndex = 12;
            this.GroupRecordsGPABtn.Text = "Group Records by GPA";
            this.GroupRecordsGPABtn.UseVisualStyleBackColor = false;
            this.GroupRecordsGPABtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // GroupGPAListBox
            // 
            this.GroupGPAListBox.FormattingEnabled = true;
            this.GroupGPAListBox.ItemHeight = 17;
            this.GroupGPAListBox.Location = new System.Drawing.Point(540, 289);
            this.GroupGPAListBox.Name = "GroupGPAListBox";
            this.GroupGPAListBox.Size = new System.Drawing.Size(165, 157);
            this.GroupGPAListBox.TabIndex = 13;
            // 
            // HeadPanel
            // 
            this.HeadPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(54)))), ((int)(((byte)(66)))));
            this.HeadPanel.Controls.Add(this.InfoBtn);
            this.HeadPanel.Controls.Add(this.AboutBtn);
            this.HeadPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeadPanel.Location = new System.Drawing.Point(0, 0);
            this.HeadPanel.Name = "HeadPanel";
            this.HeadPanel.Size = new System.Drawing.Size(727, 39);
            this.HeadPanel.TabIndex = 14;
            // 
            // InfoBtn
            // 
            this.InfoBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.InfoBtn.FlatAppearance.BorderSize = 0;
            this.InfoBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(72)))), ((int)(((byte)(88)))));
            this.InfoBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(72)))), ((int)(((byte)(88)))));
            this.InfoBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InfoBtn.Image = global::DatabaseQuery_SanPedro.Properties.Resources.icons8_info_32;
            this.InfoBtn.Location = new System.Drawing.Point(671, 0);
            this.InfoBtn.Name = "InfoBtn";
            this.InfoBtn.Size = new System.Drawing.Size(34, 36);
            this.InfoBtn.TabIndex = 1;
            this.InfoBtn.UseVisualStyleBackColor = true;
            this.InfoBtn.Click += new System.EventHandler(this.InfoBtn_Click);
            // 
            // AboutBtn
            // 
            this.AboutBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AboutBtn.FlatAppearance.BorderSize = 0;
            this.AboutBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(72)))), ((int)(((byte)(88)))));
            this.AboutBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(72)))), ((int)(((byte)(88)))));
            this.AboutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AboutBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AboutBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(214)))));
            this.AboutBtn.Image = global::DatabaseQuery_SanPedro.Properties.Resources.icons8_database_32;
            this.AboutBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AboutBtn.Location = new System.Drawing.Point(23, 0);
            this.AboutBtn.Name = "AboutBtn";
            this.AboutBtn.Size = new System.Drawing.Size(263, 39);
            this.AboutBtn.TabIndex = 0;
            this.AboutBtn.Text = "Database Query San Pedro";
            this.AboutBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.AboutBtn.UseVisualStyleBackColor = true;
            this.AboutBtn.Click += new System.EventHandler(this.AboutBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(72)))), ((int)(((byte)(88)))));
            this.ClientSize = new System.Drawing.Size(727, 463);
            this.Controls.Add(this.HeadPanel);
            this.Controls.Add(this.GroupGPAListBox);
            this.Controls.Add(this.GroupRecordsGPABtn);
            this.Controls.Add(this.AverageLbl);
            this.Controls.Add(this.MaxLbl);
            this.Controls.Add(this.MinLbl);
            this.Controls.Add(this.CountLbl);
            this.Controls.Add(this.ViewGradeStatBtn);
            this.Controls.Add(this.MinGPAListBox);
            this.Controls.Add(this.ShowRecordsBtn);
            this.Controls.Add(this.minGPAtxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HighGpaBtn);
            this.Controls.Add(this.highGPAListBox);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database Query San Pedro";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.HeadPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.ListBox highGPAListBox;
        private System.Windows.Forms.Button HighGpaBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox minGPAtxt;
        private System.Windows.Forms.Button ShowRecordsBtn;
        private System.Windows.Forms.ListBox MinGPAListBox;
        private System.Windows.Forms.Button ViewGradeStatBtn;
        private System.Windows.Forms.Label CountLbl;
        private System.Windows.Forms.Label MinLbl;
        private System.Windows.Forms.Label MaxLbl;
        private System.Windows.Forms.Label AverageLbl;
        private System.Windows.Forms.Button GroupRecordsGPABtn;
        private System.Windows.Forms.ListBox GroupGPAListBox;
        private System.Windows.Forms.Panel HeadPanel;
        private System.Windows.Forms.Button AboutBtn;
        private System.Windows.Forms.Button InfoBtn;
    }
}

