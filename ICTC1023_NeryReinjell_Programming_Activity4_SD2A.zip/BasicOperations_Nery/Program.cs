﻿using System;

namespace BasicOperations_Nery
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.AcceptNum();

            Sum sum = new Sum();
            Difference diff = new Difference();
            Product prod = new Product();
            Quotient quot = new Quotient();
            Remainder rem = new Remainder();


            Console.WriteLine("\nSum: {0}", sum.SumOf());
            Console.WriteLine("Difference: {0}", diff.DiffOf());
            Console.WriteLine("Product: {0}", prod.ProductOf());
            Console.WriteLine("Quotient: {0}", quot.QuotientOf());
            Console.WriteLine("Remainder: {0}", rem.RemainderOf());
        }
    }
}