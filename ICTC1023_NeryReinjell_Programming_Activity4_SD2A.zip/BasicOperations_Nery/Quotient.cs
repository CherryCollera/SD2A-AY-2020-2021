﻿class Quotient:DeclareVar
{
    public double QuotientOf()
    {
        double quot = num1 / num2;
        return quot;
    }
}