﻿class Product:DeclareVar
{
    public double ProductOf()
    {
        double prod = num1 * num2;
        return prod;
    }
}