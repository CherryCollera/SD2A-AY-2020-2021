﻿class DeclareVar
{
    public static double num1, num2;


    public static double Value1
    {
        get { return num1; }
        set { num1 = value; }
    }
    public static double Value2
    {
        get { return num2; }
        set { num2 = value; }
    }
}