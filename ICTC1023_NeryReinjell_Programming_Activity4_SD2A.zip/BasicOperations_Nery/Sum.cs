﻿class Sum:DeclareVar
{
    public double SumOf()
    {
        double sum = num1 + num2;
        return sum;
    }
}