﻿class Input
{
    public void AcceptNum()
    {
        System.Console.Write("Enter 1st Number: ");
        DeclareVar.Value1 = System.Convert.ToDouble(System.Console.ReadLine());
        System.Console.Write("Enter 2nd Number: ");
        DeclareVar.Value2 = System.Convert.ToDouble(System.Console.ReadLine());
    }
}