﻿class Remainder:DeclareVar
{
    public double RemainderOf()
    {
        double rem = num1 % num2;
        return rem;
    }
}