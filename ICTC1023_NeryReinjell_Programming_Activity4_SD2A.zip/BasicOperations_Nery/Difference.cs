﻿class Difference:DeclareVar
{
    public double DiffOf()
    {
        double diff = num1 - num2;
        return diff;
    }
}
