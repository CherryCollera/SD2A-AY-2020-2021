﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace average_of_grades
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            double grade, grade1, grade2, grade3, grade4, ave;

            Console.WriteLine("Enter Five Numbers: ");
            grade = Convert.ToDouble(Console.ReadLine());
            grade1 = Convert.ToDouble(Console.ReadLine());
            grade2 = Convert.ToDouble(Console.ReadLine());
            grade3 = Convert.ToDouble(Console.ReadLine());
            grade4 = Convert.ToDouble(Console.ReadLine());
            ave = grade + grade1 + grade2 + grade3 + grade4;
            Console.WriteLine("Average is {0:0.000}", ave / 5);

            Console.ReadKey();
        }
    }
}
