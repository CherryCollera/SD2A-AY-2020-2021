﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace five_basic_operation
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Sum = {0}", num1 + num2);
            Console.WriteLine("Diff = {0}", num1 - num2);
            Console.WriteLine("Prod = {0}", num1 * num2);
            Console.WriteLine("Quo = {0}", num1 / num2);
            Console.WriteLine("Mod = {0}", num1 % num2);

            Console.ReadKey();
        }
    }
}
