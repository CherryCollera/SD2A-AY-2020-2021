﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace declaring_constant
{
    class sabasozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double AreaCircle, area;

            Console.Write("Enter Area: ");
            area = Convert.ToDouble(Console.ReadLine());

            AreaCircle = pi * area * area;

            Console.Write("Radius: {0:0.0000}", area + ", Area: ", pi * area * area);
            Console.Write(", Area: {0}", pi * area * area);
            Console.ReadKey();
        }
    }
}
