﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sabadozyrillejoym_pajarillojethro
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number:");
            int firstNum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            int secondNum = Convert.ToInt32(Console.ReadLine());

            Console.Write("Sum = {0}", firstNum + secondNum);
            Console.ReadKey();

        }
    }
}
