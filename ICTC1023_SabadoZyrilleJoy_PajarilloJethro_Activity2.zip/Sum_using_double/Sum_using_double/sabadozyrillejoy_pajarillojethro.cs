﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Sum_using_double
{
    class sabadozyrillejoy_pajarillojethro
    {
        static void Main(string[] args)
        {
            double firstNum, secondNum;

            Console.Write("Enter Number: ");
            firstNum = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Number: ");
            secondNum = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Sum = {0}", firstNum + secondNum);

            Console.ReadKey();
        }
    }
}
