﻿using ClassExample1_Bantay;
    class Print //Creating 2nd class
    {
    public void PrintDetails()
    {
        Accept a = new Accept();
        a.AcceptDetails();
        System.Console.Write("\nHello " + a.firstname + " " + a.lastname
            + "!!!\n You have created classes in OOP");
        MyProfile mp = new MyProfile();
        mp.DisplayProfile();
    }
    }

