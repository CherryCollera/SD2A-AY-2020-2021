﻿/*Creating classes in OOP
 * Author: Louisse Anne Bantay
 * Date: March 22, 2021
 */

using System;
namespace ClassExample1_Bantay
{
    class Program //Creating 4th class
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
