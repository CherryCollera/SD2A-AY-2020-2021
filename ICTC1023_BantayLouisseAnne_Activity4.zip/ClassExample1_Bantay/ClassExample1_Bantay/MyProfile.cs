﻿    class MyProfile //Creating 3rd class
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tLouisse Anne Bantay");
            System.Console.WriteLine("Birthday:\t\tSeptember 23, 2001");
            System.Console.WriteLine("Course:\t\t\tBS in Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\tSecond Year");
            System.Console.WriteLine("Section:\t\tSD2A");
            System.Console.ReadLine();
        }
    }

