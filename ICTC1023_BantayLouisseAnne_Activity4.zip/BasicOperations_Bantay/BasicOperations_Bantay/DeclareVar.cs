﻿using BasicOperations_Bantay;

    class DeclareVar
    {
        public static double num1, num2;
    }

