﻿    class Quotient
    {
    public double ComputeQuo()
    {
        double quo = DeclareVar.num1 / DeclareVar.num2;
        return quo;
    }

}

