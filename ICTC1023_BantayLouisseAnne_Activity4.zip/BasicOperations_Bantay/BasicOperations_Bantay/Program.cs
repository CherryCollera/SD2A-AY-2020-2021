﻿using System;

namespace BasicOperations_Bantay
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.InputVal();

            Sum s = new Sum();
            Difference d = new Difference();
            Product p = new Product();
            Quotient q = new Quotient();
            Remainder r = new Remainder();

            Console.WriteLine("Sum = {0}", s.ComputeSum());
            Console.WriteLine("Difference = {0}", d.ComputeDiff());
            Console.WriteLine("Product = {0}", p.ComputeProd());
            Console.WriteLine("Quotient = {0:0.00}", q.ComputeQuo());
            Console.WriteLine("Remainder = {0}", r.ComputeRem());
            Console.ReadKey();
        }
    }
}
