﻿  class Remainder
    {
    public double ComputeRem()
    {
        double rem = DeclareVar.num1 % DeclareVar.num2;
        return rem;
    }

}

