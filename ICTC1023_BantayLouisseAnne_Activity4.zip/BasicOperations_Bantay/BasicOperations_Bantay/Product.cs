﻿    class Product
    {
    public double ComputeProd()
    {
        double prod = DeclareVar.num1 * DeclareVar.num2;
        return prod;
    }
}

