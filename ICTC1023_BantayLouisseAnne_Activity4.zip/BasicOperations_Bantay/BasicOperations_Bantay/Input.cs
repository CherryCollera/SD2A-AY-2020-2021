﻿class Input
    {
        public void InputVal()
        {
            System.Console.Write("Enter first number: ");
            DeclareVar.num1 = System.Convert.ToDouble(System.Console.ReadLine());
            System.Console.Write("Enter second number: ");
            DeclareVar.num2 = System.Convert.ToDouble(System.Console.ReadLine());
        }
    }

