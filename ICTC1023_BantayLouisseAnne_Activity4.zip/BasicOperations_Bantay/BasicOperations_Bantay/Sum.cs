﻿    class Sum
    {
        public double ComputeSum()
    {
        double sum = DeclareVar.num1 + DeclareVar.num2;
        return sum;     
    }

    }

