﻿    class Difference
    {
    public double ComputeDiff()
    {
        double diff = DeclareVar.num1 - DeclareVar.num2;
        return diff;
    }

}

