﻿
namespace DataBinding2_Nery
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet = new DataBinding2_Nery.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DataBinding2_Nery.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.btn_ShowRecords = new System.Windows.Forms.Button();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.btn_GroupbyGPA = new System.Windows.Forms.Button();
            this.listBoxGroupByGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(24, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(442, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.Location = new System.Drawing.Point(24, 181);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(158, 23);
            this.btn_HighGPA.TabIndex = 1;
            this.btn_HighGPA.Text = "Show Students with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = true;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_HighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.Location = new System.Drawing.Point(24, 210);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(158, 108);
            this.listBox_HighGPA.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(253, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter Minimum GPA:";
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(363, 183);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(103, 20);
            this.textBox_MinGPA.TabIndex = 4;
            // 
            // btn_ShowRecords
            // 
            this.btn_ShowRecords.Location = new System.Drawing.Point(256, 210);
            this.btn_ShowRecords.Name = "btn_ShowRecords";
            this.btn_ShowRecords.Size = new System.Drawing.Size(101, 23);
            this.btn_ShowRecords.TabIndex = 5;
            this.btn_ShowRecords.Text = "Show Records";
            this.btn_ShowRecords.UseVisualStyleBackColor = true;
            this.btn_ShowRecords.Click += new System.EventHandler(this.btn_ShowRecords_Click);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.Location = new System.Drawing.Point(256, 239);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(210, 82);
            this.listBox_MinGPA.TabIndex = 6;
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(498, 25);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(158, 23);
            this.btn_ViewGradeStat.TabIndex = 7;
            this.btn_ViewGradeStat.Text = "View Grade Statistics";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(525, 70);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(35, 13);
            this.labelCount.TabIndex = 8;
            this.labelCount.Text = "label2";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(525, 102);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(35, 13);
            this.labelMin.TabIndex = 9;
            this.labelMin.Text = "label3";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(525, 130);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(35, 13);
            this.labelMax.TabIndex = 10;
            this.labelMax.Text = "label4";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(525, 162);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(35, 13);
            this.labelAverage.TabIndex = 11;
            this.labelAverage.Text = "label5";
            // 
            // btn_GroupbyGPA
            // 
            this.btn_GroupbyGPA.Location = new System.Drawing.Point(684, 25);
            this.btn_GroupbyGPA.Name = "btn_GroupbyGPA";
            this.btn_GroupbyGPA.Size = new System.Drawing.Size(158, 23);
            this.btn_GroupbyGPA.TabIndex = 12;
            this.btn_GroupbyGPA.Text = "Group Records by GPA";
            this.btn_GroupbyGPA.UseVisualStyleBackColor = true;
            this.btn_GroupbyGPA.Click += new System.EventHandler(this.btn_GroupbyGPA_Click);
            // 
            // listBoxGroupByGPA
            // 
            this.listBoxGroupByGPA.FormattingEnabled = true;
            this.listBoxGroupByGPA.Location = new System.Drawing.Point(684, 70);
            this.listBoxGroupByGPA.Name = "listBoxGroupByGPA";
            this.listBoxGroupByGPA.Size = new System.Drawing.Size(158, 186);
            this.listBoxGroupByGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 450);
            this.Controls.Add(this.listBoxGroupByGPA);
            this.Controls.Add(this.btn_GroupbyGPA);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btn_ViewGradeStat);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.btn_ShowRecords);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.Button btn_ShowRecords;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button btn_GroupbyGPA;
        private System.Windows.Forms.ListBox listBoxGroupByGPA;
    }
}

