﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
February 25, 2021
This program will display the Name you Input*/

namespace Sample3_InputMyName
{
    class Inputs
    {
        //Fields that's inclusive only to the class Profile
        private string name;

        //Method for getting the input and setting the value
        public string Name
        {
            get{ 
                return name; 
            }
            set{ 
                name = value; 
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Main Method where you input the value and print.
            Inputs Iname = new Inputs();
            System.Console.Write("Enter your Name (FirstName LastName): ");
            Iname.Name = System.Console.ReadLine();
            System.Console.WriteLine("\nHello "+Iname.Name+"!!!\nWelcome to OOP Environment.");

        }
    }
}
