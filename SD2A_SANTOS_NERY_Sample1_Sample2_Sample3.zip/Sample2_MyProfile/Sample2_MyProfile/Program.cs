﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
February 25, 2021
This program will display My Profile*/

namespace Sample2_MyProfile
{
    class Profile
    {
        //Fields that are inclusive only to the class Profile
        private string name;
        private string bdate;
        private string course;
        private string year;
        private string section;

        //Methods for getting the input and setting the value
        public string Name  
        {
            get{ 
                return name; 
            }
            set { 
                name = value; 
            }
        }

        public string Bdate  
        {
            get{ 
                return bdate; 
            }
            set { 
                bdate = value; 
            }
        }

        public string Course   
        {
            get { 
                return course; 
            }
            set { 
                course = value; 
            }
        }

        public string Year   
        {
            get { 
                return year; 
            }
            set { 
                year = value; 
            }
        }

        public string Section  
        {
            get { 
                return section; 
            }
            set { 
                section = value; 
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Main Method where you input the value and print.
            Profile MyProf = new Profile();
            MyProf.Name = "Joshua M. Santos";
            MyProf.Bdate = "June 6";
            MyProf.Course = "BS Computer Science";
            MyProf.Year = "II";
            MyProf.Section = "A";
            System.Console.WriteLine("Name: "+ MyProf.Name+"\nDate: "+ MyProf.Bdate+ "\nCourse: " + MyProf.Course
            + "\nYear: " + MyProf.Year+ "\nSection: " + MyProf.Section);
            System.Console.ReadLine();
        }
    }
}
