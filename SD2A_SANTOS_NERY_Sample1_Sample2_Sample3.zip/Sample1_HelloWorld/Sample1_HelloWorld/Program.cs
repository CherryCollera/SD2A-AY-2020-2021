﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
February 25, 2021
This program will display the phrase "Hello World!"*/

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
