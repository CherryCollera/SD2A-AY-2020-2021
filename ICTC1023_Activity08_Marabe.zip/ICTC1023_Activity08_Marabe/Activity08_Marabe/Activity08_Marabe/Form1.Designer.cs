﻿
namespace Activity08_Marabe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new Activity08_Marabe.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new Activity08_Marabe.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.lbl_Count = new System.Windows.Forms.Label();
            this.lbl_Min = new System.Windows.Forms.Label();
            this.lbl_Max = new System.Windows.Forms.Label();
            this.lbl_Ave = new System.Windows.Forms.Label();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.lbl_MinGPA = new System.Windows.Forms.Label();
            this.txt_MinGPA = new System.Windows.Forms.TextBox();
            this.btn_ShowRecords = new System.Windows.Forms.Button();
            this.listBox1_MinGPA = new System.Windows.Forms.ListBox();
            this.btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.listBox1_GroupGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(17, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(623, 353);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 50;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 101;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 101;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 162;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(667, 25);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(264, 39);
            this.btn_ViewGradeStat.TabIndex = 1;
            this.btn_ViewGradeStat.Text = "View Grade Statistic";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // lbl_Count
            // 
            this.lbl_Count.AutoSize = true;
            this.lbl_Count.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Location = new System.Drawing.Point(663, 93);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Size = new System.Drawing.Size(75, 26);
            this.lbl_Count.TabIndex = 2;
            this.lbl_Count.Text = "Count";
            // 
            // lbl_Min
            // 
            this.lbl_Min.AutoSize = true;
            this.lbl_Min.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Min.Location = new System.Drawing.Point(663, 147);
            this.lbl_Min.Name = "lbl_Min";
            this.lbl_Min.Size = new System.Drawing.Size(113, 26);
            this.lbl_Min.TabIndex = 3;
            this.lbl_Min.Text = "Minimum";
            // 
            // lbl_Max
            // 
            this.lbl_Max.AutoSize = true;
            this.lbl_Max.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Max.Location = new System.Drawing.Point(663, 200);
            this.lbl_Max.Name = "lbl_Max";
            this.lbl_Max.Size = new System.Drawing.Size(117, 26);
            this.lbl_Max.TabIndex = 4;
            this.lbl_Max.Text = "Maximum";
            // 
            // lbl_Ave
            // 
            this.lbl_Ave.AutoSize = true;
            this.lbl_Ave.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ave.Location = new System.Drawing.Point(663, 256);
            this.lbl_Ave.Name = "lbl_Ave";
            this.lbl_Ave.Size = new System.Drawing.Size(95, 26);
            this.lbl_Ave.TabIndex = 5;
            this.lbl_Ave.Text = "Average";
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HighGPA.Location = new System.Drawing.Point(17, 408);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(264, 39);
            this.btn_HighGPA.TabIndex = 6;
            this.btn_HighGPA.Text = "Show Student with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = true;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_HighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 22;
            this.listBox_HighGPA.Location = new System.Drawing.Point(21, 456);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(259, 202);
            this.listBox_HighGPA.TabIndex = 7;
            // 
            // lbl_MinGPA
            // 
            this.lbl_MinGPA.AutoSize = true;
            this.lbl_MinGPA.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MinGPA.Location = new System.Drawing.Point(300, 417);
            this.lbl_MinGPA.Name = "lbl_MinGPA";
            this.lbl_MinGPA.Size = new System.Drawing.Size(190, 22);
            this.lbl_MinGPA.TabIndex = 8;
            this.lbl_MinGPA.Text = "Enter minimum GPA: ";
            // 
            // txt_MinGPA
            // 
            this.txt_MinGPA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MinGPA.Location = new System.Drawing.Point(486, 413);
            this.txt_MinGPA.Name = "txt_MinGPA";
            this.txt_MinGPA.Size = new System.Drawing.Size(154, 30);
            this.txt_MinGPA.TabIndex = 9;
            this.txt_MinGPA.TextChanged += new System.EventHandler(this.txt_MinGPA_TextChanged);
            // 
            // btn_ShowRecords
            // 
            this.btn_ShowRecords.Enabled = false;
            this.btn_ShowRecords.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ShowRecords.Location = new System.Drawing.Point(392, 449);
            this.btn_ShowRecords.Name = "btn_ShowRecords";
            this.btn_ShowRecords.Size = new System.Drawing.Size(161, 39);
            this.btn_ShowRecords.TabIndex = 10;
            this.btn_ShowRecords.Text = "Show Records";
            this.btn_ShowRecords.UseVisualStyleBackColor = true;
            this.btn_ShowRecords.Click += new System.EventHandler(this.btn_ShowRecords_Click);
            // 
            // listBox1_MinGPA
            // 
            this.listBox1_MinGPA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1_MinGPA.FormattingEnabled = true;
            this.listBox1_MinGPA.ItemHeight = 22;
            this.listBox1_MinGPA.Location = new System.Drawing.Point(304, 494);
            this.listBox1_MinGPA.Name = "listBox1_MinGPA";
            this.listBox1_MinGPA.Size = new System.Drawing.Size(336, 180);
            this.listBox1_MinGPA.TabIndex = 11;
            // 
            // btn_GroupRecordsGPA
            // 
            this.btn_GroupRecordsGPA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GroupRecordsGPA.Location = new System.Drawing.Point(691, 408);
            this.btn_GroupRecordsGPA.Name = "btn_GroupRecordsGPA";
            this.btn_GroupRecordsGPA.Size = new System.Drawing.Size(264, 39);
            this.btn_GroupRecordsGPA.TabIndex = 12;
            this.btn_GroupRecordsGPA.Text = "Group Records by GPA";
            this.btn_GroupRecordsGPA.UseVisualStyleBackColor = true;
            this.btn_GroupRecordsGPA.Click += new System.EventHandler(this.btn_GroupRecordsGPA_Click);
            // 
            // listBox1_GroupGPA
            // 
            this.listBox1_GroupGPA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1_GroupGPA.FormattingEnabled = true;
            this.listBox1_GroupGPA.ItemHeight = 22;
            this.listBox1_GroupGPA.Location = new System.Drawing.Point(691, 456);
            this.listBox1_GroupGPA.Name = "listBox1_GroupGPA";
            this.listBox1_GroupGPA.Size = new System.Drawing.Size(264, 202);
            this.listBox1_GroupGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 690);
            this.Controls.Add(this.listBox1_GroupGPA);
            this.Controls.Add(this.btn_GroupRecordsGPA);
            this.Controls.Add(this.listBox1_MinGPA);
            this.Controls.Add(this.btn_ShowRecords);
            this.Controls.Add(this.txt_MinGPA);
            this.Controls.Add(this.lbl_MinGPA);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btn_HighGPA);
            this.Controls.Add(this.lbl_Ave);
            this.Controls.Add(this.lbl_Max);
            this.Controls.Add(this.lbl_Min);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.btn_ViewGradeStat);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.Label lbl_Count;
        private System.Windows.Forms.Label lbl_Min;
        private System.Windows.Forms.Label lbl_Max;
        private System.Windows.Forms.Label lbl_Ave;
        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label lbl_MinGPA;
        private System.Windows.Forms.TextBox txt_MinGPA;
        private System.Windows.Forms.Button btn_ShowRecords;
        private System.Windows.Forms.ListBox listBox1_MinGPA;
        private System.Windows.Forms.Button btn_GroupRecordsGPA;
        private System.Windows.Forms.ListBox listBox1_GroupGPA;
    }
}

