﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity08_Marabe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            lbl_Ave.Visible = false;
            lbl_Count.Visible = false;
            lbl_Max.Visible = false;
            lbl_Min.Visible = false;
        }

        private void btn_ShowRecords_Click(object sender, EventArgs e)
        {
            listBox1_MinGPA.Items.Clear();
            double miniGPA = Convert.ToDouble(txt_MinGPA.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > miniGPA
                orderby s.GradePointAverage descending
                select s;

            foreach (var s in goodStudents)
                listBox1_MinGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void btn_HighGPA_Click(object sender, EventArgs e)
        {
            listBox_HighGPA.Items.Clear();
            const double CUTOFF = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > CUTOFF
                orderby s.GradePointAverage descending
                select s;

            foreach (var s in goodStudents)
                listBox_HighGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void txt_MinGPA_TextChanged(object sender, EventArgs e)
        {
            String text = txt_MinGPA.Text;
            if(text == "")
            {
                btn_ShowRecords.Enabled = false;
            }
            else
            {
                btn_ShowRecords.Enabled = true;
            }
        }

        private void btn_GroupRecordsGPA_Click(object sender, EventArgs e)
        {
            listBox1_GroupGPA.Items.Clear();
            var studGPA =
                from s in this.cartmanCollegeDataSet.tblStudents
                group s by (int)s.GradePointAverage;

            foreach(var GroupGPA in studGPA)
            {
                listBox1_GroupGPA.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    listBox1_GroupGPA.Items.Add(" " + s.GradePointAverage + " " + s.LastName);

            }

        }

        private void btn_ViewGradeStat_Click(object sender, EventArgs e)
        {
            lbl_Ave.Visible = true;
            lbl_Count.Visible = true;
            lbl_Max.Visible = true;
            lbl_Min.Visible = true;

            var gpas =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;
            lbl_Count.Text = "Count is \t" + gpas.Count();
            lbl_Min.Text = "Lowest is \t" + gpas.Min();
            lbl_Max.Text = "Highest is \t" + gpas.Max();
            lbl_Ave.Text = "Average of all GPA is \t" + gpas.Average();
        }
    }
}
