﻿
namespace Databinding_Santos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.BscsToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBscsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.Address_SamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBySamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastname_A_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastname_AToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByBSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBy2ndYearToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBy2ndYearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBy2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBy2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByConsonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByConsonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new Databinding_Santos.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new Databinding_Santos.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.BscsToolStrip.SuspendLayout();
            this.Address_SamalToolStrip.SuspendLayout();
            this.lastname_A_CToolStrip.SuspendLayout();
            this.fillByBSITToolStrip.SuspendLayout();
            this.fillBy2ndYearToolStrip.SuspendLayout();
            this.fillBy2BToolStrip.SuspendLayout();
            this.fillByConsonantToolStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(192, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(597, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "STUDENT RECORDS MONITORING SYSTEM";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(2, 66);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(946, 275);
            this.dataGridView1.TabIndex = 1;
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(458, 398);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 2;
            this.refreshToolStrip.Text = "refreshToolStrip";
            this.refreshToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.refreshToolStrip_ItemClicked);
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // BscsToolStrip
            // 
            this.BscsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.BscsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBscsToolStripButton});
            this.BscsToolStrip.Location = new System.Drawing.Point(515, 359);
            this.BscsToolStrip.Name = "BscsToolStrip";
            this.BscsToolStrip.Size = new System.Drawing.Size(50, 25);
            this.BscsToolStrip.TabIndex = 3;
            this.BscsToolStrip.Text = "fillByBscsToolStrip";
            // 
            // fillByBscsToolStripButton
            // 
            this.fillByBscsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBscsToolStripButton.Name = "fillByBscsToolStripButton";
            this.fillByBscsToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.fillByBscsToolStripButton.Text = "BSCS";
            this.fillByBscsToolStripButton.Click += new System.EventHandler(this.fillByBscsToolStripButton_Click);
            // 
            // Address_SamalToolStrip
            // 
            this.Address_SamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.Address_SamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBySamalToolStripButton});
            this.Address_SamalToolStrip.Location = new System.Drawing.Point(321, 359);
            this.Address_SamalToolStrip.Name = "Address_SamalToolStrip";
            this.Address_SamalToolStrip.Size = new System.Drawing.Size(55, 25);
            this.Address_SamalToolStrip.TabIndex = 4;
            this.Address_SamalToolStrip.Text = "fillBySamalToolStrip";
            // 
            // fillBySamalToolStripButton
            // 
            this.fillBySamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBySamalToolStripButton.Name = "fillBySamalToolStripButton";
            this.fillBySamalToolStripButton.Size = new System.Drawing.Size(43, 22);
            this.fillBySamalToolStripButton.Text = "Samal";
            this.fillBySamalToolStripButton.Click += new System.EventHandler(this.fillBySamalToolStripButton_Click);
            // 
            // lastname_A_CToolStrip
            // 
            this.lastname_A_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastname_A_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastname_AToolStripButton});
            this.lastname_A_CToolStrip.Location = new System.Drawing.Point(139, 359);
            this.lastname_A_CToolStrip.Name = "lastname_A_CToolStrip";
            this.lastname_A_CToolStrip.Size = new System.Drawing.Size(157, 25);
            this.lastname_A_CToolStrip.TabIndex = 5;
            this.lastname_A_CToolStrip.Text = "lastname_AToolStrip";
            // 
            // lastname_AToolStripButton
            // 
            this.lastname_AToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastname_AToolStripButton.Name = "lastname_AToolStripButton";
            this.lastname_AToolStripButton.Size = new System.Drawing.Size(145, 22);
            this.lastname_AToolStripButton.Text = "Lastname_Starts_with_A&C";
            this.lastname_AToolStripButton.Click += new System.EventHandler(this.lastname_AToolStripButton_Click);
            // 
            // fillByBSITToolStrip
            // 
            this.fillByBSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByBSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBSITToolStripButton});
            this.fillByBSITToolStrip.Location = new System.Drawing.Point(70, 359);
            this.fillByBSITToolStrip.Name = "fillByBSITToolStrip";
            this.fillByBSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.fillByBSITToolStrip.TabIndex = 6;
            this.fillByBSITToolStrip.Text = "fillByBSITToolStrip";
            // 
            // fillByBSITToolStripButton
            // 
            this.fillByBSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBSITToolStripButton.Name = "fillByBSITToolStripButton";
            this.fillByBSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.fillByBSITToolStripButton.Text = "BSIT";
            this.fillByBSITToolStripButton.Click += new System.EventHandler(this.fillByBSITToolStripButton_Click);
            // 
            // fillBy2ndYearToolStrip
            // 
            this.fillBy2ndYearToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBy2ndYearToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBy2ndYearToolStripButton});
            this.fillBy2ndYearToolStrip.Location = new System.Drawing.Point(597, 359);
            this.fillBy2ndYearToolStrip.Name = "fillBy2ndYearToolStrip";
            this.fillBy2ndYearToolStrip.Size = new System.Drawing.Size(65, 25);
            this.fillBy2ndYearToolStrip.TabIndex = 7;
            this.fillBy2ndYearToolStrip.Text = "fillBy2ndYearToolStrip";
            // 
            // fillBy2ndYearToolStripButton
            // 
            this.fillBy2ndYearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy2ndYearToolStripButton.Name = "fillBy2ndYearToolStripButton";
            this.fillBy2ndYearToolStripButton.Size = new System.Drawing.Size(53, 22);
            this.fillBy2ndYearToolStripButton.Text = "2ndYear";
            this.fillBy2ndYearToolStripButton.Click += new System.EventHandler(this.fillBy2ndYearToolStripButton_Click);
            // 
            // fillBy2BToolStrip
            // 
            this.fillBy2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBy2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBy2BToolStripButton});
            this.fillBy2BToolStrip.Location = new System.Drawing.Point(409, 359);
            this.fillBy2BToolStrip.Name = "fillBy2BToolStrip";
            this.fillBy2BToolStrip.Size = new System.Drawing.Size(75, 25);
            this.fillBy2BToolStrip.TabIndex = 8;
            this.fillBy2BToolStrip.Text = "fillBy2BToolStrip";
            // 
            // fillBy2BToolStripButton
            // 
            this.fillBy2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy2BToolStripButton.Name = "fillBy2BToolStripButton";
            this.fillBy2BToolStripButton.Size = new System.Drawing.Size(63, 22);
            this.fillBy2BToolStripButton.Text = "Section2B";
            this.fillBy2BToolStripButton.Click += new System.EventHandler(this.fillBy2BToolStripButton_Click);
            // 
            // fillByConsonantToolStrip
            // 
            this.fillByConsonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByConsonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByConsonantToolStripButton});
            this.fillByConsonantToolStrip.Location = new System.Drawing.Point(692, 359);
            this.fillByConsonantToolStrip.Name = "fillByConsonantToolStrip";
            this.fillByConsonantToolStrip.Size = new System.Drawing.Size(200, 25);
            this.fillByConsonantToolStrip.TabIndex = 9;
            this.fillByConsonantToolStrip.Text = "fillByConsonantToolStrip";
            // 
            // fillByConsonantToolStripButton
            // 
            this.fillByConsonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByConsonantToolStripButton.Name = "fillByConsonantToolStripButton";
            this.fillByConsonantToolStripButton.Size = new System.Drawing.Size(188, 22);
            this.fillByConsonantToolStripButton.Text = "Firstname_Starts_with_Consonant";
            this.fillByConsonantToolStripButton.Click += new System.EventHandler(this.fillByConsonantToolStripButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(952, 68);
            this.panel1.TabIndex = 10;
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(950, 440);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.fillByConsonantToolStrip);
            this.Controls.Add(this.fillBy2BToolStrip);
            this.Controls.Add(this.fillBy2ndYearToolStrip);
            this.Controls.Add(this.fillByBSITToolStrip);
            this.Controls.Add(this.lastname_A_CToolStrip);
            this.Controls.Add(this.Address_SamalToolStrip);
            this.Controls.Add(this.BscsToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.BscsToolStrip.ResumeLayout(false);
            this.BscsToolStrip.PerformLayout();
            this.Address_SamalToolStrip.ResumeLayout(false);
            this.Address_SamalToolStrip.PerformLayout();
            this.lastname_A_CToolStrip.ResumeLayout(false);
            this.lastname_A_CToolStrip.PerformLayout();
            this.fillByBSITToolStrip.ResumeLayout(false);
            this.fillByBSITToolStrip.PerformLayout();
            this.fillBy2ndYearToolStrip.ResumeLayout(false);
            this.fillBy2ndYearToolStrip.PerformLayout();
            this.fillBy2BToolStrip.ResumeLayout(false);
            this.fillBy2BToolStrip.PerformLayout();
            this.fillByConsonantToolStrip.ResumeLayout(false);
            this.fillByConsonantToolStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip BscsToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBscsToolStripButton;
        private System.Windows.Forms.ToolStrip Address_SamalToolStrip;
        private System.Windows.Forms.ToolStripButton fillBySamalToolStripButton;
        private System.Windows.Forms.ToolStrip lastname_A_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastname_AToolStripButton;
        private System.Windows.Forms.ToolStrip fillByBSITToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBSITToolStripButton;
        private System.Windows.Forms.ToolStrip fillBy2ndYearToolStrip;
        private System.Windows.Forms.ToolStripButton fillBy2ndYearToolStripButton;
        private System.Windows.Forms.ToolStrip fillBy2BToolStrip;
        private System.Windows.Forms.ToolStripButton fillBy2BToolStripButton;
        private System.Windows.Forms.ToolStrip fillByConsonantToolStrip;
        private System.Windows.Forms.ToolStripButton fillByConsonantToolStripButton;
        private System.Windows.Forms.Panel panel1;
    }
}

