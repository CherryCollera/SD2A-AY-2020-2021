﻿namespace Databinding_Santos
{


    partial class studentsDataSet
    {
    }
}

namespace Databinding_Santos.studentsDataSetTableAdapters {
    
    
    public partial class tblStudent_InfoTableAdapter {
    }
}
