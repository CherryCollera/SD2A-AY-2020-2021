﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * May 24, 2021
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Activity09
{
    public partial class Form1 : Form
    {

        private OleDbConnection Bookcon;
        private OleDbCommand oleDbcmd = new OleDbCommand();
        private String ConnParam = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Marabe\Desktop\\ICTC1023_Activity10_MarabeBantay\Activity09\book3.mdb";
        //private String ConnParam = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = C:\Users\Marabe\Desktop\\ICTC1023_Activity10_MarabeBantay\Activity09\book3.accdb";
        public Form1()
        {
            Bookcon = new OleDbConnection(ConnParam);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Bookcon.Open();
            oleDbcmd.Connection = Bookcon;
            oleDbcmd.CommandText = "insert into bookrecords(BookTitle, Description)"
                + " values ('" + this.txtBookTitle.Text + "','" + this.txtDescription.Text + "');";

            int temp = oleDbcmd.ExecuteNonQuery();
            if (temp > 0)
            {
                txtBookTitle.Text = null;
                txtDescription.Text = null;
                MessageBox.Show("Record Succesfully Added");
            }
            else
            {
                MessageBox.Show("Failed to Add a Record");
            }
            Bookcon.Close();
        }

        private void btnShowRecord_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dadapter = new OleDbDataAdapter("SELECT * FROM bookrecords", ConnParam);
            OleDbDataAdapter dadapter1 = new OleDbDataAdapter("SELECT * FROM bookrecords", ConnParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dadapter);

            DataTable dataTable = new DataTable();
            DataSet db = new DataSet();

            dadapter.Fill(dataTable);

            for(int i = 0; i<dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1]);
            }
            txtBookTitle.Text = null;
            txtDescription.Text = null;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            txtBookTitle.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtDescription.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            String name = txtBookTitle.Text;
            if (name == "")
            {
                MessageBox.Show("Please Select the Record You want to delete");
            }
            else
            {
                Bookcon.Open();
                OleDbCommand test = Bookcon.CreateCommand();
                test.CommandType = CommandType.Text;
                test.CommandText = "delete from bookrecords where BookTitle='" + this.txtBookTitle.Text + "'";

                test.ExecuteNonQuery();
                Bookcon.Close();
                txtBookTitle.Text = null;
                txtDescription.Text = null;
                MessageBox.Show("Record Successfully Deleted.(Note: Click Show All Record)");

            }
        }
    }
}
