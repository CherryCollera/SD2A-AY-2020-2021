﻿/* Ralph Matthew De Leon
   BSCS-SD2A
   19-04349 */

using System;

namespace BasicOperations
{
    class Program
    {   
        static void Main(string[] args)
        {
            // I used double for the variables to bypass ArithmiticException when dividing anything with 0
            Console.Write("Enter First Num: ");
            double FirstNum = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Num: ");
            double SecondNum = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\nSum = {0}", FirstNum + SecondNum);
            Console.WriteLine("Difference = {0}", FirstNum - SecondNum);
            Console.WriteLine("Product = {0}", FirstNum * SecondNum);
            Console.WriteLine("Quotient = {0}", FirstNum / SecondNum);
            Console.WriteLine("Remainder = {0}", FirstNum % SecondNum);
        }
    }
}
