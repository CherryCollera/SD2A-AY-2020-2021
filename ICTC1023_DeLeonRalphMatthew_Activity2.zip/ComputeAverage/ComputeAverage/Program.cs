﻿/* Ralph Matthew De Leon
   BSCS-SD2A
   19-04349 */

using System;

namespace ComputeAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Number Of Grades: ");
            int NumOfGrades = Convert.ToInt32(Console.ReadLine());

            double[] Grades = new double[NumOfGrades];

            for(int i = 0; i < NumOfGrades; i++)
            {
                Console.Write("Grade #" + (i+1) + ": ");
                Grades[i] = Convert.ToDouble(Console.ReadLine());
            }

            double sum = 0;

            foreach(int a in Grades)
                sum += a; 
            
            Console.WriteLine("Average = {0:0.###}", sum / NumOfGrades);
        }
    }
}
