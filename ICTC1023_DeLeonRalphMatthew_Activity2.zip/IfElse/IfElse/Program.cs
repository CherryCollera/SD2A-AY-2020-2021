﻿using System;

/* Ralph Matthew De Leon
   BSCS-SD2A
   19-04349 */

namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter First Num: ");
            int FirstNum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Num: ");
            int SecondNum = Convert.ToInt32(Console.ReadLine());

            if (FirstNum > SecondNum)
                Console.WriteLine(FirstNum + " is greater than " + SecondNum);
            else if (SecondNum > FirstNum)
                Console.WriteLine(SecondNum + " is greater than " + FirstNum);
            else
                Console.WriteLine(SecondNum + " is equal to " + FirstNum);
        }
    }
}
