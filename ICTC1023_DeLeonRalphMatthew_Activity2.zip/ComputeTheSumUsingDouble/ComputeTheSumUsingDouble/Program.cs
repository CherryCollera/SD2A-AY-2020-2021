﻿/* Ralph Matthew De Leon
   BSCS-SD2A
   19-04349 */

using System;

namespace ComputeTheSumUsingDouble
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter First Num: ");
            double FirstNum = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Num: ");
            double SecondNum = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Sum = {0} ", FirstNum + SecondNum);
        }
    }
}
