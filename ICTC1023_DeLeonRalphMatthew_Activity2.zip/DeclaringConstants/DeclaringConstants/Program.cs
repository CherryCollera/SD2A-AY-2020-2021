﻿/* Ralph Matthew De Leon
   BSCS-SD2A
   19-04349 */

using System;

namespace DeclaringConstants
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Radius: ");
            double Radius = Convert.ToDouble(Console.ReadLine());

            const double pi = 3.14159;
            double AreaCircle = pi * Radius * Radius;
            
            Console.WriteLine("Radius: {0:0.####}, Area: {1:0.####}", Radius, AreaCircle);

        }
    }
}
