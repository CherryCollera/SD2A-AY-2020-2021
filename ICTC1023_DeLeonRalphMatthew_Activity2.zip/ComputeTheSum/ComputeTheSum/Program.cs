﻿/* Ralph Matthew De Leon
   BSCS-SD2A
   19-04349 */

using System;

namespace ComputeTheSum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter first number: ");
            int FirstNum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            int SecondNum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Sum = {0} ", FirstNum + SecondNum);
        }
    }
}
