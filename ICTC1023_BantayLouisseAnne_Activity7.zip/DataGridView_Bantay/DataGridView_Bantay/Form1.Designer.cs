﻿
namespace DataGridView_Bantay
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByBSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new DataGridView_Bantay.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new DataGridView_Bantay.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.fillByBSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByBSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBySamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBySamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBySecondYearToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBySecondYearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBy2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillBy2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByLastNameACToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByLastNameACToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByFirstNameVowelsToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByFirstNameVowelsToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.fillByBSCSToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.fillByBSITToolStrip.SuspendLayout();
            this.fillBySamalToolStrip.SuspendLayout();
            this.fillBySecondYearToolStrip.SuspendLayout();
            this.fillBy2BToolStrip.SuspendLayout();
            this.fillByLastNameACToolStrip.SuspendLayout();
            this.fillByFirstNameVowelsToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(29, 89);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(886, 257);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(245, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(484, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "Student Records Monitoring System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(451, 405);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 2;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // fillByBSCSToolStrip
            // 
            this.fillByBSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByBSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBSCSToolStripButton});
            this.fillByBSCSToolStrip.Location = new System.Drawing.Point(65, 368);
            this.fillByBSCSToolStrip.Name = "fillByBSCSToolStrip";
            this.fillByBSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.fillByBSCSToolStrip.TabIndex = 3;
            this.fillByBSCSToolStrip.Text = "fillByBSCSToolStrip";
            // 
            // fillByBSCSToolStripButton
            // 
            this.fillByBSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBSCSToolStripButton.Name = "fillByBSCSToolStripButton";
            this.fillByBSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.fillByBSCSToolStripButton.Text = "BSCS";
            this.fillByBSCSToolStripButton.Click += new System.EventHandler(this.fillByBSCSToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // fillByBSITToolStrip
            // 
            this.fillByBSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByBSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByBSITToolStripButton});
            this.fillByBSITToolStrip.Location = new System.Drawing.Point(147, 368);
            this.fillByBSITToolStrip.Name = "fillByBSITToolStrip";
            this.fillByBSITToolStrip.Size = new System.Drawing.Size(46, 25);
            this.fillByBSITToolStrip.TabIndex = 4;
            this.fillByBSITToolStrip.Text = "fillByBSITToolStrip";
            // 
            // fillByBSITToolStripButton
            // 
            this.fillByBSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByBSITToolStripButton.Name = "fillByBSITToolStripButton";
            this.fillByBSITToolStripButton.Size = new System.Drawing.Size(34, 22);
            this.fillByBSITToolStripButton.Text = "BSIT";
            this.fillByBSITToolStripButton.Click += new System.EventHandler(this.fillByBSITToolStripButton_Click);
            // 
            // fillBySamalToolStrip
            // 
            this.fillBySamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBySamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBySamalToolStripButton});
            this.fillBySamalToolStrip.Location = new System.Drawing.Point(227, 368);
            this.fillBySamalToolStrip.Name = "fillBySamalToolStrip";
            this.fillBySamalToolStrip.Size = new System.Drawing.Size(102, 25);
            this.fillBySamalToolStrip.TabIndex = 5;
            this.fillBySamalToolStrip.Text = "Address, Samal";
            // 
            // fillBySamalToolStripButton
            // 
            this.fillBySamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBySamalToolStripButton.Name = "fillBySamalToolStripButton";
            this.fillBySamalToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.fillBySamalToolStripButton.Text = "Address_Samal";
            this.fillBySamalToolStripButton.Click += new System.EventHandler(this.fillBySamalToolStripButton_Click);
            // 
            // fillBySecondYearToolStrip
            // 
            this.fillBySecondYearToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBySecondYearToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBySecondYearToolStripButton});
            this.fillBySecondYearToolStrip.Location = new System.Drawing.Point(354, 368);
            this.fillBySecondYearToolStrip.Name = "fillBySecondYearToolStrip";
            this.fillBySecondYearToolStrip.Size = new System.Drawing.Size(130, 25);
            this.fillBySecondYearToolStrip.TabIndex = 6;
            this.fillBySecondYearToolStrip.Text = "fillBySecondYearToolStrip";
            // 
            // fillBySecondYearToolStripButton
            // 
            this.fillBySecondYearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBySecondYearToolStripButton.Name = "fillBySecondYearToolStripButton";
            this.fillBySecondYearToolStripButton.Size = new System.Drawing.Size(118, 22);
            this.fillBySecondYearToolStripButton.Text = "SecondYearStudents";
            this.fillBySecondYearToolStripButton.Click += new System.EventHandler(this.fillBySecondYearToolStripButton_Click);
            // 
            // fillBy2BToolStrip
            // 
            this.fillBy2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillBy2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillBy2BToolStripButton});
            this.fillBy2BToolStrip.Location = new System.Drawing.Point(515, 368);
            this.fillBy2BToolStrip.Name = "fillBy2BToolStrip";
            this.fillBy2BToolStrip.Size = new System.Drawing.Size(80, 25);
            this.fillBy2BToolStrip.TabIndex = 7;
            this.fillBy2BToolStrip.Text = "fillBy2BToolStrip";
            // 
            // fillBy2BToolStripButton
            // 
            this.fillBy2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy2BToolStripButton.Name = "fillBy2BToolStripButton";
            this.fillBy2BToolStripButton.Size = new System.Drawing.Size(68, 22);
            this.fillBy2BToolStripButton.Text = "Section_2B";
            this.fillBy2BToolStripButton.Click += new System.EventHandler(this.fillBy2BToolStripButton_Click);
            // 
            // fillByLastNameACToolStrip
            // 
            this.fillByLastNameACToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByLastNameACToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByLastNameACToolStripButton});
            this.fillByLastNameACToolStrip.Location = new System.Drawing.Point(626, 368);
            this.fillByLastNameACToolStrip.Name = "fillByLastNameACToolStrip";
            this.fillByLastNameACToolStrip.Size = new System.Drawing.Size(112, 25);
            this.fillByLastNameACToolStrip.TabIndex = 8;
            this.fillByLastNameACToolStrip.Text = "fillByLastNameACToolStrip";
            // 
            // fillByLastNameACToolStripButton
            // 
            this.fillByLastNameACToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByLastNameACToolStripButton.Name = "fillByLastNameACToolStripButton";
            this.fillByLastNameACToolStripButton.Size = new System.Drawing.Size(100, 22);
            this.fillByLastNameACToolStripButton.Text = "LastNameAandC";
            this.fillByLastNameACToolStripButton.Click += new System.EventHandler(this.fillByLastNameACToolStripButton_Click);
            // 
            // fillByFirstNameVowelsToolStrip
            // 
            this.fillByFirstNameVowelsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fillByFirstNameVowelsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByFirstNameVowelsToolStripButton});
            this.fillByFirstNameVowelsToolStrip.Location = new System.Drawing.Point(763, 368);
            this.fillByFirstNameVowelsToolStrip.Name = "fillByFirstNameVowelsToolStrip";
            this.fillByFirstNameVowelsToolStrip.Size = new System.Drawing.Size(113, 25);
            this.fillByFirstNameVowelsToolStrip.TabIndex = 9;
            this.fillByFirstNameVowelsToolStrip.Text = "fillByFirstNameVowelsToolStrip";
            // 
            // fillByFirstNameVowelsToolStripButton
            // 
            this.fillByFirstNameVowelsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByFirstNameVowelsToolStripButton.Name = "fillByFirstNameVowelsToolStripButton";
            this.fillByFirstNameVowelsToolStripButton.Size = new System.Drawing.Size(101, 22);
            this.fillByFirstNameVowelsToolStripButton.Text = "FirstNameVowels";
            this.fillByFirstNameVowelsToolStripButton.Click += new System.EventHandler(this.fillByFirstNameVowelsToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(944, 450);
            this.Controls.Add(this.fillByFirstNameVowelsToolStrip);
            this.Controls.Add(this.fillByLastNameACToolStrip);
            this.Controls.Add(this.fillBy2BToolStrip);
            this.Controls.Add(this.fillBySecondYearToolStrip);
            this.Controls.Add(this.fillBySamalToolStrip);
            this.Controls.Add(this.fillByBSITToolStrip);
            this.Controls.Add(this.fillByBSCSToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Data Grid Bantay";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.fillByBSCSToolStrip.ResumeLayout(false);
            this.fillByBSCSToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.fillByBSITToolStrip.ResumeLayout(false);
            this.fillByBSITToolStrip.PerformLayout();
            this.fillBySamalToolStrip.ResumeLayout(false);
            this.fillBySamalToolStrip.PerformLayout();
            this.fillBySecondYearToolStrip.ResumeLayout(false);
            this.fillBySecondYearToolStrip.PerformLayout();
            this.fillBy2BToolStrip.ResumeLayout(false);
            this.fillBy2BToolStrip.PerformLayout();
            this.fillByLastNameACToolStrip.ResumeLayout(false);
            this.fillByLastNameACToolStrip.PerformLayout();
            this.fillByFirstNameVowelsToolStrip.ResumeLayout(false);
            this.fillByFirstNameVowelsToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip fillByBSCSToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBSCSToolStripButton;
        private System.Windows.Forms.ToolStrip fillByBSITToolStrip;
        private System.Windows.Forms.ToolStripButton fillByBSITToolStripButton;
        private System.Windows.Forms.ToolStrip fillBySamalToolStrip;
        private System.Windows.Forms.ToolStripButton fillBySamalToolStripButton;
        private System.Windows.Forms.ToolStrip fillBySecondYearToolStrip;
        private System.Windows.Forms.ToolStripButton fillBySecondYearToolStripButton;
        private System.Windows.Forms.ToolStrip fillBy2BToolStrip;
        private System.Windows.Forms.ToolStripButton fillBy2BToolStripButton;
        private System.Windows.Forms.ToolStrip fillByLastNameACToolStrip;
        private System.Windows.Forms.ToolStripButton fillByLastNameACToolStripButton;
        private System.Windows.Forms.ToolStrip fillByFirstNameVowelsToolStrip;
        private System.Windows.Forms.ToolStripButton fillByFirstNameVowelsToolStripButton;
    }
}

