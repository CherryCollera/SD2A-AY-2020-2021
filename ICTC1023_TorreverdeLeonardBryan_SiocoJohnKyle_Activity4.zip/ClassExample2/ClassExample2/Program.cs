﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 22, 2021
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Red ");
            Console.WriteLine(car.Describe());
            car = new Car("Green ");
            Console.WriteLine(car.Describe());
            Console.ReadLine();

            
        }
    }
}
