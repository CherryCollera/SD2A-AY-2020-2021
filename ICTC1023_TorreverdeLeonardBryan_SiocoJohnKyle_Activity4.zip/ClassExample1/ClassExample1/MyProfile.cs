﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 22, 2021
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            Console.WriteLine("Name:\t\t\t Kyle Sioco");
            Console.WriteLine("Course:\t\t\t BS in Computer Science Major in Software Dev");
            Console.WriteLine("Year:\t\t\t2nd year");
            Console.WriteLine("Section:\t\t\tA");
            Console.ReadLine();
        }
    }
}
