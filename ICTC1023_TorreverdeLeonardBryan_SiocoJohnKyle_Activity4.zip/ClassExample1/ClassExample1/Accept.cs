﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1
{
    class Accept
    {
        public string fname, lname;
        public void AcceptDetails()
        {
            Console.Write("Enter Your firstname and lastname:\t");
            fname = Console.ReadLine();
            lname = Console.ReadLine();
        }
    }
}
