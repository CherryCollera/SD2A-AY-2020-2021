﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 22, 2021
 * 
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class DeclareVar
    {
        public static double num1, num2 = 0;

        public static double Num1
        {
            get { return num1; }
            set { num1 = value; }
        }

        public static double Num2
        {
            get { return num2; }
            set { num2 = value; }
        }
    }
}
