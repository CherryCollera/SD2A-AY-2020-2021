﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 22, 2021
 * 
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BasicOperations
{
    class Input
    {
        DeclareVar d = new DeclareVar();

        public void InputVals()
        {
            Console.Write("Input num1: ");
            DeclareVar.num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Input num2: ");
            DeclareVar.num2 = Convert.ToDouble(Console.ReadLine());
        }

    }
}
