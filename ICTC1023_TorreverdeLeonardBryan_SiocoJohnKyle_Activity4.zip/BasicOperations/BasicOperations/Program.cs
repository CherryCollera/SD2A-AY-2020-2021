﻿/* 19-01073 
 * Torreverde, Leonard Bryan C.
 * 
 * 19-00735
 * Sioco, John Kyle D.
 * 
 * SD2A
 * March 22, 2021
 * 
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BasicOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            Sum s = new Sum();
            Difference d = new Difference();
            Product p = new Product();
            Quotient q = new Quotient();
            Remainder r = new Remainder();
            
            i.InputVals();

            Console.WriteLine("Sum: {0}", s.computeSum());
            Console.WriteLine("Difference: {0}", d.computeDiff());
            Console.WriteLine("Product: {0}", p.computeProd());
            Console.WriteLine("Quotient: {0}", q.computeQuot());
            Console.WriteLine("Remainder: {0}", r.computeRem());
            Console.ReadKey();

        }
    }
}
