﻿/*Creating classes in OOP
 * Author: Myrro Stephen P. Vitangcol
 * Date: march 24, 2021
 */

using System;
namespace ClassExample_Collera
{
    class Program // Creating 4th Class
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}