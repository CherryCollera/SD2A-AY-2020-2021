﻿class MyProfile // Creating 3rd class
{
    public void DisplayProfile()
    {
        System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
        System.Console.WriteLine("Name: \t\t\tMyrro Stephen Vitangcol");
        System.Console.WriteLine("Birthday: \t\tDecember 11, 1998");
        System.Console.WriteLine("Course: \t\tBS Computer Science Major in Software Development");
        System.Console.WriteLine("Year:\t\t\t3rd Year");
        System.Console.WriteLine("Section:\t\tA");
        System.Console.WriteLine();
    }
}