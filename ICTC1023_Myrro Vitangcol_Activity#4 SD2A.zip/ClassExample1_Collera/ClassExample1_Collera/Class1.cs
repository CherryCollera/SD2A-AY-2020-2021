﻿using CreatingClass;
class Print // Creating 2nd class
{
    public void PrintDetails()
    {
        Accept a = new Accept(); //Creating Object of 1st class
        a.AcceptDetail();      // Executing method of 1st class
        // Print Value of name Variable
        System.Console.WriteLine("Hello " + a.firstname + " " + a.lastname + "!!!\nYou have created classes in OOP");
        MyProfile mp = new MyProfile();
        mp.DisplayProfile();
    }
}