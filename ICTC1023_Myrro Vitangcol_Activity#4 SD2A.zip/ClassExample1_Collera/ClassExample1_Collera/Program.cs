﻿using System;
namespace CreatingClass
{
    class Accept //Creating First Class
    {
        public string firstname, lastname;
        public void AcceptDetail()
        {
            System.Console.Write("Enter your firstname and lastname: \t");
            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();
        }
    }
}
