﻿class Quotient
{
    public void ComputeQuo()
    {
        DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        System.Console.Write("\t\tQuotient\t=\t{0}", DeclareVar.quotient);
    }
}