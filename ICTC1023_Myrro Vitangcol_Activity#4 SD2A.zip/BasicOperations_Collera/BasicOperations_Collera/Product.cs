﻿class Product
{
    public void ComputePro()
    {
        DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
        System.Console.Write("\t\tProduct\t=\t{0}", DeclareVar.product);
    }
}