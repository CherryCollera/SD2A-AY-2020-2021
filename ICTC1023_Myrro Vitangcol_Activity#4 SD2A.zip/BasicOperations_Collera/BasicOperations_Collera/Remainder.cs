﻿class Remainder
{
    public void ComputeRem()
    {
        DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
        System.Console.Write("\t\tRemainder\t=\t{0}", DeclareVar.remainder);
    }
}