﻿class Sum
{
    public void ComputeSum()
    {
        DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
        System.Console.Write("Sum\t=\t{0}", DeclareVar.sum);
    }
}