﻿using System;
namespace BasicOperations_Collera
{
    class Program
    {
        static void Main (string[] args)
        {
            Input i = new Input();
            i.InputData();

            Sum s = new Sum();
            s.ComputeSum();

            Difference d = new Difference();
            d.ComputeDiff();

            Product p = new Product();
            p.ComputePro();

            Quotient q = new Quotient();
            q.ComputeQuo();

            Remainder r = new Remainder();
            r.ComputeRem();

            Console.ReadKey();

            


        }
    }
}