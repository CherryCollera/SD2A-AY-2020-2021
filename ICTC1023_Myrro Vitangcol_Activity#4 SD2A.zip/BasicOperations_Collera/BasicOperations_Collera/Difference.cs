﻿class Difference
{
    public void ComputeDiff()
    {
        DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
        System.Console.Write("\tDifference\t=\t{0}", DeclareVar.difference);
    }
}