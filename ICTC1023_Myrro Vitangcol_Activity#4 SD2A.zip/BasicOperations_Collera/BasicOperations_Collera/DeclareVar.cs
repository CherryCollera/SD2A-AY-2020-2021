﻿class DeclareVar
{
    public static int num1, num2, sum, difference, product, quotient, remainder;
}