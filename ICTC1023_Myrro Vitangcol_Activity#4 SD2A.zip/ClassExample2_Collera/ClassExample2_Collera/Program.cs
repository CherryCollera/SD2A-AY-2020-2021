﻿using System;

namespace Class_Collera
{
    class Program
    {
        static void Main(string[] args)
        {
            car Car;
            Car = new car("Red");
            Console.WriteLine(Car.Describe());
            Car = new car("Green");
            Console.WriteLine(Car.Describe());
            Console.WriteLine();

        }
    }
}
