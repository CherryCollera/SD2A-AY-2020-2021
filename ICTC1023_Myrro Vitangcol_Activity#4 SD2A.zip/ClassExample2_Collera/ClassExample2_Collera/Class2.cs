﻿class declaration
{
    public string color
    {
        get
        {
            return color;
        }
        set
        {
            color = value;
        }
    }
}