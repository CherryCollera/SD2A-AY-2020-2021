﻿class car
{
    private string color;
    public car(string color)
    {
        this.color = color;
    }
    public string Describe()
    {
        return "this car is " + color;
    }
}