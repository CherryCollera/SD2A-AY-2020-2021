﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 15, 2021
This program will display While Loop*/
using System;

namespace Whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while(i < 10)
            {
                Console.Write("While statement ");
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
