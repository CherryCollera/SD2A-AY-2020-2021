﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 15, 2021
This program will display Switch*/
using System;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            char gender;

            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Enter your Gender M/F: ");
            gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {
                case 'M': case  'm':
                        Console.Write("\nHi "+name+"! Your gender is Male!.");
                    break;
                case 'F': case 'f':
                    Console.Write("\nHi " + name + "! Your gender is Female!.");
                    break;
                default:
                    Console.Write("\nInvalid Input... Try again...");
                    break;
            }
            Console.ReadKey();
        }
    }
}
