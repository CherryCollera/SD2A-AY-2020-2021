﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 15, 2021
This program will display Comparing Numbers*/
using System;

namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            //the first else if statement checks if there's 2 equal numbers and determine if its less or greater than to the remaining number
            if (num1 == num2 && num1 == num3)
            {
                Console.WriteLine("\n{0}, {1} and {2} are equal", num1, num2, num3);
            }else if (num1 == num2 || num1 == num3 || num2 == num3)
            {
                if (num1 == num2 && num1 > num3)
                {
                    Console.WriteLine("\n{0} and {1} is equal and greater than {2}", num1, num2, num3);
                }else if (num1 == num2 && num1 < num3)
                {
                    Console.WriteLine("\n{0} and {1} is equal and less than {2}", num1, num2, num3);
                }else if (num1 == num3 && num1 > num2)
                {
                    Console.WriteLine("\n{0} and {1} is equal and greater than {2}", num1, num3, num2);
                }else if (num1 == num3 && num1 < num2)
                {
                    Console.WriteLine("\n{0} and {1} is equal and less than {2}", num1, num3, num2);
                }else if (num2 == num3 && num2 > num1)
                {
                    Console.WriteLine("\n{0} and {1} is equal and greater than {2}", num2, num3, num1);
                }else if (num1 == num3 && num1 < num2)
                {
                    Console.WriteLine("\n{0} and {1} is equal and less than {2}", num1, num3, num2);
                }
            }else if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
            }else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num2, num3, num1);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
            }else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
            }else
            {
                Console.WriteLine("Invalid Input");
            }

            Console.ReadKey();
        }
    }
}
