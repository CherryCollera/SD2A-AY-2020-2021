﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 15, 2021
This program will display Do-While loop*/
using System;

namespace Do_Whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] GEF06_nms = new int[] { 6, 7, 8, 10 };
            int GEF06_sum = 0;
            int i = 0;
            do
            {
                GEF06_sum += GEF06_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(GEF06_sum);
            Console.ReadKey();
        }
    }
}
