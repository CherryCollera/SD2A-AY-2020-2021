﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 15, 2021
This program will display Grading System*/
using System;

namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\nEnter Your Final Grade: ");
            double FinalGrade = Convert.ToDouble(Console.ReadLine());

            if (FinalGrade > 100)
                Main(args);
            else if (FinalGrade < 60)
                Console.WriteLine("Grade Equivalent: Incomplete");
            else if (FinalGrade <= 71)
                Console.WriteLine("Grade Equivalent: 5.00 \nRemarks: Failed");
            else if (FinalGrade <= 74)
                Console.WriteLine("Grade Equivalent: 4.00 \nRemarks: Conditional (MT Only)");
            else if (FinalGrade <= 76)
                Console.WriteLine("Grade Equivalent: 3.00 \nRemarks: Passed");
            else if (FinalGrade <= 79)
                Console.WriteLine("Grade Equivalent: 2.75 \n Remarks: Passed");
            else if (FinalGrade <= 82)
                Console.WriteLine("Grade Equivalent: 2.50 \nRemarks: Fair");
            else if (FinalGrade <= 85)
                Console.WriteLine("Grade Equivalent: 2.25 \nRemarks: Good");
            else if (FinalGrade <= 88)
                Console.WriteLine("Grade Equivalent: 2.00 \nRemarks: Good");
            else if (FinalGrade <= 91)
                Console.WriteLine("Grade Equivalent: 1.75 \nRemarks: Very Good");
            else if (FinalGrade <= 94)
                Console.WriteLine("Grade Equivalent: 1.50 \nRemarks: Very Good");
            else if (FinalGrade <= 97)
                Console.WriteLine("Grade Equivalent: 1.25 \nRemarks: Very Good");
            else
                Console.WriteLine("Grade Equivalent: 1.00 \nRemarks: Excellent");

            Console.WriteLine("\nPress enter to try again");
            if (Console.ReadKey().Key == ConsoleKey.Enter)
                Main(args);
        }
    }
}
