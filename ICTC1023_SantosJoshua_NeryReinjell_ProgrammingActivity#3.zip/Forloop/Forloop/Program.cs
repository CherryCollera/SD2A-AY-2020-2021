﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 15, 2021
This program will display For Loop*/
using System;

namespace Forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
