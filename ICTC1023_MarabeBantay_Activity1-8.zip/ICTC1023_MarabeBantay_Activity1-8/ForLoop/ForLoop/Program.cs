﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 15, 2021
 * This program will show For Loop
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
