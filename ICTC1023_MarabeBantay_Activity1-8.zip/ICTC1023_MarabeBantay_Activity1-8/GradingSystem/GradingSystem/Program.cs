﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 15, 2021
 * This program will show the grading system
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your grade   : ");
            double grade = Convert.ToDouble(Console.ReadLine());

            if (grade >= 98)
            {
                Console.WriteLine("Garde Equivalent   : 1.00");
                Console.WriteLine("Remarks           :  Exellent ");

            }else if (grade >= 95 && grade <= 97){
                Console.WriteLine("Garde Equivalent   : 1.25");
                Console.WriteLine("Remarks           :  Exellent ");

            }else if (grade >= 92 && grade <= 94){
                Console.WriteLine("Garde Equivalent   : 1.50");
                Console.WriteLine("Remarks           :  Very Good ");

            }else if (grade >= 89 && grade <= 91){
                Console.WriteLine("Garde Equivalent   : 1.75");
                Console.WriteLine("Remarks           :  Very Good ");

            }else if (grade >= 86 && grade <= 88){
                Console.WriteLine("Garde Equivalent   : 2.00");
                Console.WriteLine("Remarks           :  Good ");

            }else if (grade >= 83 && grade <= 85){
                Console.WriteLine("Garde Equivalent   : 2.25");
                Console.WriteLine("Remarks           :  Good ");

            }else if (grade >= 80 && grade <= 82){
                Console.WriteLine("Garde Equivalent   : 2.50");
                Console.WriteLine("Remarks           :  Fair");

            }else if (grade >= 77 && grade <= 79){
                Console.WriteLine("Garde Equivalent   : 2.75");
                Console.WriteLine("Remarks           :  Passed");

            }else if (grade >= 75 && grade <= 76){
                Console.WriteLine("Garde Equivalent   : 3.00");
                Console.WriteLine("Remarks           :  Passed");

            }else if (grade >= 72 && grade <= 74){
                Console.WriteLine("Garde Equivalent   : 4.00");
                Console.WriteLine("Remarks           :  Conditional");

            }else if (grade >= 60 && grade <= 71){
                Console.WriteLine("Garde Equivalent   : 5.00");
                Console.WriteLine("Remarks           :  Failed");

            }else {
                Console.WriteLine("Garde Equivalent   : Incomplete");
                Console.WriteLine("Remarks           :  Inc");
            }

            Console.ReadKey();
        }
    }
}
