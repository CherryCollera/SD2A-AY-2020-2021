﻿/*19-00814
 * Marabe, Imee Rose
 * 19-05159
 * Bantay, Louisse Anne A.
 * BSCS SD2A
 * March 15, 2021
 * This program will compare numbers
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int ILM18_Num1, ILM18_Num2, ILM18_Num3;

            Console.Write("Enter 1st number ");
            ILM18_Num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd number ");
            ILM18_Num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd number ");
            ILM18_Num3 = Convert.ToInt32(Console.ReadLine());

            if (ILM18_Num1 > ILM18_Num2 && ILM18_Num1 > ILM18_Num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", ILM18_Num1, ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{1} is less than {0}", ILM18_Num1, ILM18_Num2);
                Console.WriteLine("{1} is less than {0}", ILM18_Num1, ILM18_Num3);

            }else if (ILM18_Num2 > ILM18_Num1 && ILM18_Num2 > ILM18_Num3)
            {
                Console.WriteLine("{1} is greater than {0} and {2}", ILM18_Num1, ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{0} is less than {1}", ILM18_Num1, ILM18_Num2);
                Console.WriteLine("{1} is less than {0}", ILM18_Num2, ILM18_Num3);
            }else if (ILM18_Num3 > ILM18_Num1 && ILM18_Num3 > ILM18_Num2)
            {
                Console.WriteLine("{2} is greater than {0} and {1}", ILM18_Num1, ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{0} is less than {1}", ILM18_Num1, ILM18_Num3);
                Console.WriteLine("{0} is less than {1}", ILM18_Num2, ILM18_Num3);
            }else if (ILM18_Num1 == ILM18_Num2 && ILM18_Num1 > ILM18_Num3)
            {
                Console.WriteLine("{0} and {1} are equal", ILM18_Num1, ILM18_Num2);
                Console.WriteLine("{0} and {1} are greater than {2}", ILM18_Num1, ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{2} is less than to {0} and {1}", ILM18_Num1, ILM18_Num2, ILM18_Num3);

            }else if (ILM18_Num1 == ILM18_Num3 && ILM18_Num1 > ILM18_Num2)
            {
                Console.WriteLine("{0} and {1} are equal", ILM18_Num1, ILM18_Num3);
                Console.WriteLine("{0} and {2} are greater than {1}", ILM18_Num1, ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{1} is less than to {0} and {2}", ILM18_Num1 , ILM18_Num2, ILM18_Num3);

            }else if (ILM18_Num3 == ILM18_Num2 && ILM18_Num3 > ILM18_Num1)
            {
                Console.WriteLine("{0} and {1} are equal", ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{1} and {2} are greater than {0}", ILM18_Num1, ILM18_Num2, ILM18_Num3);
                Console.WriteLine("{0} is less than to {1} and {2}", ILM18_Num1, ILM18_Num2, ILM18_Num3);

            }
            else
            {
                Console.WriteLine("{0}, {1} and {2} are equal", ILM18_Num1, ILM18_Num2, ILM18_Num3);
            }

            Console.ReadKey();
        }
    }
}
