﻿/* Project# 6: While
 * Ralph Matthew De Leon
 * BSCS-SD2A
 * 19-04349
 */

using System;

namespace While
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while(i < 10)
            {
                Console.WriteLine("While statement iteration #" + i);
                i++;
            }
        }
    }
}
