﻿/* Project# 5: For
 * Ralph Matthew De Leon
 * BSCS-SD2A
 * 19-04349
 */

using System;

namespace For
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
                Console.WriteLine(i);
        }
    }
}
