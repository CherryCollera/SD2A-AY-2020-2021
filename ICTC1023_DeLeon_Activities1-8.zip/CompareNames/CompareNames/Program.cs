﻿/* Project# 1: Comparing Names
 * Ralph Matthew De Leon
 * BSCS-SD2A
 * 19-04349
 */

using System;

namespace CompareNames
{
    class Program
    {
        static void Main(string[] args)
        {
            String string1 = "Cherri";
            String string2 = "Cherri";
            String string3 = "Cherry";
            String string4 = "cherry";
            String string5 = "CHERRY";

            Console.WriteLine("Using Equals() method");
            Console.WriteLine("compare {0} to {1}: {2}", string1, string2, String.Equals(string1, string2));
            Console.WriteLine("compare {0} to {1}: {2}", string1, string3, String.Equals(string1, string3));
            Console.WriteLine("\nLength of {0} is {1}", string1, string1.Length);
            Console.WriteLine("String {0} Substring (0,3) will return {1}", string5, string5.Substring(0, 3));

            Console.WriteLine("\nUsing Compare() method");
            Console.WriteLine("compare {0} to {1}: {2}", string1, string2, String.Compare(string1, string2));
            Console.WriteLine("compare {0} to {1}: {2}", string1, string3, String.Compare(string1, string3));
            Console.WriteLine("compare {0} to {1}: {2}", string3, string1, String.Compare(string3, string1));
            Console.WriteLine("compare {0} to {1}: {2}", string4, string5, String.Compare(string4, string5));

            Console.WriteLine("\nUsing CompareTo() method");
            Console.WriteLine("compare {0} to {1}: {2}", string1, string2, string1.CompareTo(string2));
            Console.WriteLine("compare {0} to {1}: {2}", string1, string3, string1.CompareTo(string3));
            Console.WriteLine("compare {0} to {1}: {2}", string3, string1, string3.CompareTo(string1));
        }
    }
}
