﻿/* Project# 7: do-while
 * Ralph Matthew De Leon
 * BSCS-SD2A
 * 19-04349
 */

using System;

namespace Do_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] GEF06_nms = new int[]{6, 7, 8, 10 };
            int GEF06_sum = 0;
            int i = 0; 

            do
            {
                GEF06_sum += GEF06_nms[i];
                i++;
            }while (i< 4); 

            Console.WriteLine(GEF06_sum); 
            Console.ReadKey(); 
        }
    }
}
