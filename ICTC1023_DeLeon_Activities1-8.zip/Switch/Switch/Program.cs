﻿/* Project# 4: Switch
 * Ralph Matthew De Leon
 * BSCS-SD2A
 * 19-04349
 */

using System;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            string Name;
            char Gender;

            Console.Write("Enter your name: ");
            Name = Console.ReadLine();
            Console.Write("Enter your gender: ");
            Gender = Convert.ToChar(Console.ReadLine());

            switch (Gender.ToString().ToLower())
            {
                case "m":
                    Console.WriteLine("\nHi " + Name + "!" + " Your gender is Male!");
                    break;
                case "f":
                    Console.WriteLine("\nHi " + Name + "!" + " Your gender is Female!");
                    break;
                default:
                    Console.WriteLine("\nInvalid input... Try again...");
                    Main(args);
                    break;
            }
        }
    }
}
