﻿/* Project# 2: Comparing Numbers
 * Ralph Matthew De Leon
 * BSCS-SD2A
 * 19-04349
 */

using System;

namespace ElseIf
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = new int[3];

            Console.Write("Enter First Num: ");
            nums[0] = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Num: ");
            nums[1] = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Num: ");
            nums[2] = Convert.ToInt32(Console.ReadLine());

            Array.Sort(nums);

            if(nums[2] == nums[0])
                Console.WriteLine(nums[0] + ", " + nums[1] + ", and " + nums[2] + " are all equal");
            else if(nums[2] > nums[1])
                Console.WriteLine(nums[2] + " is greater than " + nums[0] + " and " + nums[1]);
            else
                Console.WriteLine(nums[2] + " and " + nums[1] + " are greater than " + nums[0]);
            
        }
    }
}
