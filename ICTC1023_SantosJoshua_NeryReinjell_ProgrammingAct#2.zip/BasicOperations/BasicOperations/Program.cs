﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 8, 2021
This program will display the Basic Operations*/
using System;

namespace BasicOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nSum = {0}", num1 + num2);
            Console.WriteLine("Difference = {0}", num1 - num2);
            Console.WriteLine("Product = {0}", num1 * num2);
            Console.WriteLine("Quotient = {0}", num1 / num2);
            Console.WriteLine("Remainder = {0}", num1 % num2);
            Console.ReadKey();
        }
    }
}
