﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 8, 2021
This program will display IfElse Problem*/
using System;

namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if(num1>num2 && num1 > num3)
            {
                Console.WriteLine("\n{0} is greather than {1} and {2}",num1,num2,num3);
            }else if(num2 > num1 && num2 > num3)
            {
                Console.WriteLine("\n{0} is greather than {1} and {2}", num2, num3, num1);
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("\n{0} is greather than {1} and {2}", num3, num1, num2);
            }
            else
            {
                Console.WriteLine("\n{0} is equal to {1} and {2}", num1, num2, num3);
            }

            Console.ReadKey();
        }
    }
}
