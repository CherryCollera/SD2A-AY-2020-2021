﻿/*19-00140, 19-00325
Joshua M. Santos, Reinjell Arren D. Nery
SD2A
March 8, 2021
This program will display the Compute the sum in int*/
using System;

namespace Computethesumint
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Sum = {0}", num1 + num2);
            Console.ReadLine();
        }
    }
}
