﻿using System;

/* Activity 01 - Compute the Sum using int
 * Diamse, JV C.
 * Vergara, Darry Dominique S.
 * BSCS SD-2A
*/

namespace ICTC1023_DiamseJV_VergaraDarry_Act1
{
    class CTC1023_DiamseJV_VergaraDarry_Act1
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Activity 01 - Compute the Sum using int");
            Console.Write("\n\nEnter the first number:   ");
            num1 = Convert.ToInt32(Console.ReadLine());
            
            Console.Write("Enter the second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Sum = {0} ", num1 + num2);
            
        }
    }
}
