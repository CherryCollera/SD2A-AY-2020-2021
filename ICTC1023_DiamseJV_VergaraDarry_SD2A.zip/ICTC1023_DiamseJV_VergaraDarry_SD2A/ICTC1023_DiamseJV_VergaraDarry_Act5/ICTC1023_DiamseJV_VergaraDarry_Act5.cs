﻿using System;

/*Ativity 05 - Constant Declaration
 * Diamse, JV C.
 * Vergara, Darry Dominique S.
 * BSCS SD-2A
 */
namespace ICTC1023_DiamseJV_VergaraDarry_Act5
{
    class ICTC1023_DiamseJV_VergaraDarry_Act5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Activity 05 - Constant Declaration");

            double rad;
            double pi = 3.14159;

            Console.Write("Enther the size of Radius:  ");
            rad = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Radius: {0:0.0000}", rad);
            Console.Write("Area: {0:0.0000}", pi * rad * rad);
            

        }
    }
}
