﻿using System;

/* Activity 03 - Basic Operations
 * Diamse, JV C.
 * Vergara, Darry Dominique S.
 * BSCS SD-2A
*/

namespace ICTC1023_DiamseJV_VergaraDarry_Act3
{
    class ICTC1023_DiamseJV_VergaraDarry_Act3
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.WriteLine("Activity 03 - Basic Operations");
            Console.Write("\nEnter the first number:    ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the second number:   ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nSum = {0}   ", num1 + num2);
            Console.WriteLine("Difference = {0}   ", num1 - num2);
            Console.WriteLine("Product = {0}   ", num1 * num2);
            Console.WriteLine("Quotient = {0}   ", num1 / num2);
            Console.WriteLine("Remainder = {0}   ", num1 % num2);
            
        }
    }
}
