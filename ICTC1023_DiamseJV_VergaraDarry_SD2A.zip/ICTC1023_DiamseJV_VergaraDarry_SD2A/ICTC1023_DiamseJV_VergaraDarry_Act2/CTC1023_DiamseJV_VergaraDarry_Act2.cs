﻿using System;

/* Activity 02 - Compute the Sum using double
 * Diamse, JV C.
 * Vergara, Darry Dominique S.
 * BSCS SD-2A
*/

namespace ICTC1023_DiamseJV_VergaraDarry_Act2
{
    class CTC1023_DiamseJV_VergaraDarry_Act2
    {
        static void Main(string[] args)
        {
            double num1, num2;
            Console.Write("Activity 02 - Compute the Sum using double");
            Console.Write("\n\nEnter the first number:   ");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the second number:  ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Sum = {0} ", num1 + num2);
            
        }
    }
}
