﻿using System;

/* Activity 06 - If Else
 * Diamse, JV C.
 * Vergara, Darry Dominique S.
 * BSCS SD-2A
*/

namespace ICTC1023_DiamseJV_VergaraDarry_Act6
{
    class ICTC1023_DiamseJV_VergaraDarry_Act6
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Activity 06 - If - Else");

            int num1, num2, num3;
            Console.Write("\nEnter the first number:   ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the third number:   ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num3, num1, num2);
            }
            else
            {
                Console.WriteLine("{0} is equal to {1} and {2}", num1, num2, num3);
            }
            
        }
    }
}
