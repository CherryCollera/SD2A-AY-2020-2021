﻿using System;

/* Activity 04 - Average of Grades
 * Diamse, JV C.
 * Vergara, Darry Dominique S.
 * BSCS SD-2A
*/

namespace ICTC1023_DiamseJV_VergaraDarry_Act4
{
    class ICTC1023_DiamseJV_VergaraDarry_Act4
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Activity 04 - Average of Grades");

            double grd1, grd2, grd3, grd4, grd5, ave;
            Console.WriteLine("Enter the five (5) grades: ");
            grd1 = Convert.ToDouble(Console.ReadLine());
            grd2 = Convert.ToDouble(Console.ReadLine());
            grd3 = Convert.ToDouble(Console.ReadLine());
            grd4 = Convert.ToDouble(Console.ReadLine());
            grd5 = Convert.ToDouble(Console.ReadLine());
            ave = (grd1 + grd2 + grd3 + grd4 + grd5);
            Console.Write("The Average is {0:0.000}", ave / 5);
        }
    }
}
