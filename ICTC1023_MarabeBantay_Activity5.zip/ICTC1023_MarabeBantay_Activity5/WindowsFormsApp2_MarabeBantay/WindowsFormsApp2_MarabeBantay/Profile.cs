﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2_MarabeBantay
{
    class Profile
    {
        public string GetMessageImee(string firstname)
        {
            return "\t\tHello " + firstname + "\nDate of Birth\t:\tMay 18, 2001\nCourse\t\t:\tBS Computer Science\nYear\t\t:\tII\nSection\t\t:\tA";
        }
        public string GetMessageLouisse(string firstname)
        {
            return "\t\tHello " + firstname + "\nDate of Birth\t:\tSeptember 23, 2001\nCourse\t\t:\tBS Computer Science\nYear\t\t:\tII\nSection\t\t:\tA";
        }
    }
}
