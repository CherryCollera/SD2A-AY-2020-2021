﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2_MarabeBantay
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void lbl_Profile_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_GetProfile_Click(object sender, EventArgs e)
        {
            Profile hb = new Profile();
            if (txt_lastname.Text == "Marabe" || txt_lastname.Text == "marabe" || txt_lastname.Text == "MARABE")
            {
                MessageBox.Show(hb.GetMessageImee(txt_firstname.Text + " " + txt_lastname.Text));
            }
            else
            {
                MessageBox.Show(hb.GetMessageLouisse(txt_firstname.Text + " " + txt_lastname.Text));
            }
            
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
