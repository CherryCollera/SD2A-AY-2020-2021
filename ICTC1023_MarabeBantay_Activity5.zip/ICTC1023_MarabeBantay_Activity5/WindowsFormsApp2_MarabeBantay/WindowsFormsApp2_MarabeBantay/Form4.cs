﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2_MarabeBantay
{
    public partial class Form4 : Form
    {
        double a, b;
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txtFnumber.Text);
            b = Convert.ToDouble(txtSnumber.Text);
            txtAnswer.Text = (a + b).ToString();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txtFnumber.Clear();
            txtSnumber.Clear();
            txtAnswer.Clear();
            txtFnumber.Focus();
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txtFnumber.Text);
            b = Convert.ToDouble(txtSnumber.Text);
            txtAnswer.Text = (a - b).ToString();
        }

        private void btn_product_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txtFnumber.Text);
            b = Convert.ToDouble(txtSnumber.Text);
            txtAnswer.Text = (a * b).ToString();
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txtFnumber.Text);
            b = Convert.ToDouble(txtSnumber.Text);
            txtAnswer.Text = (a / b).ToString();
        }

        private void btn_remainder_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txtFnumber.Text);
            b = Convert.ToDouble(txtSnumber.Text);
            txtAnswer.Text = (a % b).ToString();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
